#!/usr/bin/env python3
"""
patch_math_latex.py — Adds Smart Math/LaTeX extraction to Alt+Q pipeline.
Uses byte-level patching to avoid Unicode issues with edit_file.
"""

import sys, shutil, os

def patch(data, old, new, label, required=True):
    if old not in data:
        if required:
            print(f"FAIL: '{label}' - needle not found")
            sys.exit(1)
        else:
            print(f"SKIP (not found): '{label}'")
            return data
    count = data.count(old)
    if count > 1:
        print(f"FAIL: '{label}' - needle found {count} times (ambiguous)")
        sys.exit(1)
    data = data.replace(old, new, 1)
    print(f"OK: {label}")
    return data

# ============================================================
# Read content.js
# ============================================================
with open('content.js', 'r', encoding='utf-8') as f:
    cjs = f.read()

shutil.copy('content.js', 'content.js.bak_math')
print("Backup created: content.js.bak_math")

# ============================================================
# PATCH 1: Insert MathML-to-LaTeX converter & smart extractor
#           right after runWebpageContext variables block
# ============================================================

MATH_MODULE = r'''
        // -----------------------------------------------------------------
        // Smart Math/LaTeX extraction for Alt+Q
        // -----------------------------------------------------------------

        // Unicode → LaTeX symbol map
        const MATH_SYMBOL_MAP = {
            '\u2212': '-', '\u00B1': '\\pm', '\u221E': '\\infty',
            '\u2264': '\\leq', '\u2265': '\\geq', '\u2260': '\\neq',
            '\u2248': '\\approx', '\u2208': '\\in', '\u2209': '\\notin',
            '\u222A': '\\cup', '\u2229': '\\cap', '\u03C0': '\\pi',
            '\u03B1': '\\alpha', '\u03B2': '\\beta', '\u0394': '\\Delta',
            '\u03A3': '\\Sigma', '\u03B3': '\\gamma', '\u03B4': '\\delta',
            '\u03B5': '\\varepsilon', '\u03B6': '\\zeta', '\u03B7': '\\eta',
            '\u03B8': '\\theta', '\u03BB': '\\lambda', '\u03BC': '\\mu',
            '\u03BD': '\\nu', '\u03BE': '\\xi', '\u03C1': '\\rho',
            '\u03C3': '\\sigma', '\u03C4': '\\tau', '\u03C6': '\\phi',
            '\u03C8': '\\psi', '\u03C9': '\\omega', '\u00D7': '\\times',
            '\u00F7': '\\div', '\u2202': '\\partial', '\u2207': '\\nabla',
            '\u222B': '\\int', '\u220F': '\\prod', '\u221A': '\\sqrt',
            '\u2211': '\\sum', '\u2026': '\\ldots', '\u22C5': '\\cdot',
            '\u2192': '\\to', '\u2190': '\\leftarrow', '\u21D2': '\\Rightarrow',
            '\u21D0': '\\Leftarrow', '\u2200': '\\forall', '\u2203': '\\exists',
            '\u2205': '\\emptyset', '\u2282': '\\subset', '\u2283': '\\supset',
            '\u2286': '\\subseteq', '\u2287': '\\supseteq',
            '\u22A5': '\\perp', '\u2220': '\\angle',
            '\u00B0': '^{\\circ}', '\u2032': "'", '\u2033': "''",
        };

        function escapeMathSymbols(text) {
            let result = '';
            for (const ch of text) {
                result += MATH_SYMBOL_MAP[ch] || ch;
            }
            return result;
        }

        // --- MathML tag → LaTeX converter ---
        const MATHML_TAGS = new Set([
            'math','mrow','mi','mn','mo','mfrac','msqrt','mroot',
            'msup','msub','msubsup','mfenced','mover','munder',
            'munderover','mtable','mtr','mtd','mtext','mspace',
            'mstyle','merror','mpadded','mphantom','menclose',
            'semantics','annotation','annotation-xml'
        ]);

        function isMathMLElement(el) {
            if (!el || el.nodeType !== 1) return false;
            const tag = el.tagName?.toLowerCase?.() || '';
            return MATHML_TAGS.has(tag) || el.namespaceURI === 'http://www.w3.org/1998/Math/MathML';
        }

        function convertMathMLNodeToLatex(node) {
            if (!node) return '';
            if (node.nodeType === 3) return escapeMathSymbols(node.textContent || '');
            if (node.nodeType !== 1) return '';

            const tag = (node.tagName || '').toLowerCase().replace(/^m:/, '');
            const children = Array.from(node.childNodes);

            function childLatex(index) {
                if (index >= children.length) return '';
                return convertMathMLNodeToLatex(children[index]);
            }
            function allChildrenLatex() {
                return children.map(c => convertMathMLNodeToLatex(c)).join('');
            }

            switch (tag) {
                case 'math':
                case 'mrow':
                case 'mstyle':
                case 'mpadded':
                    return allChildrenLatex();

                case 'semantics': {
                    // Try annotation first
                    const annot = node.querySelector('annotation[encoding="application/x-tex"]');
                    if (annot && annot.textContent.trim()) return annot.textContent.trim();
                    // Fallback to first child
                    return children.length > 0 ? convertMathMLNodeToLatex(children[0]) : '';
                }

                case 'annotation':
                    return ''; // handled by semantics

                case 'mi':
                case 'mn':
                case 'mtext':
                    return escapeMathSymbols(node.textContent || '');

                case 'mo': {
                    const text = (node.textContent || '').trim();
                    return escapeMathSymbols(text);
                }

                case 'mfrac': {
                    if (children.length < 2) return allChildrenLatex();
                    return '\\frac{' + childLatex(0) + '}{' + childLatex(1) + '}';
                }

                case 'msqrt':
                    return '\\sqrt{' + allChildrenLatex() + '}';

                case 'mroot': {
                    if (children.length < 2) return '\\sqrt{' + allChildrenLatex() + '}';
                    return '\\sqrt[' + childLatex(1) + ']{' + childLatex(0) + '}';
                }

                case 'msup': {
                    if (children.length < 2) return allChildrenLatex();
                    const base = childLatex(0);
                    const exp = childLatex(1);
                    return '{' + base + '}^{' + exp + '}';
                }

                case 'msub': {
                    if (children.length < 2) return allChildrenLatex();
                    return '{' + childLatex(0) + '}_{' + childLatex(1) + '}';
                }

                case 'msubsup': {
                    if (children.length < 3) return allChildrenLatex();
                    return '{' + childLatex(0) + '}_{' + childLatex(1) + '}^{' + childLatex(2) + '}';
                }

                case 'mfenced': {
                    const open = node.getAttribute('open') || '(';
                    const close = node.getAttribute('close') || ')';
                    const separators = node.getAttribute('separators') || ',';
                    const inner = [];
                    for (const child of children) {
                        inner.push(convertMathMLNodeToLatex(child));
                    }
                    const sep = separators.trim().charAt(0) || ',';
                    return '\\left' + open + inner.join(sep + ' ') + '\\right' + close;
                }

                case 'mover': {
                    if (children.length < 2) return allChildrenLatex();
                    const base = childLatex(0);
                    const over = childLatex(1);
                    // Common accents
                    if (over === '\u0302' || over === '^') return '\\hat{' + base + '}';
                    if (over === '\u0304' || over === '\u00AF') return '\\bar{' + base + '}';
                    if (over === '\u02D9' || over === '.') return '\\dot{' + base + '}';
                    if (over === '\u0303' || over === '~') return '\\tilde{' + base + '}';
                    if (over === '\u2192') return '\\vec{' + base + '}';
                    return '\\overset{' + over + '}{' + base + '}';
                }

                case 'munder': {
                    if (children.length < 2) return allChildrenLatex();
                    return '\\underset{' + childLatex(1) + '}{' + childLatex(0) + '}';
                }

                case 'munderover': {
                    if (children.length < 3) return allChildrenLatex();
                    const baseUO = childLatex(0);
                    const under = childLatex(1);
                    const over = childLatex(2);
                    return '{' + baseUO + '}_{' + under + '}^{' + over + '}';
                }

                case 'mtable': {
                    const rows = [];
                    for (const child of children) {
                        if ((child.tagName || '').toLowerCase() === 'mtr') {
                            const cells = [];
                            for (const td of child.childNodes) {
                                if (td.nodeType === 1 && (td.tagName || '').toLowerCase() === 'mtd') {
                                    cells.push(convertMathMLNodeToLatex(td));
                                }
                            }
                            rows.push(cells.join(' & '));
                        }
                    }
                    return '\\begin{matrix} ' + rows.join(' \\\\ ') + ' \\end{matrix}';
                }

                case 'mtr':
                case 'mtd':
                    return allChildrenLatex();

                case 'mspace':
                    return '\\; ';

                case 'mphantom':
                    return '\\phantom{' + allChildrenLatex() + '}';

                case 'merror':
                    return '\\text{[error: ' + allChildrenLatex() + ']}';

                case 'menclose': {
                    const notation = node.getAttribute('notation') || '';
                    if (notation.includes('radical')) return '\\sqrt{' + allChildrenLatex() + '}';
                    return allChildrenLatex();
                }

                default:
                    return allChildrenLatex();
            }
        }

        function mathMLStringToLatex(markup) {
            try {
                const parser = new DOMParser();
                const doc = parser.parseFromString(
                    '<wrapper xmlns:m="http://www.w3.org/1998/Math/MathML">' + markup + '</wrapper>',
                    'text/html'
                );
                const math = doc.querySelector('math') ||
                             doc.querySelector('mrow') ||
                             doc.body;
                if (!math) return null;
                return convertMathMLNodeToLatex(math);
            } catch (e) {
                console.warn('UD/AA MathML parse error:', e);
                return null;
            }
        }

        function extractLatexFromMathElement(element) {
            if (!element || element.nodeType !== 1) {
                return { latex: null, source: 'none', exact: false, display: false, warning: 'Not an element' };
            }

            const isDisplay = element.getAttribute('display') === 'block' ||
                              element.classList?.contains?.('display') ||
                              element.closest?.('[display="block"]') !== null;

            // Priority 1: data-latex / data-tex attribute
            const dataLatex = element.getAttribute('data-latex') ||
                              element.getAttribute('data-tex') ||
                              element.closest?.('[data-latex]')?.getAttribute('data-latex') ||
                              element.closest?.('[data-tex]')?.getAttribute('data-tex');
            if (dataLatex) {
                return { latex: dataLatex, source: 'data-tex', exact: true, display: isDisplay };
            }

            // Priority 2: annotation[encoding="application/x-tex"]
            const annotation = element.querySelector?.('annotation[encoding="application/x-tex"]');
            if (annotation && annotation.textContent.trim()) {
                return { latex: annotation.textContent.trim(), source: 'annotation', exact: true, display: isDisplay };
            }

            // Priority 3: MathJax original TeX script
            const mjxId = element.getAttribute?.('data-mjx-texcode') ||
                          element.id;
            if (mjxId) {
                const texScript = document.querySelector(
                    'script[type^="math/tex"][id="' + mjxId + '"],' +
                    'script[type^="math/tex"][data-target="' + mjxId + '"]'
                );
                if (texScript && texScript.textContent.trim()) {
                    return { latex: texScript.textContent.trim(), source: 'mathjax', exact: true, display: isDisplay };
                }
            }
            // Try nearby script tags
            const prevSib = element.previousElementSibling;
            if (prevSib && prevSib.tagName === 'SCRIPT' &&
                (prevSib.type || '').startsWith('math/tex') &&
                prevSib.textContent.trim()) {
                return { latex: prevSib.textContent.trim(), source: 'mathjax', exact: true, display: isDisplay };
            }

            // Priority 4: data-mathml attribute
            const dataMathML = element.getAttribute('data-mathml');
            if (dataMathML) {
                const latex = mathMLStringToLatex(dataMathML);
                if (latex) return { latex, source: 'data-mathml', exact: false, display: isDisplay };
            }

            // Priority 5: DOM MathML elements
            const mathEl = element.tagName?.toLowerCase() === 'math' ? element :
                           element.querySelector?.('math');
            if (mathEl) {
                const latex = convertMathMLNodeToLatex(mathEl);
                if (latex) return { latex, source: 'mathml', exact: false, display: isDisplay };
            }

            // Priority 6: KaTeX MathML inside .katex-mathml
            const katexMathML = element.querySelector?.('.katex-mathml math') ||
                                element.closest?.('.katex')?.querySelector?.('.katex-mathml math');
            if (katexMathML) {
                // Check annotation first
                const katexAnnot = katexMathML.querySelector('annotation[encoding="application/x-tex"]');
                if (katexAnnot && katexAnnot.textContent.trim()) {
                    return { latex: katexAnnot.textContent.trim(), source: 'katex', exact: true, display: isDisplay };
                }
                const latex = convertMathMLNodeToLatex(katexMathML);
                if (latex) return { latex, source: 'katex-mathml', exact: false, display: isDisplay };
            }

            // Priority 7: MathJax assistive MML
            const mjxMml = element.querySelector?.('mjx-assistive-mml math');
            if (mjxMml) {
                const latex = convertMathMLNodeToLatex(mjxMml);
                if (latex) return { latex, source: 'mathjax-mml', exact: false, display: isDisplay };
            }

            return { latex: null, source: 'visual-fallback', exact: false, display: false,
                     warning: 'Formula source unavailable' };
        }

        // --- Detect if a DOM element is a math container ---
        function isMathContainer(el) {
            if (!el || el.nodeType !== 1) return false;
            const tag = (el.tagName || '').toLowerCase();

            // MathML
            if (isMathMLElement(el)) return true;

            // KaTeX
            if (el.classList?.contains?.('katex') ||
                el.classList?.contains?.('katex-display') ||
                el.classList?.contains?.('editor-equation')) return true;

            // MathJax
            if (tag === 'mjx-container' || tag === 'mjx-math') return true;

            // data attributes
            if (el.hasAttribute?.('data-latex') || el.hasAttribute?.('data-tex') ||
                el.hasAttribute?.('data-mathml')) return true;

            // script type math/tex
            if (tag === 'script' && (el.type || '').startsWith('math/tex')) return true;

            return false;
        }

        function findMathAncestor(el) {
            let node = el;
            while (node) {
                if (isMathContainer(node)) return node;
                if (node.parentElement && isMathContainer(node.parentElement)) return node.parentElement;
                node = node.parentElement;
            }
            return null;
        }

        // --- Smart text extraction from selection Range ---
        function extractSmartContent(selection) {
            if (!selection || selection.rangeCount === 0) return '';

            const range = selection.getRangeAt(0);
            const fragment = range.cloneContents();

            // Quick check: is there any math content?
            const hasMathContent = fragment.querySelector(
                'math, .katex, .katex-display, mjx-container, [data-latex], [data-tex], ' +
                '[data-mathml], .editor-equation, script[type^="math/tex"], ' +
                'annotation[encoding="application/x-tex"]'
            );

            // If no math, return plain text unchanged (original behavior)
            if (!hasMathContent) {
                return String(selection).trim();
            }

            // Walk the original DOM range to preserve structure
            const parts = [];
            const processedMathRoots = new Set();

            function walkNode(node) {
                if (!node) return;

                // Text node
                if (node.nodeType === 3) {
                    const text = node.textContent || '';
                    if (text.trim()) parts.push(text);
                    else if (text.includes('\n')) parts.push('\n');
                    else if (parts.length > 0 && text.includes(' ')) parts.push(' ');
                    return;
                }

                if (node.nodeType !== 1) return;

                // Skip hidden elements and decorative content
                const tag = (node.tagName || '').toLowerCase();
                if (tag === 'script' && !(node.type || '').startsWith('math/tex')) return;
                if (tag === 'style' || tag === 'link') return;
                if (tag === 'img' || tag === 'svg') {
                    // Check if it's a math-related SVG (MathJax)
                    if (!node.closest?.('mjx-container') && !node.closest?.('.katex')) return;
                }

                // Math container detection
                if (isMathContainer(node)) {
                    // Prevent duplicates
                    const mathKey = node.outerHTML?.substring(0, 200) || node.textContent;
                    if (processedMathRoots.has(mathKey)) return;
                    processedMathRoots.add(mathKey);

                    // Look for the original element in the live DOM (fragment loses context)
                    const result = extractLatexFromElement_InLiveDOM(node, range);
                    if (result && result.latex) {
                        if (result.display) {
                            parts.push('\n\\[\n' + result.latex + '\n\\]\n');
                        } else {
                            parts.push('\\(' + result.latex + '\\)');
                        }
                    } else if (result && result.warning) {
                        // Can't extract reliably, use text content
                        const fallback = (node.textContent || '').trim();
                        if (fallback) parts.push(fallback);
                    }
                    return;
                }

                // KaTeX .katex-html sibling (already processed via .katex parent)
                if (node.classList?.contains?.('katex-html') &&
                    node.parentElement?.classList?.contains?.('katex')) {
                    return; // Skip, .katex parent handled it
                }
                if (node.classList?.contains?.('katex-mathml')) {
                    return; // Skip, .katex parent handled it
                }

                // Block elements add line breaks
                const isBlock = /^(p|div|h[1-6]|li|br|hr|tr|blockquote|section|article|pre|ol|ul|table|dd|dt|dl|figcaption)$/.test(tag);
                if (isBlock && parts.length > 0) {
                    const last = parts[parts.length - 1];
                    if (last && last !== '\n' && !last.endsWith('\n')) parts.push('\n');
                }
                if (tag === 'br') { parts.push('\n'); return; }

                // List items
                if (tag === 'li') {
                    const parent = node.parentElement;
                    if (parent && parent.tagName?.toLowerCase() === 'ol') {
                        const idx = Array.from(parent.children).indexOf(node) + 1;
                        parts.push(idx + '. ');
                    }
                }

                // Recurse into children
                for (const child of node.childNodes) {
                    walkNode(child);
                }

                if (isBlock) {
                    const last = parts[parts.length - 1];
                    if (last && last !== '\n' && !last.endsWith('\n')) parts.push('\n');
                }
            }

            // Try to find math elements in the original live DOM
            function extractLatexFromElement_InLiveDOM(fragmentNode, selRange) {
                // The fragment is a copy; we need to find the matching element in
                // the live document to access sibling scripts, parents, etc.

                // Strategy: search the live DOM around the selection
                const container = selRange.commonAncestorContainer;
                const root = container.nodeType === 1 ? container : container.parentElement;
                if (!root) return extractLatexFromMathElement(fragmentNode);

                // Try to find matching live element by class / tag
                const fragTag = (fragmentNode.tagName || '').toLowerCase();
                const fragClass = fragmentNode.className || '';

                let candidates = [];
                if (fragClass && typeof fragClass === 'string') {
                    const mainClass = fragClass.split(/\s+/)[0];
                    if (mainClass) candidates = Array.from(root.querySelectorAll('.' + CSS.escape(mainClass)));
                }
                if (candidates.length === 0 && fragTag) {
                    candidates = Array.from(root.querySelectorAll(fragTag));
                }

                // Find the best match by text similarity
                const fragText = (fragmentNode.textContent || '').trim().substring(0, 80);
                for (const cand of candidates) {
                    const candText = (cand.textContent || '').trim().substring(0, 80);
                    if (candText === fragText || fragText.includes(candText) || candText.includes(fragText)) {
                        return extractLatexFromMathElement(cand);
                    }
                }

                // Fallback to fragment element
                return extractLatexFromMathElement(fragmentNode);
            }

            walkNode(fragment);

            // Clean up result
            let result = parts.join('')
                .replace(/\n{3,}/g, '\n\n')    // max 2 consecutive newlines
                .replace(/[ \t]{2,}/g, ' ')     // collapse spaces
                .trim();

            return result;
        }

        // --- Validate extracted content ---
        function validateLatexContent(text) {
            if (!text) return { valid: false, error: 'EMPTY_SELECTION' };

            // Check balanced braces
            let braceCount = 0;
            let inCommand = false;
            for (let i = 0; i < text.length; i++) {
                const ch = text[i];
                if (ch === '\\') { inCommand = true; continue; }
                if (inCommand) { inCommand = false; continue; }
                if (ch === '{') braceCount++;
                else if (ch === '}') braceCount--;
                if (braceCount < 0) return { valid: false, error: 'INVALID_LATEX_BRACES' };
            }
            if (braceCount !== 0) return { valid: false, error: 'INVALID_LATEX_BRACES' };

            // Check for duplicate formula wrappers
            if (/\\\(\s*\\\(/.test(text) || /\\\[\s*\\\[/.test(text)) {
                return { valid: false, error: 'DUPLICATE_MATH_EXTRACTION' };
            }

            return { valid: true };
        }

'''

# Insert after the broadcastOverlayEl variable and before the injectStyles comment
ANCHOR_BEFORE_STYLES = "        // -----------------------------------------------------------------\n        // Styling\n        // -----------------------------------------------------------------\n        function injectStyles() {"

cjs = patch(cjs,
    ANCHOR_BEFORE_STYLES,
    MATH_MODULE + "\n" + ANCHOR_BEFORE_STYLES,
    "Insert Math/LaTeX extraction module before injectStyles"
)

# ============================================================
# PATCH 2: Replace the Alt+Q handler with smart extraction
# ============================================================

OLD_ALT_Q = """            // Alt + Q sends selected text into Gemini.
            if (event.altKey && event.code === 'KeyQ' && !event.ctrlKey && !event.shiftKey) {
                event.preventDefault();
                const selectedText = String(window.getSelection() || '').trim();
                if (!selectedText) return;

                await PanelManager.openGemini();
                await delay(300);
                if (siteIframe?.contentWindow) {
                    siteIframe.contentWindow.postMessage({
                        type: 'NERIX_AUTO_PROMPT',
                        text: selectedText
                    }, GEMINI_TARGET_ORIGIN);
                }
                return;
            }"""

NEW_ALT_Q = r"""            // Alt + Q sends selected text (with smart math/LaTeX extraction) into Gemini.
            if (event.altKey && event.code === 'KeyQ' && !event.ctrlKey && !event.shiftKey) {
                event.preventDefault();

                const sel = window.getSelection();
                if (!sel || sel.isCollapsed || !String(sel).trim()) return;

                let extractedText;
                let hasMath = false;
                try {
                    extractedText = extractSmartContent(sel);
                    hasMath = /\\[(\[]|\\frac|\\sqrt|\\sum|\\int|\\prod/.test(extractedText);
                } catch (mathErr) {
                    console.warn('UD/AA: Math extraction error, falling back to plain text:', mathErr);
                    extractedText = String(sel).trim();
                }

                if (!extractedText) return;

                // Validate if math is present
                if (hasMath) {
                    const validation = validateLatexContent(extractedText);
                    if (!validation.valid && validation.error === 'INVALID_LATEX_BRACES') {
                        console.warn('UD/AA: LaTeX brace mismatch detected, using plain text fallback');
                        extractedText = String(sel).trim();
                        hasMath = false;
                    }
                }

                await PanelManager.openGemini();
                await delay(300);
                if (siteIframe?.contentWindow) {
                    siteIframe.contentWindow.postMessage({
                        type: 'NERIX_AUTO_PROMPT',
                        text: extractedText,
                        meta: { hasMath }
                    }, GEMINI_TARGET_ORIGIN);
                }
                return;
            }"""

cjs = patch(cjs, OLD_ALT_Q, NEW_ALT_Q, "Replace Alt+Q handler with smart math extraction")

# ============================================================
# PATCH 3: Update NERIX_AUTO_PROMPT handler in Gemini frame
#           to use better instruction for math content
# ============================================================

OLD_AUTO_PROMPT = r"""            if (event.data.type === 'NERIX_AUTO_PROMPT') {
                if (typeof event.data.text !== 'string' || !event.data.text.trim()) return;
                const prompt = event.data.text.trim() +
                    "\n\nsavolimga aniq qisqa javob ber bu yerda bor variantlardan eng to'g'risini o'zini ayt to'g'ri javob va nechinchi qatorda ekanligi menga aniq javob kerak";
                void insertAndSend(prompt);
            }"""

NEW_AUTO_PROMPT = r"""            if (event.data.type === 'NERIX_AUTO_PROMPT') {
                if (typeof event.data.text !== 'string' || !event.data.text.trim()) return;
                const rawText = event.data.text.trim();
                const hasMath = event.data.meta?.hasMath === true;
                let instruction;
                if (hasMath) {
                    instruction = "\n\nQuyida veb-sahifadan tanlangan material keltirilgan. Matematik formulalar LaTeX formatida berilgan bo'lishi mumkin. Ularni matematik ifoda sifatida talqin qil. Formulalardagi kasr, ildiz, daraja, indeks, qavs va operatorlarning ma'nosini saqla. Oddiy matn va formulalarni birgalikda tahlil qil. Savolga aniq va qisqa javob ber. Agar variantlar bo'lsa, ularning mavjud tartibini va matnini hisobga ol. Noaniq formula uchun taxminiy qiymat yoki belgini o'zingdan qo'shma.";
                } else {
                    instruction = "\n\nsavolimga aniq qisqa javob ber bu yerda bor variantlardan eng to'g'risini o'zini ayt to'g'ri javob va nechinchi qatorda ekanligi menga aniq javob kerak";
                }
                const prompt = rawText + instruction;
                void insertAndSend(prompt);
            }"""

cjs = patch(cjs, OLD_AUTO_PROMPT, NEW_AUTO_PROMPT, "Update NERIX_AUTO_PROMPT handler for math-aware instruction")

# ============================================================
# Write patched content.js
# ============================================================
with open('content.js', 'w', encoding='utf-8') as f:
    f.write(cjs)

print("\n=== All patches applied successfully! ===")
print("Files modified: content.js")
print("Backup: content.js.bak_math")
