#!/usr/bin/env python3
"""
patch_katex_html.py — Adds KaTeX HTML-only parser (superscript, subscript,
mfrac, sqrt, nested structures) to the existing math extraction module.
"""

import sys, shutil

def patch(data, old, new, label, required=True):
    if old not in data:
        if required:
            print(f"FAIL: '{label}' - needle not found")
            sys.exit(1)
        else:
            print(f"SKIP (not found): '{label}'")
            return data
    count = data.count(old)
    if count > 1:
        print(f"FAIL: '{label}' - needle found {count} times (ambiguous)")
        sys.exit(1)
    data = data.replace(old, new, 1)
    print(f"OK: {label}")
    return data

with open('content.js', 'r', encoding='utf-8') as f:
    cjs = f.read()

shutil.copy('content.js', 'content.js.bak_katex')
print("Backup created: content.js.bak_katex")

# ============================================================
# PATCH 1: Insert KaTeX HTML parser before extractLatexFromMathElement
# ============================================================

KATEX_HTML_PARSER = r'''
        // -----------------------------------------------------------------
        // KaTeX HTML-only parser (no MathML/annotation fallback)
        // Handles .katex-html, .msupsub, .mfrac, .sqrt, etc.
        // -----------------------------------------------------------------

        // Set of KaTeX CSS classes that are purely structural/layout
        const KATEX_SKIP_CLASSES = new Set([
            'strut', 'pstrut', 'vlist-s', 'nulldelimiter',
            'fontsize-ensurer', 'reset-size', 'svg-align',
            'frac-line', 'rule', 'hide-tail', 'halfarrow-left',
            'halfarrow-right', 'large-op', 'delimsizing',
        ]);

        function isKatexLayoutOnly(el) {
            if (!el || el.nodeType !== 1) return false;
            const tag = (el.tagName || '').toLowerCase();
            if (tag === 'img' || tag === 'svg' || tag === 'style') return true;
            const cls = el.classList;
            if (!cls) return false;
            for (const c of cls) {
                if (KATEX_SKIP_CLASSES.has(c)) return true;
            }
            // .vlist-s is a zero-width spacer
            if (cls.contains('vlist-s')) return true;
            return false;
        }

        /**
         * parseKaTeXNode(el) — recursively converts a KaTeX HTML element into LaTeX.
         * Works on .katex-html, .base, .mord, .mbin, .mrel, .mopen, .mclose,
         * .mfrac, .msupsub, .sqrt, .mop, .mpunct, and nested structures.
         */
        function parseKaTeXNode(el) {
            if (!el) return '';
            if (el.nodeType === 3) {
                // Text node — return text, map Unicode math symbols
                const t = el.textContent || '';
                return escapeMathSymbols(t);
            }
            if (el.nodeType !== 1) return '';

            // Skip layout-only elements
            if (isKatexLayoutOnly(el)) return '';

            const cls = el.classList || new DOMTokenList();
            const tag = (el.tagName || '').toLowerCase();

            // --- .mfrac: fraction ---
            if (cls.contains('mfrac')) {
                // Structure: .mfrac > .vlist-t.vlist-t2 > .vlist-r > .vlist > children
                // The numerator and denominator are in separate .vlist rows
                // OR direct children might be .frac-line separated elements
                const numDen = extractFractionParts(el);
                if (numDen) {
                    return '\\frac{' + numDen.num + '}{' + numDen.den + '}';
                }
                // Fallback: just concat children
                return childrenLatex(el);
            }

            // --- .sqrt: square root ---
            if (cls.contains('sqrt')) {
                // .sqrt > .vlist > root content
                // May also have .root for nth root
                const rootIndex = el.querySelector(':scope > .root');
                const body = el.querySelector(':scope > .vlist-t') ||
                             el.querySelector(':scope > .vlist');
                const bodyLatex = body ? parseKaTeXNode(body) : childrenLatex(el);
                if (rootIndex) {
                    const idx = parseKaTeXNode(rootIndex);
                    return '\\sqrt[' + idx + ']{' + bodyLatex + '}';
                }
                return '\\sqrt{' + bodyLatex + '}';
            }

            // --- .msupsub: superscript and/or subscript ---
            if (cls.contains('msupsub')) {
                return parseKaTeXSupSub(el);
            }

            // --- .mopen / .mclose: delimiters ---
            if (cls.contains('mopen')) {
                const text = getKatexVisibleText(el);
                const mapped = { '(': '(', '[': '[', '{': '\\{', '|': '|', '\\lvert': '|' };
                return mapped[text] || text || '(';
            }
            if (cls.contains('mclose')) {
                const text = getKatexVisibleText(el);
                const mapped = { ')': ')', ']': ']', '}': '\\}', '|': '|', '\\rvert': '|' };
                return mapped[text] || text || ')';
            }

            // --- .mop: math operator like \sum, \int, \lim ---
            if (cls.contains('mop')) {
                const text = getKatexVisibleText(el).trim();
                const opMap = {
                    'lim': '\\lim', 'sin': '\\sin', 'cos': '\\cos', 'tan': '\\tan',
                    'log': '\\log', 'ln': '\\ln', 'max': '\\max', 'min': '\\min',
                    'sup': '\\sup', 'inf': '\\inf', 'det': '\\det', 'gcd': '\\gcd',
                    '\u2211': '\\sum', '\u220F': '\\prod', '\u222B': '\\int',
                };
                return opMap[text] || escapeMathSymbols(text);
            }

            // --- .mbin: binary operator ---
            if (cls.contains('mbin')) {
                const text = getKatexVisibleText(el);
                return escapeMathSymbols(text);
            }

            // --- .mrel: relation operator ---
            if (cls.contains('mrel')) {
                const text = getKatexVisibleText(el);
                return escapeMathSymbols(text);
            }

            // --- .mpunct: punctuation ---
            if (cls.contains('mpunct')) {
                return getKatexVisibleText(el);
            }

            // --- .mspace: spacing ---
            if (cls.contains('mspace')) {
                return ' ';
            }

            // --- .mord: ordinary math character ---
            // Could contain nested .msupsub, .mfrac, etc.
            if (cls.contains('mord')) {
                return parseKaTeXMord(el);
            }

            // --- .base: a rendering line within .katex-html ---
            if (cls.contains('base')) {
                return childrenLatex(el);
            }

            // --- .katex-html: top-level ---
            if (cls.contains('katex-html')) {
                return childrenLatex(el);
            }

            // --- .katex: top-level container ---
            if (cls.contains('katex') || cls.contains('katex-display')) {
                // Prefer .katex-mathml annotation if present
                const mathml = el.querySelector('.katex-mathml annotation[encoding="application/x-tex"]');
                if (mathml && mathml.textContent.trim()) {
                    return mathml.textContent.trim();
                }
                // Then try .katex-mathml math
                const mathmlEl = el.querySelector('.katex-mathml math');
                if (mathmlEl) {
                    const converted = convertMathMLNodeToLatex(mathmlEl);
                    if (converted) return converted;
                }
                // Fallback to HTML parsing
                const htmlPart = el.querySelector('.katex-html');
                if (htmlPart) return parseKaTeXNode(htmlPart);
                return childrenLatex(el);
            }

            // --- .editor-equation: wrapper around .katex ---
            if (cls.contains('editor-equation')) {
                const katex = el.querySelector('.katex');
                if (katex) return parseKaTeXNode(katex);
                return childrenLatex(el);
            }

            // --- .vlist, .vlist-t, .vlist-r: vertical list containers ---
            if (cls.contains('vlist') || cls.contains('vlist-t') ||
                cls.contains('vlist-t2') || cls.contains('vlist-r')) {
                return childrenLatex(el);
            }

            // --- .sizing, .mtight: sizing containers ---
            if (cls.contains('sizing') || cls.contains('mtight') ||
                cls.contains('minner')) {
                return childrenLatex(el);
            }

            // --- span with .mathnormal, .mathrm, .mathit, .mathbf ---
            if (cls.contains('mathnormal') || cls.contains('mathrm') ||
                cls.contains('mathit') || cls.contains('mathbf') ||
                cls.contains('mathbb') || cls.contains('mathcal') ||
                cls.contains('mathsf') || cls.contains('mathtt')) {
                return escapeMathSymbols(el.textContent || '');
            }

            // Generic: recurse into children
            return childrenLatex(el);
        }

        function childrenLatex(el) {
            let result = '';
            for (const child of el.childNodes) {
                result += parseKaTeXNode(child);
            }
            return result;
        }

        /**
         * Parse .mord which may be a simple character or contain
         * nested .msupsub structures
         */
        function parseKaTeXMord(el) {
            const children = Array.from(el.childNodes);

            // Simple case: just text content, no element children
            const elementChildren = children.filter(c => c.nodeType === 1);
            if (elementChildren.length === 0) {
                return escapeMathSymbols(el.textContent || '');
            }

            // Check for .msupsub as a child (base + sup/sub together)
            let result = '';
            for (const child of children) {
                if (child.nodeType === 3) {
                    result += escapeMathSymbols(child.textContent || '');
                } else if (child.nodeType === 1) {
                    if (isKatexLayoutOnly(child)) continue;
                    result += parseKaTeXNode(child);
                }
            }
            return result;
        }

        /**
         * Parse .msupsub to extract superscript and/or subscript.
         *
         * KaTeX structures for sup/sub:
         *
         * Case 1 — Sup only (.vlist-t2):
         * .msupsub > .vlist-t.vlist-t2 > .vlist-r > .vlist > [rows]
         * where rows contain the sub (bottom) and sup (top) values.
         *
         * Case 2 — Sup only (.vlist-t, no .vlist-t2):
         * .msupsub > .vlist-t > .vlist-r > .vlist > one row with sup
         *
         * The sup element typically has a negative top style (shifted up).
         * The sub element has 0 or positive top.
         */
        function parseKaTeXSupSub(el) {
            const vlistT = el.querySelector(':scope > .vlist-t');
            if (!vlistT) {
                // No vlist structure — try direct text
                return childrenLatex(el);
            }

            const hasT2 = vlistT.classList.contains('vlist-t2');
            const vlistR = vlistT.querySelector(':scope > .vlist-r');
            if (!vlistR) return childrenLatex(el);

            const vlists = vlistR.querySelectorAll(':scope > .vlist');
            if (vlists.length === 0) return childrenLatex(el);

            const mainVlist = vlists[0];
            const rows = Array.from(mainVlist.children).filter(
                c => c.nodeType === 1 && !isKatexLayoutOnly(c)
            );

            let supLatex = '';
            let subLatex = '';

            if (hasT2 && rows.length >= 2) {
                // Two rows: bottom row = subscript, top row = superscript
                // Row order in DOM: first row is the bottom (sub), second is top (sup)
                // Actually in KaTeX, the rows go from bottom to top in DOM order
                // with negative top values for the superscript
                //
                // We identify by style.top: more negative = higher (superscript)
                const parsed = rows.map(row => {
                    const topStyle = parseFloat(row.style?.top) || 0;
                    const content = parseKaTeXSupSubContent(row);
                    return { top: topStyle, content };
                });

                // Sort by top value: most negative (highest) first
                parsed.sort((a, b) => a.top - b.top);

                if (parsed.length >= 2) {
                    supLatex = parsed[0].content; // most negative top = superscript
                    subLatex = parsed[parsed.length - 1].content; // least negative = subscript
                } else if (parsed.length === 1) {
                    // Determine based on top value
                    if (parsed[0].top < -0.2) {
                        supLatex = parsed[0].content;
                    } else {
                        subLatex = parsed[0].content;
                    }
                }
            } else if (rows.length >= 1) {
                // Single row — determine sup or sub based on top value
                const topVal = parseFloat(rows[0].style?.top) || 0;
                const content = parseKaTeXSupSubContent(rows[0]);
                if (topVal < -0.2) {
                    supLatex = content;
                } else {
                    subLatex = content;
                }
            }

            let result = '';
            if (subLatex) result += '_{' + subLatex + '}';
            if (supLatex) result += '^{' + supLatex + '}';
            return result;
        }

        /**
         * Extract the actual math content from a sup/sub row element.
         * Skips .pstrut, .sizing wrappers, and digs into .mtight.
         */
        function parseKaTeXSupSubContent(rowEl) {
            let result = '';
            for (const child of rowEl.childNodes) {
                if (child.nodeType === 3) {
                    const t = (child.textContent || '').trim();
                    if (t) result += escapeMathSymbols(t);
                    continue;
                }
                if (child.nodeType !== 1) continue;
                if (isKatexLayoutOnly(child)) continue;

                const cls = child.classList;
                if (cls?.contains?.('sizing') || cls?.contains?.('mtight')) {
                    result += childrenLatex(child);
                } else if (cls?.contains?.('mord') || cls?.contains?.('mrel') ||
                           cls?.contains?.('mbin') || cls?.contains?.('mop')) {
                    result += parseKaTeXNode(child);
                } else {
                    result += parseKaTeXNode(child);
                }
            }
            return result;
        }

        /**
         * Extract fraction parts from .mfrac element.
         * KaTeX structure:
         * .mfrac > .vlist-t.vlist-t2 > .vlist-r > .vlist > rows
         * where rows contain numerator (top) and denominator (bottom),
         * separated by .frac-line.
         */
        function extractFractionParts(mfracEl) {
            const rows = [];
            const vlist = mfracEl.querySelector('.vlist-t .vlist-r > .vlist') ||
                          mfracEl.querySelector('.vlist-t > .vlist-r > .vlist') ||
                          mfracEl.querySelector('.vlist');
            if (!vlist) return null;

            for (const child of vlist.children) {
                if (child.nodeType !== 1) continue;
                if (isKatexLayoutOnly(child)) continue;
                if (child.classList?.contains?.('frac-line')) continue;
                // Skip .vlist-s spacers
                if (child.classList?.contains?.('vlist-s')) continue;

                const content = parseKaTeXSupSubContent(child);
                if (content || content === '0') rows.push(content);
            }

            if (rows.length >= 2) {
                // In KaTeX fraction DOM, numerator is first, denominator is second
                return { num: rows[0], den: rows[1] };
            }
            return null;
        }

        /**
         * Get visible text from a KaTeX element, skipping layout nodes.
         */
        function getKatexVisibleText(el) {
            if (!el) return '';
            if (el.nodeType === 3) return el.textContent || '';
            if (el.nodeType !== 1) return '';
            if (isKatexLayoutOnly(el)) return '';
            let text = '';
            for (const child of el.childNodes) {
                text += getKatexVisibleText(child);
            }
            return text;
        }

'''

# Insert before extractLatexFromMathElement
INSERT_ANCHOR = "        function extractLatexFromMathElement(element) {"

cjs = patch(cjs, INSERT_ANCHOR, KATEX_HTML_PARSER + "\n" + INSERT_ANCHOR,
    "Insert KaTeX HTML parser before extractLatexFromMathElement")

# ============================================================
# PATCH 2: Add Priority 8 (KaTeX HTML-only) to extractLatexFromMathElement
#           right before the final return
# ============================================================

OLD_FINAL_RETURN = '''            return { latex: null, source: 'visual-fallback', exact: false, display: false,
                     warning: 'Formula source unavailable' };
        }'''

NEW_FINAL_RETURN = '''            // Priority 8: KaTeX HTML-only parsing (no MathML available)
            const katexHtml = element.querySelector?.('.katex-html') ||
                              (element.classList?.contains?.('katex-html') ? element : null) ||
                              element.closest?.('.katex')?.querySelector?.('.katex-html') ||
                              (element.classList?.contains?.('editor-equation') ? element.querySelector?.('.katex-html') || element.querySelector?.('.katex') : null);
            if (katexHtml) {
                try {
                    const latex = parseKaTeXNode(katexHtml);
                    if (latex && latex.trim()) {
                        return { latex: latex.trim(), source: 'katex-html', exact: false, display: isDisplay };
                    }
                } catch (e) {
                    console.warn('UD/AA: KaTeX HTML parse error:', e);
                }
            }

            // Priority 9: .editor-equation without .katex wrapper
            if (element.classList?.contains?.('editor-equation')) {
                try {
                    const latex = parseKaTeXNode(element);
                    if (latex && latex.trim()) {
                        return { latex: latex.trim(), source: 'editor-equation', exact: false, display: isDisplay };
                    }
                } catch (e) {
                    console.warn('UD/AA: editor-equation parse error:', e);
                }
            }

            return { latex: null, source: 'visual-fallback', exact: false, display: false,
                     warning: 'Formula source unavailable' };
        }'''

cjs = patch(cjs, OLD_FINAL_RETURN, NEW_FINAL_RETURN,
    "Add KaTeX HTML-only and editor-equation priorities to extractLatexFromMathElement")

# ============================================================
# PATCH 3: Enhance isMathContainer to catch .editor-equation more robustly
# ============================================================

OLD_MATH_CONTAINER_CHECK = """            // KaTeX
            if (el.classList?.contains?.('katex') ||
                el.classList?.contains?.('katex-display') ||
                el.classList?.contains?.('editor-equation')) return true;"""

NEW_MATH_CONTAINER_CHECK = """            // KaTeX
            if (el.classList?.contains?.('katex') ||
                el.classList?.contains?.('katex-display') ||
                el.classList?.contains?.('editor-equation')) return true;

            // .katex-html without .katex parent (rare but possible in fragments)
            if (el.classList?.contains?.('katex-html')) return true;"""

cjs = patch(cjs, OLD_MATH_CONTAINER_CHECK, NEW_MATH_CONTAINER_CHECK,
    "Enhance isMathContainer with .katex-html detection")

# ============================================================
# PATCH 4: Improve extractSmartContent to handle multiple
#           .editor-equation within one paragraph properly
# ============================================================

OLD_QUICK_CHECK = """            // Quick check: is there any math content?
            const hasMathContent = fragment.querySelector(
                'math, .katex, .katex-display, mjx-container, [data-latex], [data-tex], ' +
                '[data-mathml], .editor-equation, script[type^="math/tex"], ' +
                'annotation[encoding="application/x-tex"]'
            );

            // If no math, return plain text unchanged (original behavior)
            if (!hasMathContent) {
                return String(selection).trim();
            }"""

NEW_QUICK_CHECK = """            // Quick check: is there any math content?
            const hasMathContent = fragment.querySelector(
                'math, .katex, .katex-display, .katex-html, mjx-container, ' +
                '[data-latex], [data-tex], [data-mathml], .editor-equation, ' +
                'script[type^="math/tex"], annotation[encoding="application/x-tex"], ' +
                '.msupsub, .mfrac, .mord > .msupsub'
            );

            // If no math, return plain text unchanged (original behavior)
            if (!hasMathContent) {
                return String(selection).trim();
            }"""

cjs = patch(cjs, OLD_QUICK_CHECK, NEW_QUICK_CHECK,
    "Expand math content detection selectors")

# ============================================================
# PATCH 5: Fix walkNode to properly handle .katex-html and
#           .editor-equation as math containers even when
#           they appear as children of non-math parents
# ============================================================

OLD_KATEX_HTML_SKIP = """                // KaTeX .katex-html sibling (already processed via .katex parent)
                if (node.classList?.contains?.('katex-html') &&
                    node.parentElement?.classList?.contains?.('katex')) {
                    return; // Skip, .katex parent handled it
                }
                if (node.classList?.contains?.('katex-mathml')) {
                    return; // Skip, .katex parent handled it
                }"""

NEW_KATEX_HTML_SKIP = """                // KaTeX .katex-html sibling (already processed via .katex parent)
                if (node.classList?.contains?.('katex-html') &&
                    node.parentElement?.classList?.contains?.('katex')) {
                    return; // Skip, .katex parent handled it
                }
                if (node.classList?.contains?.('katex-mathml')) {
                    return; // Skip, .katex parent handled it
                }

                // .msupsub or .mfrac appearing outside a recognized math container
                // (e.g., partial KaTeX structure in selection fragment)
                if ((node.classList?.contains?.('msupsub') ||
                     node.classList?.contains?.('mfrac') ||
                     node.classList?.contains?.('sqrt')) &&
                    !node.closest?.('.katex, .katex-html, .editor-equation')) {
                    // This is an orphaned KaTeX element — try to parse it
                    try {
                        const orphanLatex = parseKaTeXNode(node);
                        if (orphanLatex) {
                            parts.push(orphanLatex);
                            return;
                        }
                    } catch (_) {}
                }"""

cjs = patch(cjs, OLD_KATEX_HTML_SKIP, NEW_KATEX_HTML_SKIP,
    "Handle orphaned KaTeX structural elements in selection fragments")

# ============================================================
# Write patched file
# ============================================================
with open('content.js', 'w', encoding='utf-8') as f:
    f.write(cjs)

print("\n=== All KaTeX HTML patches applied successfully! ===")
print("Files modified: content.js")
print("Backup: content.js.bak_katex")
