﻿(() => {
    'use strict';
    if (window.__NERIX_CS_LOADED__) return;
    window.__NERIX_CS_LOADED__ = true;

    const IS_TOP_FRAME = window === window.top;
    const IS_GEMINI_ORIGIN = location.origin === 'https://gemini.google.com';
    const GEMINI_TARGET_ORIGIN = 'https://gemini.google.com';
    const SCREENSHOT_GEMINI_PROMPT = `Rasmdagi savolga to'g'ri javob ber. Savolni va barcha variant/qatorlarni diqqat bilan tahlil qil. Asosiy to'g'ri javobni alohida quyidagi shaklda yoz: Javob: [asosiy to'g'ri javob]. Javobingning eng oxirida esa aynan quyidagi ikki qatorni yoz va ulardan keyin boshqa izoh qo'shma:
1.J: [asosiy to'g'ri javob]
2.Q: [javob joylashgan qator yoki variant raqami] manashu 2 qator aniq hiosobotni bold qilib yoz, bulardan boshqasini bold qilma faqat shularni bold qilib yubor`;

    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));


    const _nxErrCounts = Object.create(null);
    const NX_DEDUP_MS  = 5000; 

    function nerixReportError(stage, error, context) {
        try {
            const norm = (error instanceof Error)
                ? error
                : new Error(String(error != null ? error : 'Unknown error'));

            const key = stage + '\x00' + norm.message;
            const now = Date.now();
            const entry = _nxErrCounts[key];

            if (entry && (now - entry.lastLoggedAt) < NX_DEDUP_MS) {
                entry.count++;
                console.warn('[NERIX][ERROR][' + stage + '] (repeated \xd7' + entry.count + '): ' + norm.message);
                return;
            }
            _nxErrCounts[key] = { count: 1, lastLoggedAt: now };

            const extra = Object.assign({ error: norm, stack: norm.stack }, context || {});
            console.error('[NERIX][ERROR][' + stage + '] ' + norm.message, extra);
        } catch (_) {
            
            try { console.error('[NERIX][ERROR][REPORTER_INTERNAL] Diagnostic helper failed.'); } catch (_2) {}
        }
    }

    function nerixLog(level, tag, message, extra) {
        try {
            const prefix = '[NERIX][' + level.toUpperCase() + '][' + tag + '] ' + message;
            if (level === 'warn') {
                extra != null ? console.warn(prefix, extra) : console.warn(prefix);
            } else {
                extra != null ? console.info(prefix, extra) : console.info(prefix);
            }
        } catch (_) {}
    }

    function sendBg(message) {
        return new Promise(resolve => {
            try {
                if (!globalThis.chrome?.runtime?.sendMessage) {
                    resolve({ ok: false, error: 'Chrome extension runtime mavjud emas.' });
                    return;
                }

                chrome.runtime.sendMessage(message, response => {
                    const runtimeError = chrome.runtime.lastError;
                    if (runtimeError) {
                        resolve({ ok: false, error: runtimeError.message });
                        return;
                    }
                    resolve(response || { ok: false, error: 'Background javob qaytarmadi.' });
                });
            } catch (error) {
                resolve({ ok: false, error: error?.message || String(error) });
            }
        });
    }

    function makeElement(tag, options = {}) {
        const element = document.createElement(tag);
        if (options.id) element.id = options.id;
        if (options.className) element.className = options.className;
        if (options.text !== undefined) element.textContent = String(options.text);
        if (options.style) element.style.cssText = options.style;
        return element;
    }




    const UDAA_MATH_CSS = `
        .udaa-math-block {
            display: flex;
            justify-content: center;
            margin: 4px 0;
            font-family: 'Times New Roman', 'Georgia', serif;
        }
        .udaa-math-inline {
            display: inline;
            font-family: 'Times New Roman', 'Georgia', serif;
            font-style: italic;
        }
        .udaa-frac {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            vertical-align: middle;
            font-style: italic;
            margin: 0 1px;
        }
        .udaa-frac-num {
            border-bottom: 1.2px solid currentColor;
            padding: 0 2px 1px 2px;
            text-align: center;
            font-size: 0.88em;
            line-height: 1.1;
        }
        .udaa-frac-den {
            padding: 1px 2px 0 2px;
            text-align: center;
            font-size: 0.88em;
            line-height: 1.1;
        }
        .udaa-sqrt {
            display: inline;
            font-style: normal;
            white-space: nowrap;
        }
        .udaa-sqrt-sign {
            font-size: 1.1em;
            vertical-align: middle;
            font-family: serif;
        }
        .udaa-sqrt-body {
            border-top: 1.3px solid currentColor;
            padding: 0 2px;
            display: inline-block;
            font-style: italic;
            vertical-align: middle;
        }
        .udaa-sup {
            font-size: 0.72em;
            vertical-align: super;
            font-style: italic;
            line-height: 0;
        }
        .udaa-sub {
            font-size: 0.72em;
            vertical-align: sub;
            font-style: italic;
            line-height: 0;
        }
        .udaa-math-var {
            font-style: italic;
        }
        .udaa-math-op {
            font-style: normal;
            padding: 0 2px;
        }
        .udaa-paren { font-style: normal; }
    `;

    // Unicode matematik belgilar jadvali
    const UDAA_SYMBOLS = {
        '\\\\pm':          '\u00b1',
        '\\\\mp':          '\u2213',
        '\\\\times':       '\u00d7',
        '\\\\div':         '\u00f7',
        '\\\\cdot':        '\u00b7',
        '\\\\leq':         '\u2264',
        '\\\\geq':         '\u2265',
        '\\\\neq':         '\u2260',
        '\\\\approx':      '\u2248',
        '\\\\infty':       '\u221e',
        '\\\\in':          '\u2208',
        '\\\\notin':       '\u2209',
        '\\\\cup':         '\u222a',
        '\\\\cap':         '\u2229',
        '\\\\subset':      '\u2282',
        '\\\\supset':      '\u2283',
        '\\\\subseteq':    '\u2286',
        '\\\\supseteq':    '\u2287',
        '\\\\emptyset':    '\u2205',
        '\\\\forall':      '\u2200',
        '\\\\exists':      '\u2203',
        '\\\\partial':     '\u2202',
        '\\\\nabla':       '\u2207',
        '\\\\sum':         '\u03a3',
        '\\\\prod':        '\u03a0',
        '\\\\int':         '\u222b',
        '\\\\to':          '\u2192',
        '\\\\leftarrow':   '\u2190',
        '\\\\Rightarrow':  '\u21d2',
        '\\\\Leftarrow':   '\u21d0',
        '\\\\rightarrow':  '\u2192',
        '\\\\leftrightarrow': '\u2194',
        '\\\\alpha':       '\u03b1',
        '\\\\beta':        '\u03b2',
        '\\\\gamma':       '\u03b3',
        '\\\\delta':       '\u03b4',
        '\\\\epsilon':     '\u03b5',
        '\\\\varepsilon':  '\u03b5',
        '\\\\zeta':        '\u03b6',
        '\\\\eta':         '\u03b7',
        '\\\\theta':       '\u03b8',
        '\\\\iota':        '\u03b9',
        '\\\\kappa':       '\u03ba',
        '\\\\lambda':      '\u03bb',
        '\\\\mu':          '\u03bc',
        '\\\\nu':          '\u03bd',
        '\\\\xi':          '\u03be',
        '\\\\pi':          '\u03c0',
        '\\\\rho':         '\u03c1',
        '\\\\sigma':       '\u03c3',
        '\\\\tau':         '\u03c4',
        '\\\\phi':         '\u03c6',
        '\\\\varphi':      '\u03c6',
        '\\\\chi':         '\u03c7',
        '\\\\psi':         '\u03c8',
        '\\\\omega':       '\u03c9',
        '\\\\Gamma':       '\u0393',
        '\\\\Delta':       '\u0394',
        '\\\\Theta':       '\u0398',
        '\\\\Lambda':      '\u039b',
        '\\\\Pi':          '\u03a0',
        '\\\\Sigma':       '\u03a3',
        '\\\\Phi':         '\u03a6',
        '\\\\Psi':         '\u03a8',
        '\\\\Omega':       '\u03a9',
        '\\\\ldots':       '\u2026',
        '\\\\cdots':       '\u22ef',
        '\\\\angle':       '\u2220',
        '\\\\perp':        '\u22a5',
        '\\\\parallel':    '\u2225',
        '\\\\circ':        '\u2218',
        '\\\\bullet':      '\u2022',
        '\\\\lfloor':      '\u230a',
        '\\\\rfloor':      '\u230b',
        '\\\\lceil':       '\u2308',
        '\\\\rceil':       '\u2309',
    };

    // Trig/log funksiyalari
    const UDAA_FUNCS = new Set([
        'sin','cos','tan','cot','sec','csc',
        'arcsin','arccos','arctan',
        'sinh','cosh','tanh',
        'log','ln','lg','exp',
        'lim','max','min','sup','inf',
        'det','gcd','lcm','mod',
        'Re','Im','arg',
    ]);

    /**
     * LaTeX tokenizer — `{}`, `^`, `_`, `\cmd`, raqam/harf, boshqalarni ajratadi
     */
    function udaaTokenize(latex) {
        const tokens = [];
        let i = 0;
        while (i < latex.length) {
            const ch = latex[i];
            if (ch === '\\') {
                // Command
                let j = i + 1;
                if (j < latex.length) {
                    if (/[a-zA-Z]/.test(latex[j])) {
                        while (j < latex.length && /[a-zA-Z]/.test(latex[j])) j++;
                        tokens.push({ type: 'cmd', val: latex.slice(i, j) });
                    } else {
                        tokens.push({ type: 'cmd', val: latex.slice(i, j + 1) });
                        j++;
                    }
                }
                i = j;
            } else if (ch === '{') {
                tokens.push({ type: 'lbrace' }); i++;
            } else if (ch === '}') {
                tokens.push({ type: 'rbrace' }); i++;
            } else if (ch === '^') {
                tokens.push({ type: 'sup' }); i++;
            } else if (ch === '_') {
                tokens.push({ type: 'sub' }); i++;
            } else if (ch === '(') {
                tokens.push({ type: 'paren', val: '(' }); i++;
            } else if (ch === ')') {
                tokens.push({ type: 'paren', val: ')' }); i++;
            } else if (ch === '[') {
                tokens.push({ type: 'paren', val: '[' }); i++;
            } else if (ch === ']') {
                tokens.push({ type: 'paren', val: ']' }); i++;
            } else if (ch === ' ' || ch === '\t' || ch === '\n') {
                i++;
            } else if (/[0-9]/.test(ch)) {
                let j = i;
                while (j < latex.length && /[0-9.]/.test(latex[j])) j++;
                tokens.push({ type: 'num', val: latex.slice(i, j) });
                i = j;
            } else {
                tokens.push({ type: 'ch', val: ch });
                i++;
            }
        }
        return tokens;
    }


    function udaaParseMath(tokens, pos, stopAtBrace) {
        const frag = document.createDocumentFragment();
        while (pos < tokens.length) {
            const tok = tokens[pos];
            if (stopAtBrace && tok.type === 'rbrace') {
                pos++;
                break;
            }
            if (tok.type === 'rbrace') { pos++; break; }

            if (tok.type === 'lbrace') {
                pos++;
                const [groupFrag, newPos] = udaaParseGroup(tokens, pos);
                pos = newPos;

                const [afterSupSubPos] = udaaHandleSupSub(tokens, pos, frag, groupFrag);
                pos = afterSupSubPos;
                continue;
            }

            if (tok.type === 'cmd') {
                const [el, newPos] = udaaHandleCmd(tokens, pos);
                pos = newPos;
                if (el) {
                    if (el instanceof Node) {
                        // sup/sub after command
                        const wrapper = document.createDocumentFragment();
                        wrapper.appendChild(el);
                        const [p2, f2] = udaaHandleSupSubNode(tokens, pos, el);
                        pos = p2;
                        
                        frag.appendChild(f2);
                        continue;
                    }
                }
                continue;
            }

            if (tok.type === 'sup') {
                pos++;
                const [groupFrag2, pos2] = udaaParseNextAtom(tokens, pos);
                pos = pos2;
                const sup = document.createElement('span');
                sup.className = 'udaa-sup';
                sup.appendChild(groupFrag2);
                frag.appendChild(sup);
                continue;
            }

            if (tok.type === 'sub') {
                pos++;
                const [groupFrag3, pos3] = udaaParseNextAtom(tokens, pos);
                pos = pos3;
                const sub = document.createElement('span');
                sub.className = 'udaa-sub';
                sub.appendChild(groupFrag3);
                frag.appendChild(sub);
                continue;
            }

    
            const span = document.createElement('span');
            if (tok.type === 'num') {
                span.textContent = tok.val;
            } else if (tok.type === 'paren') {
                span.className = 'udaa-paren';
                span.textContent = tok.val;
            } else {
                span.className = 'udaa-math-var';
                span.textContent = tok.val || '';
            }
            pos++;
     
            const [p2, s2] = udaaHandleSupSubNode(tokens, pos, span);
            pos = p2;
            frag.appendChild(s2);
            continue;
        }
        return [frag, pos];
    }

    function udaaParseGroup(tokens, pos) {
        const frag = document.createDocumentFragment();
        while (pos < tokens.length) {
            const tok = tokens[pos];
            if (tok.type === 'rbrace') { pos++; break; }

            if (tok.type === 'lbrace') {
                pos++;
                const [inner, p2] = udaaParseGroup(tokens, pos);
                pos = p2;
                frag.appendChild(inner);
                continue;
            }
            if (tok.type === 'cmd') {
                const [el, p2] = udaaHandleCmd(tokens, pos);
                pos = p2;
                if (el instanceof Node) {
                    const [p3, s3] = udaaHandleSupSubNode(tokens, pos, el);
                    pos = p3;
                    frag.appendChild(s3);
                }
                continue;
            }
            if (tok.type === 'sup') {
                pos++;
                const [a, p2] = udaaParseNextAtom(tokens, pos);
                pos = p2;
                const sup = document.createElement('span');
                sup.className = 'udaa-sup';
                sup.appendChild(a);
                frag.appendChild(sup);
                continue;
            }
            if (tok.type === 'sub') {
                pos++;
                const [a, p2] = udaaParseNextAtom(tokens, pos);
                pos = p2;
                const sub = document.createElement('span');
                sub.className = 'udaa-sub';
                sub.appendChild(a);
                frag.appendChild(sub);
                continue;
            }
            const span = document.createElement('span');
            if (tok.type === 'num') {
                span.textContent = tok.val;
            } else if (tok.type === 'paren') {
                span.className = 'udaa-paren';
                span.textContent = tok.val;
            } else {
                span.className = 'udaa-math-var';
                span.textContent = tok.val || '';
            }
            pos++;
            const [p3, s3] = udaaHandleSupSubNode(tokens, pos, span);
            pos = p3;
            frag.appendChild(s3);
        }
        return [frag, pos];
    }

    function udaaParseNextAtom(tokens, pos) {
        const frag = document.createDocumentFragment();
        if (pos >= tokens.length) return [frag, pos];
        const tok = tokens[pos];
        if (tok.type === 'lbrace') {
            pos++;
            return udaaParseGroup(tokens, pos);
        }
        if (tok.type === 'cmd') {
            const [el, p2] = udaaHandleCmd(tokens, pos);
            if (el instanceof Node) frag.appendChild(el);
            return [frag, p2];
        }
        if (tok.type === 'num') {
            const sp = document.createElement('span');
            sp.textContent = tok.val;
            frag.appendChild(sp);
            return [frag, pos + 1];
        }
        const sp = document.createElement('span');
        sp.className = (tok.type === 'paren') ? 'udaa-paren' : 'udaa-math-var';
        sp.textContent = tok.val || '';
        frag.appendChild(sp);
        return [frag, pos + 1];
    }

    function udaaHandleSupSubNode(tokens, pos, baseNode) {
        // Returns [newPos, fragmentContainingBaseAndSupSub]
        const wrap = document.createDocumentFragment();
        const container = document.createElement('span');
        container.style.display = 'inline';
        container.appendChild(baseNode);

        while (pos < tokens.length) {
            const tok = tokens[pos];
            if (tok.type === 'sup') {
                pos++;
                const [a, p2] = udaaParseNextAtom(tokens, pos);
                pos = p2;
                const sup = document.createElement('span');
                sup.className = 'udaa-sup';
                sup.appendChild(a);
                container.appendChild(sup);
                continue;
            }
            if (tok.type === 'sub') {
                pos++;
                const [a, p2] = udaaParseNextAtom(tokens, pos);
                pos = p2;
                const sub = document.createElement('span');
                sub.className = 'udaa-sub';
                sub.appendChild(a);
                container.appendChild(sub);
                continue;
            }
            break;
        }
        // Unwrap if no sup/sub added
        if (!container.querySelector('.udaa-sup, .udaa-sub')) {
            wrap.appendChild(baseNode);
        } else {
            wrap.appendChild(container);
        }
        return [pos, wrap];
    }

    function udaaHandleSupSub(tokens, pos, frag, groupNode) {
        // For when we have a group fragment as base — wrap in span first
        const baseSpan = document.createElement('span');
        baseSpan.style.display = 'inline';
        baseSpan.appendChild(groupNode);

        while (pos < tokens.length) {
            const tok = tokens[pos];
            if (tok.type === 'sup') {
                pos++;
                const [a, p2] = udaaParseNextAtom(tokens, pos);
                pos = p2;
                const sup = document.createElement('span');
                sup.className = 'udaa-sup';
                sup.appendChild(a);
                baseSpan.appendChild(sup);
                continue;
            }
            if (tok.type === 'sub') {
                pos++;
                const [a, p2] = udaaParseNextAtom(tokens, pos);
                pos = p2;
                const sub = document.createElement('span');
                sub.className = 'udaa-sub';
                sub.appendChild(a);
                baseSpan.appendChild(sub);
                continue;
            }
            break;
        }
        frag.appendChild(baseSpan);
        return [pos, frag];
    }

    function udaaHandleCmd(tokens, pos) {
        const tok = tokens[pos];
        const cmd = tok.val; // e.g. '\\frac', '\\sqrt', '\\text'
        pos++;

        // Check symbol map
        if (UDAA_SYMBOLS[cmd] !== undefined) {
            const sp = document.createElement('span');
            sp.className = 'udaa-math-op';
            sp.textContent = UDAA_SYMBOLS[cmd];
            return [sp, pos];
        }

        // Named functions
        const name = cmd.slice(1); // remove backslash
        if (UDAA_FUNCS.has(name)) {
            const sp = document.createElement('span');
            sp.className = 'udaa-math-op';
            sp.style.fontStyle = 'normal';
            sp.textContent = name;
            return [sp, pos];
        }

        switch (cmd) {
            case '\\frac': {
                // \frac{num}{den}
                let numFrag, denFrag, p2, p3;
                if (pos < tokens.length && tokens[pos].type === 'lbrace') {
                    p2 = pos + 1;
                    [numFrag, p2] = udaaParseGroup(tokens, p2);
                } else {
                    [numFrag, p2] = udaaParseNextAtom(tokens, pos);
                }
                if (p2 < tokens.length && tokens[p2].type === 'lbrace') {
                    p3 = p2 + 1;
                    [denFrag, p3] = udaaParseGroup(tokens, p3);
                } else {
                    [denFrag, p3] = udaaParseNextAtom(tokens, p2);
                }
                const frac = document.createElement('span');
                frac.className = 'udaa-frac';
                const num = document.createElement('span');
                num.className = 'udaa-frac-num';
                num.appendChild(numFrag);
                const den = document.createElement('span');
                den.className = 'udaa-frac-den';
                den.appendChild(denFrag);
                frac.append(num, den);
                return [frac, p3];
            }

            case '\\sqrt': {
                // \sqrt[n]{body} or \sqrt{body}
                let nthFrag = null, bodyFrag, p2;
                if (pos < tokens.length && tokens[pos].type === 'paren' && tokens[pos].val === '[') {
                    // optional nth root
                    pos++;
                    nthFrag = document.createDocumentFragment();
                    while (pos < tokens.length) {
                        const t = tokens[pos];
                        if (t.type === 'paren' && t.val === ']') { pos++; break; }
                        const sp = document.createElement('span');
                        sp.textContent = t.val || t.type;
                        nthFrag.appendChild(sp);
                        pos++;
                    }
                    p2 = pos;
                } else {
                    p2 = pos;
                }
                if (p2 < tokens.length && tokens[p2].type === 'lbrace') {
                    p2++;
                    [bodyFrag, p2] = udaaParseGroup(tokens, p2);
                } else {
                    [bodyFrag, p2] = udaaParseNextAtom(tokens, p2);
                }
                const sqrtEl = document.createElement('span');
                sqrtEl.className = 'udaa-sqrt';
                if (nthFrag) {
                    const idx = document.createElement('span');
                    idx.className = 'udaa-sup';
                    idx.style.marginRight = '1px';
                    idx.appendChild(nthFrag);
                    sqrtEl.appendChild(idx);
                }
                const sign = document.createElement('span');
                sign.className = 'udaa-sqrt-sign';
                sign.textContent = '\u221a';
                const body = document.createElement('span');
                body.className = 'udaa-sqrt-body';
                body.appendChild(bodyFrag);
                sqrtEl.append(sign, body);
                return [sqrtEl, p2];
            }

            case '\\text': {
                let textFrag, p2;
                if (pos < tokens.length && tokens[pos].type === 'lbrace') {
                    p2 = pos + 1;
                    [textFrag, p2] = udaaParseGroup(tokens, p2);
                } else {
                    [textFrag, p2] = udaaParseNextAtom(tokens, pos);
                }
                const sp = document.createElement('span');
                sp.style.fontStyle = 'normal';
                sp.appendChild(textFrag);
                return [sp, p2];
            }

            case '\\left': {
                // \left( ... \right)
                let delimiter = '';
                if (pos < tokens.length) {
                    const dt = tokens[pos];
                    delimiter = dt.val || dt.type || '';
                    pos++;
                }
                const sp = document.createElement('span');
                sp.className = 'udaa-paren';
                sp.textContent = delimiter;
                return [sp, pos];
            }
            case '\\right': {
                let delimiter = '';
                if (pos < tokens.length) {
                    const dt = tokens[pos];
                    delimiter = dt.val || dt.type || '';
                    pos++;
                }
                const sp = document.createElement('span');
                sp.className = 'udaa-paren';
                sp.textContent = delimiter;
                return [sp, pos];
            }

            case '\\,':
            case '\\;':
            case '\\:':
            case '\\!':
            case '\\ ':
            case '\\quad':
            case '\\qquad': {
                const sp = document.createElement('span');
                sp.textContent = '\u2009';
                return [sp, pos];
            }

            case '\\\\': {
                return [document.createElement('br'), pos];
            }

            default: {
                // Unknown command — render name as-is
                const sp = document.createElement('span');
                sp.className = 'udaa-math-var';
                sp.textContent = name;
                return [sp, pos];
            }
        }
    }

    /**
     * LaTeX matnini DOM elementiga aylantirish
     * @param {string} latex - LaTeX kodi
     * @param {boolean} displayMode - true = block, false = inline
     * @returns {HTMLElement}
     */
    function udaaRenderLatex(latex, displayMode) {
        try {
            const tokens = udaaTokenize(latex.trim());
            const [frag] = udaaParseMath(tokens, 0, false);
            const wrapper = document.createElement('span');
            wrapper.className = displayMode ? 'udaa-math-block' : 'udaa-math-inline';
            if (displayMode) wrapper.style.display = 'flex';
            wrapper.appendChild(frag);
            return wrapper;
        } catch (e) {
            const fallback = document.createElement('span');
            fallback.textContent = latex;
            return fallback;
        }
    }

    /**
     * Matnni parse qilib, LaTeX formulalarni render qiladigan DOM fragment yaratish.
     * $...$ → inline, $$...$$ → block
     *
     * @param {string} text — Gemini javobi (aralash matn + LaTeX)
     * @returns {DocumentFragment}
     */
    function udaaRenderMixedText(text) {
        const frag = document.createDocumentFragment();
        if (!text) return frag;

        // $$...$$ va $...$ ni topamiz
        // Avval $$...$$, keyin $...$
        const DISPLAY_RE = /\$\$([\s\S]+?)\$\$/g;
        const INLINE_RE  = /\$((?:[^$\\]|\\.)+?)\$/g;

        // Barcha match'larni tartib bilan topamiz
        const matches = [];

        let m;
        // reset
        DISPLAY_RE.lastIndex = 0;
        while ((m = DISPLAY_RE.exec(text)) !== null) {
            matches.push({ start: m.index, end: m.index + m[0].length, latex: m[1], display: true });
        }

        INLINE_RE.lastIndex = 0;
        while ((m = INLINE_RE.exec(text)) !== null) {
            // $$...$$ bilan to'qnashmaydi
            const inside = matches.some(x => m.index >= x.start && m.index < x.end);
            if (!inside) {
                matches.push({ start: m.index, end: m.index + m[0].length, latex: m[1], display: false });
            }
        }

        // Also handle \(...\) inline and \[...\] display
        const PAREN_INLINE_RE = /\\\(([\s\S]+?)\\\)/g;
        PAREN_INLINE_RE.lastIndex = 0;
        while ((m = PAREN_INLINE_RE.exec(text)) !== null) {
            const inside = matches.some(x => m.index >= x.start && m.index < x.end);
            if (!inside) {
                matches.push({ start: m.index, end: m.index + m[0].length, latex: m[1], display: false });
            }
        }

        const BRACKET_DISPLAY_RE = /\\\[([\s\S]+?)\\\]/g;
        BRACKET_DISPLAY_RE.lastIndex = 0;
        while ((m = BRACKET_DISPLAY_RE.exec(text)) !== null) {
            const inside = matches.some(x => m.index >= x.start && m.index < x.end);
            if (!inside) {
                matches.push({ start: m.index, end: m.index + m[0].length, latex: m[1], display: true });
            }
        }

        // Tartib bo'yicha saralash
        matches.sort((a, b) => a.start - b.start);

        let cursor = 0;
        for (const match of matches) {
            // Oldingi oddiy matn
            if (match.start > cursor) {
                const plainText = text.slice(cursor, match.start);
                // Bo'lish qatorlari bo'yicha
                const lines = plainText.split('\n');
                for (let i = 0; i < lines.length; i++) {
                    if (lines[i]) {
                        frag.appendChild(document.createTextNode(lines[i]));
                    }
                    if (i < lines.length - 1) {
                        frag.appendChild(document.createElement('br'));
                    }
                }
            }
            // LaTeX render
            const rendered = udaaRenderLatex(match.latex, match.display);
            frag.appendChild(rendered);
            cursor = match.end;
        }

        // Oxirgi qoldiq matn
        if (cursor < text.length) {
            const tail = text.slice(cursor);
            const lines = tail.split('\n');
            for (let i = 0; i < lines.length; i++) {
                if (lines[i]) {
                    frag.appendChild(document.createTextNode(lines[i]));
                }
                if (i < lines.length - 1) {
                    frag.appendChild(document.createElement('br'));
                }
            }
        }

        return frag;
    }

    /**
     * answerCard uchun to'liq DOM yaratish:
     * "1.J: ..." va "2.Q: ..." qatorlari
     * LaTeX formulalari render qilinadi
     */
    function udaaBuildAnswerCardDOM(answerText, questionRow) {
        const answerLine = document.createElement('div');
        answerLine.className = 'answer-line';

        // "1.J: " prefix — oddiy matn
        const prefix = document.createTextNode('1.J: ');
        answerLine.appendChild(prefix);
        answerLine.appendChild(udaaRenderMixedText(answerText));

        const rowLine = document.createElement('div');
        rowLine.className = 'answer-line';

        // questionRow kelsa — uni ishlatamiz, bo'lmasa lineCount
        if (questionRow && String(questionRow).trim()) {
            const rowPrefix = document.createTextNode('2.Q: ');
            rowLine.appendChild(rowPrefix);
            rowLine.appendChild(udaaRenderMixedText(String(questionRow).trim()));
        } else {
            const lineCount = answerText.split('\n').filter(l => l.trim().length > 0).length;
            rowLine.textContent = '2.Q: ' + lineCount;
        }

        return { answerLine, rowLine };
    }

    // === END LaTeX Render Engine ===

    // Answer overlays use Shadow DOM so host-page CSS cannot force vertical text,
    // narrow widths, or per-character wrapping inside the notification.
    function createAnswerOverlayHost(id, edge = 'top') {
        if (!document.body) return null;
        document.getElementById(id)?.remove();

        const host = document.createElement('div');
        host.id = id;
        const hostStyles = {
            all: 'initial',
            position: 'fixed',
            top: edge === 'top' ? '12px' : 'auto',
            bottom: edge === 'bottom' ? '24px' : 'auto',
            left: '12px',
            right: 'auto',
            display: 'block',
            width: 'fit-content',
            height: 'auto',
            maxWidth: 'calc(100vw - 24px)',
            maxHeight: 'none',
            margin: '0',
            padding: '0',
            border: '0',
            background: 'transparent',
            boxShadow: 'none',
            overflow: 'visible',
            zIndex: '2147483647',
            pointerEvents: 'none',
            direction: 'ltr',
            writingMode: 'horizontal-tb',
            transform: 'none',
            contain: 'layout style'
        };
        for (const [property, value] of Object.entries(hostStyles)) {
            const cssProperty = property.replace(/[A-Z]/g, letter => '-' + letter.toLowerCase());
            host.style.setProperty(cssProperty, value, 'important');
        }

        const shadow = host.attachShadow({ mode: 'open' });
        const style = document.createElement('style');
        // Inject math styles from UDAA_MATH_CSS
        const mathStyleEl = document.createElement('style');
        mathStyleEl.textContent = UDAA_MATH_CSS;
        shadow.appendChild(mathStyleEl);

        style.textContent = `
            :host {
                all: initial;
                position: fixed;
                display: block;
                width: fit-content;
                max-width: calc(100vw - 24px);
                height: auto;
                margin: 0;
                padding: 0;
                overflow: visible;
                direction: ltr;
                writing-mode: horizontal-tb;
                pointer-events: none;
                z-index: 2147483647;
            }
            .answer-card {
                box-sizing: border-box;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                justify-content: flex-start;
                gap: 2px;
                width: max-content;
                max-width: min(900px, calc(100vw - 24px));
                min-width: min(300px, calc(100vw - 24px));
                height: auto;
                max-height: min(55vh, 520px);
                margin: 0;
                padding: 6px 8px;
                border: 0;
                border-radius: 0;
                background: #ffffff;
                color: #c46a22;
                box-shadow: none;
                font-family: Arial, sans-serif;
                font-size: 14px;
                font-weight: 500;
                line-height: 1.6;
                text-align: left;
                text-indent: 0;
                white-space: normal;
                overflow-wrap: break-word;
                word-break: normal;
                hyphens: none;
                writing-mode: horizontal-tb;
                text-orientation: mixed;
                direction: ltr;
                unicode-bidi: plaintext;
                overflow: auto;
                opacity: 0;
                transform: translateX(calc(-100% - 16px));
                transition: transform 320ms cubic-bezier(.2,.75,.25,1), opacity 260ms ease;
                pointer-events: none;
            }
            .answer-card.visible {
                opacity: 1;
                transform: translateX(0);
            }
            .answer-line {
                display: block;
                box-sizing: border-box;
                width: max-content;
                max-width: 100%;
                min-width: min(260px, calc(100vw - 32px));
                margin: 0;
                padding: 0;
                border: 0;
                background: transparent;
                color: #c46a22;
                font: inherit;
                line-height: inherit;
                text-align: left;
                white-space: pre-wrap;
                overflow-wrap: break-word;
                word-break: normal;
                hyphens: none;
                writing-mode: horizontal-tb;
                text-orientation: mixed;
                direction: ltr;
                unicode-bidi: plaintext;
            }
        `;
        const card = document.createElement('div');
        card.className = 'answer-card';
        card.setAttribute('role', 'status');
        card.setAttribute('aria-live', 'polite');
        shadow.append(style, card);
        document.body.appendChild(host);
        return { host, card };
    }

    function animateAnswerOverlayIn(card) {
        if (!card) return;
        card.classList.remove('visible');
        // Force a style/layout boundary so repeated answers replay the slide-in.
        void card.getBoundingClientRect();
        requestAnimationFrame(() => {
            if (card.isConnected) card.classList.add('visible');
        });
    }


    function runWebpageContext() {
        if (!IS_TOP_FRAME || IS_GEMINI_ORIGIN) return;

        const POPUP_WIDTH = 420;
        const GEMINI_URL = 'https://gemini.google.com/app';
        const MAX_CHAT_MESSAGES = 20;
        const POLL_MS = 3000;

        // --- Account authentication (Alt+CapsLock, one-time) ---
        // PAROLLAR FRONTENDDA SAQLANMAYDI.
        // Tekshiruv faqat Supabase Edge Function orqali serverda bajariladi.

        // Flag set to true while a login prompt is currently on screen.
        // Prevents duplicate prompts from repeated keydown events.
        let loginPromptActive = false;

        // Saves authenticated account to chrome.storage.local via background.
        function persistAuthAccount(accountName) {
            return sendBg({ type: 'NERIX_SET_AUTH_ACCOUNT', activeAccount: accountName });
        }

        // Reads authenticated account from chrome.storage.local via background.
        function readAuthAccount() {
            return sendBg({ type: 'NERIX_GET_AUTH_ACCOUNT' });
        }

        // Runs the interactive password prompt loop (called by Alt+CapsLock when not yet authenticated).
        // Uses window.prompt() for numeric password input.
        // Password verification is done server-side via Supabase Edge Function.
        async function runLoginFlow() {
            if (loginPromptActive) return;
            loginPromptActive = true;
            try {
                while (true) {
                    const entered = window.prompt('Parolni kiriting (faqat raqam):');
                    // User cancelled the prompt.
                    if (entered === null) break;
                    const trimmed = String(entered).trim();
                    if (!trimmed) {
                        window.alert("Parol kiritilmadi. Qaytadan kiriting.");
                        continue;
                    }
                    // Server-side password verification via background.js → Edge Function
                    const result = await sendBg({ type: 'NERIX_LOGIN_VERIFY', password: trimmed });
                    if (result && result.ok && result.success && result.account) {
                        // Valid password — save and initialize.
                        const accountName = result.account === 'UMAROV' ? 'Umarov' : 'Dilshod';
                        await persistAuthAccount(accountName);
                        const user = result.account; // 'UMAROV' or 'DILSHOD'
                        enterChatAs(user);
                        // Open the chat panel after successful authentication.
                        PanelManager.openChat();
                        break;
                    } else if (result && result.error === 'NETWORK_ERROR') {
                        window.alert("Server bilan bog'lanib bo'lmadi. Internet aloqasini tekshiring.");
                        break;
                    } else {
                        window.alert("Noto'g'ri parol! Qaytadan kiriting.");
                        // Loop continues — prompts again.
                    }
                }
            } finally {
                loginPromptActive = false;
            }
        }

        let currentUser = null;
        let chatIdentitySelected = false;
        let stealthPopup = null;
        let largeChatPanel = null;
        let quickReplyPanel = null;
        let siteIframe = null;
        let chatContainer = null;
        let isPopupOpen = false;
        let isLargeChatOpen = false;
        let isQuickReplyOpen = false;
        let uiBuilt = false;
        let initialChatLoadDone = false;
        let isFetchingMessages = false;
        let isSendingMessage = false;
        let isSendingQuickReply = false;
        let lastRenderedSignature = '';
        let pendingQuickReplyAfterIdentity = false;
        let pollTimer = null;
        const lastMessageIds = new Set();

        // --- Notification / unread state ---
        let unreadCount = 0;
        let previewEnabled = true;  // foydalanuvchi yoqib/o'chirishi mumkin
        const seenMessageIds = new Set(); // takroriy bildirishnomani oldini olish
        let notifBadgeEl = null;        // unread badge elementi

        let fullPageAnswerPopup = null;
        let fullPageAnswerCard = null;
        let fullPagePopupTimer = null;

        // --- Alt+Z: oxirgi Gemini javobini ko'rsatuvchi popup ---
        let lastSavedGeminiAnswer = '';
        let altZHeld = false;
        let isAltWHeld = false;

        // --- Shift+Alt: oxirgi chat xabarini ghost preview sifatida ko'rsatish ---
        let nxShiftAltHeld = false;
        let nxLastChatMsg = null; // so'nggi kelgan xabar (lastNewMsg bilan sinxron)
        let altZPopupEl = null;
        let altZPopupCard = null;

        // --- Alt+B: Broadcast panel (UMAROV owner only) ---
        let broadcastPanelEl = null;
        let isBroadcastPanelOpen = false;
        let broadcastOverlayEl = null;
        const seenBroadcastIds = new Set();

        // --- Alt+F: White Area Editor ---
        let waeActive = false;
        let waeKeydownFired = false;
        // WAE internal state
        const WAE = {
            elements: [],     // each element owns an independent top-level stacking host
            nextId: 1,
            selectedId: null,
            drawState: null,  // active draw gesture
            pendingMoveState: null, // selected element; becomes drag after 4px
            dragState: null,  // active move gesture
            resizeState: null,// active resize gesture
            animFrame: null,
            host: null,       // high-layer UI host (handles, panel, preview only)
            shadow: null,
            cursorSnapshot: null,
            gestureStyleSnapshot: null,
            gestureStyleActive: false,
            suspended: false,
            suspendReasons: new Set(),
            pointerListenersAttached: false,
            selectOptionsObserver: null,
            selectOptionsFrame: null,
            selectOptionsDropdowns: new Set(),
            selectOptionsStyleSnapshots: new Map(),
        };

        // -----------------------------------------------------------------
        // Messages from background and Gemini frame
        // -----------------------------------------------------------------
        if (globalThis.chrome?.runtime?.onMessage) {
            chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
                if (!message || typeof message.type !== 'string') return false;

                switch (message.type) {
                    case 'NERIX_TOGGLE_QUICK_REPLY':
                        // LOGIN GUARD: blocked when not authenticated
                        if (!isAuthenticated()) { showLoginRequiredNotification(); sendResponse({ ok: false, error: 'NOT_AUTHENTICATED' }); return false; }
                        toggleQuickReply();
                        sendResponse({ ok: true });
                        return false;

                    case 'NERIX_TOGGLE_GEMINI_POPUP':
                        // LOGIN GUARD: blocked when not authenticated
                        if (!isAuthenticated()) { showLoginRequiredNotification(); sendResponse({ ok: false, error: 'NOT_AUTHENTICATED' }); return false; }
                        toggleGeminiPopup();
                        sendResponse({ ok: true });
                        return false;

                    case 'NERIX_TOGGLE_CHAT':
                        // LOGIN GUARD: blocked when not authenticated
                        if (!isAuthenticated()) { showLoginRequiredNotification(); sendResponse({ ok: false, error: 'NOT_AUTHENTICATED' }); return false; }
                        PanelManager.toggleChat();
                        sendResponse({ ok: true });
                        return false;

                    case 'NERIX_BROADCAST_SHOW':
                        // UMAROV must never see any broadcast overlay.
                        // Track the ID to prevent duplicates even when suppressed,
                        // so that a later account switch cannot replay old messages.
                        if (message.id && !seenBroadcastIds.has(String(message.id))) {
                            seenBroadcastIds.add(String(message.id));
                            // Only show the overlay when the active account is NOT UMAROV.
                            if (currentUser !== 'UMAROV') {
                                showBroadcastOverlay(message.message, message.sender, message.durationMs);
                            }
                        }
                        sendResponse({ ok: true });
                        return false;

                    case 'NERIX_START_SCREENSHOT':
                        // LOGIN GUARD: blocked when not authenticated
                        if (!isAuthenticated()) { showLoginRequiredNotification(); sendResponse({ ok: false, error: 'NOT_AUTHENTICATED' }); return false; }
                        // Background command shortcuts may not reach this frame as keydown events.
                        // Suspend WAE before the background capture round-trip begins.
                        waeSuspendForShortcut('screenshot');
                        if (typeof window.__nerixStartScreenshot === 'function') {
                            // Screenshot already taken in background before overlay;
                            // background sends it here via NERIX_DELIVER_SCREENSHOT
                        } else {
                            // Trigger capture via background
                            chrome.runtime.sendMessage(
                                { type: 'NERIX_CAPTURE_TAB' },
                                (resp) => {
                                    if (resp && resp.dataUrl &&
                                        typeof window.__nerixStartScreenshot === 'function') {
                                        window.__nerixStartScreenshot(
                                            resp.dataUrl,
                                            window.innerWidth,
                                            window.innerHeight
                                        );
                                    }
                                }
                            );
                        }
                        sendResponse({ ok: true });
                        return false;

                    case 'NERIX_DELIVER_SCREENSHOT':
                        // LOGIN GUARD: blocked when not authenticated
                        if (!isAuthenticated()) { sendResponse({ ok: false, error: 'NOT_AUTHENTICATED' }); return false; }
                        if (
                            message.dataUrl &&
                            typeof window.__nerixStartScreenshot === 'function'
                        ) {
                            window.__nerixStartScreenshot(
                                message.dataUrl,
                                message.viewportWidth || window.innerWidth,
                                message.viewportHeight || window.innerHeight
                            );
                        }
                        sendResponse({ ok: true });
                        return false;

                    case 'NERIX_LOGIN_REQUIRED_NOTIFY':
                        // Background triggers this when a command is blocked due to no auth.
                        showLoginRequiredNotification();
                        sendResponse({ ok: true });
                        return false;

                    default:
                        return false;
                }
            });
        }

        window.addEventListener('message', event => {
            if (!event.data || typeof event.data.type !== 'string') return;
            if (!siteIframe || event.source !== siteIframe.contentWindow) return;
            if (event.origin !== GEMINI_TARGET_ORIGIN) return;

            const msgType = event.data.type;
            try {
                if (msgType === 'NERIX_RESPONSE_PENDING') {
                    clearFullPageAnswer();
                } else if (msgType === 'NERIX_SHOW_PARSED_ANSWER') {
                    if (!event.data.answer) {
                        console.warn('[NERIX][WARN][MESSAGE_BUS] NERIX_SHOW_PARSED_ANSWER received with empty answer field.', { payload: event.data });
                        return;
                    }
                    showFullPageAnswer(
                        event.data.answer,
                        event.data.questionRow,
                        event.data.fullText,
                        event.data.mainAnswer
                    );
                } else if (msgType === 'NERIX_ALT_Z_DOWN') {
                    waeSuspendForShortcut('alt-z');
                    altZHeld = true;
                    showAltZPopup(lastSavedGeminiAnswer);
                } else if (msgType === 'NERIX_ALT_Z_UP') {
                    altZHeld = false;
                    hideAltZPopup();
                    waeResumeAfterShortcut('alt-z');
                } else if (msgType === 'NERIX_ALT_W_DOWN') {
                    waeSuspendForShortcut('alt-w');
                    setAltWState(true);
                } else if (msgType === 'NERIX_ALT_W_UP') {
                    setAltWState(false);
                    waeResumeAfterShortcut('alt-w');
                }
            } catch (handlerErr) {
                console.error('[NERIX][ERROR][MESSAGE_HANDLER] Handler failed for message type: ' + msgType, {
                    error: handlerErr,
                    stack: handlerErr?.stack,
                    msgType
                });
            }
        });


        // -----------------------------------------------------------------
        // Smart Math/LaTeX extraction for Alt+Q
        // -----------------------------------------------------------------

        // Unicode → LaTeX symbol map
        const MATH_SYMBOL_MAP = {
            '\u2212': '-', '\u00B1': '\\pm', '\u221E': '\\infty',
            '\u2264': '\\leq', '\u2265': '\\geq', '\u2260': '\\neq',
            '\u2248': '\\approx', '\u2208': '\\in', '\u2209': '\\notin',
            '\u222A': '\\cup', '\u2229': '\\cap', '\u03C0': '\\pi',
            '\u03B1': '\\alpha', '\u03B2': '\\beta', '\u0394': '\\Delta',
            '\u03A3': '\\Sigma', '\u03B3': '\\gamma', '\u03B4': '\\delta',
            '\u03B5': '\\varepsilon', '\u03B6': '\\zeta', '\u03B7': '\\eta',
            '\u03B8': '\\theta', '\u03BB': '\\lambda', '\u03BC': '\\mu',
            '\u03BD': '\\nu', '\u03BE': '\\xi', '\u03C1': '\\rho',
            '\u03C3': '\\sigma', '\u03C4': '\\tau', '\u03C6': '\\phi',
            '\u03C8': '\\psi', '\u03C9': '\\omega', '\u00D7': '\\times',
            '\u00F7': '\\div', '\u2202': '\\partial', '\u2207': '\\nabla',
            '\u222B': '\\int', '\u220F': '\\prod', '\u221A': '\\sqrt',
            '\u2211': '\\sum', '\u2026': '\\ldots', '\u22C5': '\\cdot',
            '\u2192': '\\to', '\u2190': '\\leftarrow', '\u21D2': '\\Rightarrow',
            '\u21D0': '\\Leftarrow', '\u2200': '\\forall', '\u2203': '\\exists',
            '\u2205': '\\emptyset', '\u2282': '\\subset', '\u2283': '\\supset',
            '\u2286': '\\subseteq', '\u2287': '\\supseteq',
            '\u22A5': '\\perp', '\u2220': '\\angle',
            '\u00B0': '^{\\circ}', '\u2032': "'", '\u2033': "''",
        };

        function escapeMathSymbols(text) {
            let result = '';
            for (const ch of text) {
                result += MATH_SYMBOL_MAP[ch] || ch;
            }
            return result;
        }

        // --- MathML tag → LaTeX converter ---
        const MATHML_TAGS = new Set([
            'math','mrow','mi','mn','mo','mfrac','msqrt','mroot',
            'msup','msub','msubsup','mfenced','mover','munder',
            'munderover','mtable','mtr','mtd','mtext','mspace',
            'mstyle','merror','mpadded','mphantom','menclose',
            'semantics','annotation','annotation-xml'
        ]);

        function isMathMLElement(el) {
            if (!el || el.nodeType !== 1) return false;
            const tag = el.tagName?.toLowerCase?.() || '';
            return MATHML_TAGS.has(tag) || el.namespaceURI === 'http://www.w3.org/1998/Math/MathML';
        }

        function convertMathMLNodeToLatex(node) {
            if (!node) return '';
            if (node.nodeType === 3) return escapeMathSymbols(node.textContent || '');
            if (node.nodeType !== 1) return '';

            const tag = (node.tagName || '').toLowerCase().replace(/^m:/, '');
            const children = Array.from(node.childNodes);

            function childLatex(index) {
                if (index >= children.length) return '';
                return convertMathMLNodeToLatex(children[index]);
            }
            function allChildrenLatex() {
                return children.map(c => convertMathMLNodeToLatex(c)).join('');
            }

            switch (tag) {
                case 'math':
                case 'mrow':
                case 'mstyle':
                case 'mpadded':
                    return allChildrenLatex();

                case 'semantics': {
                    // Try annotation first
                    const annot = node.querySelector('annotation[encoding="application/x-tex"]');
                    if (annot && annot.textContent.trim()) return annot.textContent.trim();
                    // Fallback to first child
                    return children.length > 0 ? convertMathMLNodeToLatex(children[0]) : '';
                }

                case 'annotation':
                    return ''; // handled by semantics

                case 'mi':
                case 'mn':
                case 'mtext':
                    return escapeMathSymbols(node.textContent || '');

                case 'mo': {
                    const text = (node.textContent || '').trim();
                    return escapeMathSymbols(text);
                }

                case 'mfrac': {
                    if (children.length < 2) return allChildrenLatex();
                    return '\\frac{' + childLatex(0) + '}{' + childLatex(1) + '}';
                }

                case 'msqrt':
                    return '\\sqrt{' + allChildrenLatex() + '}';

                case 'mroot': {
                    if (children.length < 2) return '\\sqrt{' + allChildrenLatex() + '}';
                    return '\\sqrt[' + childLatex(1) + ']{' + childLatex(0) + '}';
                }

                case 'msup': {
                    if (children.length < 2) return allChildrenLatex();
                    const base = childLatex(0);
                    const exp = childLatex(1);
                    return '{' + base + '}^{' + exp + '}';
                }

                case 'msub': {
                    if (children.length < 2) return allChildrenLatex();
                    return '{' + childLatex(0) + '}_{' + childLatex(1) + '}';
                }

                case 'msubsup': {
                    if (children.length < 3) return allChildrenLatex();
                    return '{' + childLatex(0) + '}_{' + childLatex(1) + '}^{' + childLatex(2) + '}';
                }

                case 'mfenced': {
                    const open = node.getAttribute('open') || '(';
                    const close = node.getAttribute('close') || ')';
                    const separators = node.getAttribute('separators') || ',';
                    const inner = [];
                    for (const child of children) {
                        inner.push(convertMathMLNodeToLatex(child));
                    }
                    const sep = separators.trim().charAt(0) || ',';
                    return '\\left' + open + inner.join(sep + ' ') + '\\right' + close;
                }

                case 'mover': {
                    if (children.length < 2) return allChildrenLatex();
                    const base = childLatex(0);
                    const over = childLatex(1);
                    // Common accents
                    if (over === '\u0302' || over === '^') return '\\hat{' + base + '}';
                    if (over === '\u0304' || over === '\u00AF') return '\\bar{' + base + '}';
                    if (over === '\u02D9' || over === '.') return '\\dot{' + base + '}';
                    if (over === '\u0303' || over === '~') return '\\tilde{' + base + '}';
                    if (over === '\u2192') return '\\vec{' + base + '}';
                    return '\\overset{' + over + '}{' + base + '}';
                }

                case 'munder': {
                    if (children.length < 2) return allChildrenLatex();
                    return '\\underset{' + childLatex(1) + '}{' + childLatex(0) + '}';
                }

                case 'munderover': {
                    if (children.length < 3) return allChildrenLatex();
                    const baseUO = childLatex(0);
                    const under = childLatex(1);
                    const over = childLatex(2);
                    return '{' + baseUO + '}_{' + under + '}^{' + over + '}';
                }

                case 'mtable': {
                    const rows = [];
                    for (const child of children) {
                        if ((child.tagName || '').toLowerCase() === 'mtr') {
                            const cells = [];
                            for (const td of child.childNodes) {
                                if (td.nodeType === 1 && (td.tagName || '').toLowerCase() === 'mtd') {
                                    cells.push(convertMathMLNodeToLatex(td));
                                }
                            }
                            rows.push(cells.join(' & '));
                        }
                    }
                    return '\\begin{matrix} ' + rows.join(' \\\\ ') + ' \\end{matrix}';
                }

                case 'mtr':
                case 'mtd':
                    return allChildrenLatex();

                case 'mspace':
                    return '\\; ';

                case 'mphantom':
                    return '\\phantom{' + allChildrenLatex() + '}';

                case 'merror':
                    return '\\text{[error: ' + allChildrenLatex() + ']}';

                case 'menclose': {
                    const notation = node.getAttribute('notation') || '';
                    if (notation.includes('radical')) return '\\sqrt{' + allChildrenLatex() + '}';
                    return allChildrenLatex();
                }

                default:
                    return allChildrenLatex();
            }
        }

        function mathMLStringToLatex(markup) {
            try {
                const parser = new DOMParser();
                const doc = parser.parseFromString(
                    '<wrapper xmlns:m="http://www.w3.org/1998/Math/MathML">' + markup + '</wrapper>',
                    'text/html'
                );
                const math = doc.querySelector('math') ||
                             doc.querySelector('mrow') ||
                             doc.body;
                if (!math) return null;
                return convertMathMLNodeToLatex(math);
            } catch (e) {
                console.warn('UD/AA MathML parse error:', e);
                return null;
            }
        }


        // -----------------------------------------------------------------
        // KaTeX HTML-only parser (no MathML/annotation fallback)
        // Handles .katex-html, .msupsub, .mfrac, .sqrt, etc.
        // -----------------------------------------------------------------

        // Set of KaTeX CSS classes that are purely structural/layout
        const KATEX_SKIP_CLASSES = new Set([
            'strut', 'pstrut', 'vlist-s', 'nulldelimiter',
            'fontsize-ensurer', 'reset-size', 'svg-align',
            'frac-line', 'rule', 'hide-tail', 'halfarrow-left',
            'halfarrow-right', 'large-op', 'delimsizing',
        ]);

        function isKatexLayoutOnly(el) {
            if (!el || el.nodeType !== 1) return false;
            const tag = (el.tagName || '').toLowerCase();
            if (tag === 'img' || tag === 'svg' || tag === 'style') return true;
            const cls = el.classList;
            if (!cls) return false;
            for (const c of cls) {
                if (KATEX_SKIP_CLASSES.has(c)) return true;
            }
            // .vlist-s is a zero-width spacer
            if (cls.contains('vlist-s')) return true;
            return false;
        }

        /**
         * parseKaTeXNode(el) — recursively converts a KaTeX HTML element into LaTeX.
         * Works on .katex-html, .base, .mord, .mbin, .mrel, .mopen, .mclose,
         * .mfrac, .msupsub, .sqrt, .mop, .mpunct, and nested structures.
         */
        function parseKaTeXNode(el) {
            if (!el) return '';
            if (el.nodeType === 3) {
                // Text node — return text, map Unicode math symbols
                const t = el.textContent || '';
                // Skip whitespace-only text nodes (HTML indentation)
                if (!t.trim()) return '';
                return escapeMathSymbols(t.trim());
            }
            if (el.nodeType !== 1) return '';

            // Skip layout-only elements
            if (isKatexLayoutOnly(el)) return '';

            const cls = el.classList || new DOMTokenList();
            const tag = (el.tagName || '').toLowerCase();

            // --- .mfrac: fraction ---
            if (cls.contains('mfrac')) {
                // Structure: .mfrac > .vlist-t.vlist-t2 > .vlist-r > .vlist > children
                // The numerator and denominator are in separate .vlist rows
                // OR direct children might be .frac-line separated elements
                const numDen = extractFractionParts(el);
                if (numDen) {
                    return '\\frac{' + numDen.num + '}{' + numDen.den + '}';
                }
                // Fallback: just concat children
                return childrenLatex(el);
            }

            // --- .sqrt: square root ---
            if (cls.contains('sqrt')) {
                // .sqrt > .vlist > root content
                // May also have .root for nth root
                const rootIndex = el.querySelector(':scope > .root');
                const body = el.querySelector(':scope > .vlist-t') ||
                             el.querySelector(':scope > .vlist');
                const bodyLatex = body ? parseKaTeXNode(body) : childrenLatex(el);
                if (rootIndex) {
                    const idx = parseKaTeXNode(rootIndex);
                    return '\\sqrt[' + idx + ']{' + bodyLatex + '}';
                }
                return '\\sqrt{' + bodyLatex + '}';
            }

            // --- .msupsub: superscript and/or subscript ---
            if (cls.contains('msupsub')) {
                return parseKaTeXSupSub(el);
            }

            // --- .mopen / .mclose: delimiters ---
            if (cls.contains('mopen')) {
                const text = getKatexVisibleText(el);
                const mapped = { '(': '(', '[': '[', '{': '\\{', '|': '|', '\\lvert': '|' };
                return mapped[text] || text || '(';
            }
            if (cls.contains('mclose')) {
                const text = getKatexVisibleText(el);
                const mapped = { ')': ')', ']': ']', '}': '\\}', '|': '|', '\\rvert': '|' };
                return mapped[text] || text || ')';
            }

            // --- .mop: math operator like \sum, \int, \lim ---
            if (cls.contains('mop')) {
                const text = getKatexVisibleText(el).trim();
                const opMap = {
                    'lim': '\\lim', 'sin': '\\sin', 'cos': '\\cos', 'tan': '\\tan',
                    'log': '\\log', 'ln': '\\ln', 'max': '\\max', 'min': '\\min',
                    'sup': '\\sup', 'inf': '\\inf', 'det': '\\det', 'gcd': '\\gcd',
                    '\u2211': '\\sum', '\u220F': '\\prod', '\u222B': '\\int',
                };
                return opMap[text] || escapeMathSymbols(text);
            }

            // --- .mbin: binary operator ---
            if (cls.contains('mbin')) {
                const text = getKatexVisibleText(el);
                return escapeMathSymbols(text);
            }

            // --- .mrel: relation operator ---
            if (cls.contains('mrel')) {
                const text = getKatexVisibleText(el);
                return escapeMathSymbols(text);
            }

            // --- .mpunct: punctuation ---
            if (cls.contains('mpunct')) {
                return getKatexVisibleText(el);
            }

            // --- .mspace: spacing ---
            if (cls.contains('mspace')) {
                return ' ';
            }

            // --- .mord: ordinary math character ---
            // Could contain nested .msupsub, .mfrac, etc.
            if (cls.contains('mord')) {
                return parseKaTeXMord(el);
            }

            // --- .base: a rendering line within .katex-html ---
            if (cls.contains('base')) {
                return childrenLatex(el);
            }

            // --- .katex-html: top-level ---
            if (cls.contains('katex-html')) {
                return childrenLatex(el);
            }

            // --- .katex: top-level container ---
            if (cls.contains('katex') || cls.contains('katex-display')) {
                // Prefer .katex-mathml annotation if present
                const mathml = el.querySelector('.katex-mathml annotation[encoding="application/x-tex"]');
                if (mathml && mathml.textContent.trim()) {
                    return mathml.textContent.trim();
                }
                // Then try .katex-mathml math
                const mathmlEl = el.querySelector('.katex-mathml math');
                if (mathmlEl) {
                    const converted = convertMathMLNodeToLatex(mathmlEl);
                    if (converted) return converted;
                }
                // Fallback to HTML parsing
                const htmlPart = el.querySelector('.katex-html');
                if (htmlPart) return parseKaTeXNode(htmlPart);
                return childrenLatex(el);
            }

            // --- .editor-equation: wrapper around .katex ---
            if (cls.contains('editor-equation')) {
                const katex = el.querySelector('.katex');
                if (katex) return parseKaTeXNode(katex);
                return childrenLatex(el);
            }

            // --- .vlist, .vlist-t, .vlist-r: vertical list containers ---
            if (cls.contains('vlist') || cls.contains('vlist-t') ||
                cls.contains('vlist-t2') || cls.contains('vlist-r')) {
                return childrenLatex(el);
            }

            // --- .sizing, .mtight: sizing containers ---
            if (cls.contains('sizing') || cls.contains('mtight') ||
                cls.contains('minner')) {
                return childrenLatex(el);
            }

            // --- span with .mathnormal, .mathrm, .mathit, .mathbf ---
            if (cls.contains('mathnormal') || cls.contains('mathrm') ||
                cls.contains('mathit') || cls.contains('mathbf') ||
                cls.contains('mathbb') || cls.contains('mathcal') ||
                cls.contains('mathsf') || cls.contains('mathtt')) {
                return escapeMathSymbols(el.textContent || '');
            }

            // Generic: recurse into children
            return childrenLatex(el);
        }

        function childrenLatex(el) {
            let result = '';
            for (const child of el.childNodes) {
                result += parseKaTeXNode(child);
            }
            return result;
        }

        /**
         * Parse .mord which may be a simple character or contain
         * nested .msupsub structures
         */
        function parseKaTeXMord(el) {
            const children = Array.from(el.childNodes);

            // Simple case: just text content, no element children
            const elementChildren = children.filter(c => c.nodeType === 1);
            if (elementChildren.length === 0) {
                return escapeMathSymbols(el.textContent || '');
            }

            // Check for .msupsub as a child (base + sup/sub together)
            let result = '';
            for (const child of children) {
                if (child.nodeType === 3) {
                    result += escapeMathSymbols(child.textContent || '');
                } else if (child.nodeType === 1) {
                    if (isKatexLayoutOnly(child)) continue;
                    result += parseKaTeXNode(child);
                }
            }
            return result;
        }

        /**
         * Parse .msupsub to extract superscript and/or subscript.
         *
         * KaTeX structures for sup/sub:
         *
         * Case 1 — Sup only (.vlist-t2):
         * .msupsub > .vlist-t.vlist-t2 > .vlist-r > .vlist > [rows]
         * where rows contain the sub (bottom) and sup (top) values.
         *
         * Case 2 — Sup only (.vlist-t, no .vlist-t2):
         * .msupsub > .vlist-t > .vlist-r > .vlist > one row with sup
         *
         * The sup element typically has a negative top style (shifted up).
         * The sub element has 0 or positive top.
         */
        function parseKaTeXSupSub(el) {
            const vlistT = el.querySelector(':scope > .vlist-t');
            if (!vlistT) {
                // No vlist structure — try direct text
                return childrenLatex(el);
            }

            const hasT2 = vlistT.classList.contains('vlist-t2');
            const vlistR = vlistT.querySelector(':scope > .vlist-r');
            if (!vlistR) return childrenLatex(el);

            const vlists = vlistR.querySelectorAll(':scope > .vlist');
            if (vlists.length === 0) return childrenLatex(el);

            const mainVlist = vlists[0];
            const rows = Array.from(mainVlist.children).filter(
                c => c.nodeType === 1 && !isKatexLayoutOnly(c)
            );

            let supLatex = '';
            let subLatex = '';

            if (hasT2 && rows.length >= 2) {
                // Two rows: one subscript, one superscript.
                // KaTeX DOM order: subscript row first (less negative top),
                // superscript row second (more negative top).
                // We identify by style.top: more negative = higher = superscript.
                const parsed = rows.map(row => {
                    const topStyle = parseFloat(row.style?.top) || 0;
                    const content = parseKaTeXSupSubContent(row);
                    return { top: topStyle, content };
                });

                // Sort by top value: most negative (highest) first
                parsed.sort((a, b) => a.top - b.top);

                if (parsed.length >= 2) {
                    supLatex = parsed[0].content; // most negative top = superscript
                    subLatex = parsed[parsed.length - 1].content; // least negative = subscript
                } else if (parsed.length === 1) {
                    // Single row with .vlist-t2 — this is subscript
                    subLatex = parsed[0].content;
                }
            } else if (hasT2 && rows.length === 1) {
                // .vlist-t2 with single row = subscript only.
                // KaTeX uses .vlist-t2 for subscripts (it has a second .vlist
                // column for baseline alignment), while .vlist-t (without t2)
                // is used for superscript-only.
                const content = parseKaTeXSupSubContent(rows[0]);
                subLatex = content;
            } else if (rows.length >= 1) {
                // .vlist-t without .vlist-t2 = superscript only.
                // Single row — this is a superscript.
                const content = parseKaTeXSupSubContent(rows[0]);
                supLatex = content;
            }

            let result = '';
            if (subLatex) result += '_{' + subLatex + '}';
            if (supLatex) result += '^{' + supLatex + '}';
            return result;
        }

        /**
         * Extract the actual math content from a sup/sub row element.
         * Skips .pstrut, .sizing wrappers, and digs into .mtight.
         */
        function parseKaTeXSupSubContent(rowEl) {
            let result = '';
            for (const child of rowEl.childNodes) {
                if (child.nodeType === 3) {
                    const t = (child.textContent || '').trim();
                    if (t) result += escapeMathSymbols(t);
                    continue;
                }
                if (child.nodeType !== 1) continue;
                if (isKatexLayoutOnly(child)) continue;

                const cls = child.classList;
                if (cls?.contains?.('sizing') || cls?.contains?.('mtight')) {
                    result += childrenLatex(child);
                } else if (cls?.contains?.('mord') || cls?.contains?.('mrel') ||
                           cls?.contains?.('mbin') || cls?.contains?.('mop')) {
                    result += parseKaTeXNode(child);
                } else {
                    result += parseKaTeXNode(child);
                }
            }
            return result;
        }

        /**
         * Extract fraction parts from .mfrac element.
         * KaTeX structure:
         * .mfrac > .vlist-t.vlist-t2 > .vlist-r > .vlist > rows
         * where rows contain numerator (top) and denominator (bottom),
         * separated by .frac-line.
         */
        function extractFractionParts(mfracEl) {
            const rows = [];
            const vlist = mfracEl.querySelector('.vlist-t .vlist-r > .vlist') ||
                          mfracEl.querySelector('.vlist-t > .vlist-r > .vlist') ||
                          mfracEl.querySelector('.vlist');
            if (!vlist) return null;

            for (const child of vlist.children) {
                if (child.nodeType !== 1) continue;
                if (isKatexLayoutOnly(child)) continue;
                if (child.classList?.contains?.('frac-line')) continue;
                // Skip .vlist-s spacers
                if (child.classList?.contains?.('vlist-s')) continue;

                const content = parseKaTeXSupSubContent(child);
                if (content || content === '0') rows.push(content);
            }

            if (rows.length >= 2) {
                // In KaTeX fraction DOM, numerator is first, denominator is second
                return { num: rows[0], den: rows[1] };
            }
            return null;
        }

        /**
         * Get visible text from a KaTeX element, skipping layout nodes.
         */
        function getKatexVisibleText(el) {
            if (!el) return '';
            if (el.nodeType === 3) return el.textContent || '';
            if (el.nodeType !== 1) return '';
            if (isKatexLayoutOnly(el)) return '';
            let text = '';
            for (const child of el.childNodes) {
                text += getKatexVisibleText(child);
            }
            return text;
        }


        function extractLatexFromMathElement(element) {
            if (!element || element.nodeType !== 1) {
                return { latex: null, source: 'none', exact: false, display: false, warning: 'Not an element' };
            }

            const isDisplay = element.getAttribute('display') === 'block' ||
                              element.classList?.contains?.('display') ||
                              element.closest?.('[display="block"]') !== null;

            // Priority 1: data-latex / data-tex attribute
            const dataLatex = element.getAttribute('data-latex') ||
                              element.getAttribute('data-tex') ||
                              element.closest?.('[data-latex]')?.getAttribute('data-latex') ||
                              element.closest?.('[data-tex]')?.getAttribute('data-tex');
            if (dataLatex) {
                return { latex: dataLatex, source: 'data-tex', exact: true, display: isDisplay };
            }

            // Priority 2: annotation[encoding="application/x-tex"]
            const annotation = element.querySelector?.('annotation[encoding="application/x-tex"]');
            if (annotation && annotation.textContent.trim()) {
                return { latex: annotation.textContent.trim(), source: 'annotation', exact: true, display: isDisplay };
            }

            // Priority 3: MathJax original TeX script
            const mjxId = element.getAttribute?.('data-mjx-texcode') ||
                          element.id;
            if (mjxId) {
                const texScript = document.querySelector(
                    'script[type^="math/tex"][id="' + mjxId + '"],' +
                    'script[type^="math/tex"][data-target="' + mjxId + '"]'
                );
                if (texScript && texScript.textContent.trim()) {
                    return { latex: texScript.textContent.trim(), source: 'mathjax', exact: true, display: isDisplay };
                }
            }
            // Try nearby script tags
            const prevSib = element.previousElementSibling;
            if (prevSib && prevSib.tagName === 'SCRIPT' &&
                (prevSib.type || '').startsWith('math/tex') &&
                prevSib.textContent.trim()) {
                return { latex: prevSib.textContent.trim(), source: 'mathjax', exact: true, display: isDisplay };
            }

            // Priority 4: data-mathml attribute
            const dataMathML = element.getAttribute('data-mathml');
            if (dataMathML) {
                const latex = mathMLStringToLatex(dataMathML);
                if (latex) return { latex, source: 'data-mathml', exact: false, display: isDisplay };
            }

            // Priority 5: DOM MathML elements
            const mathEl = element.tagName?.toLowerCase() === 'math' ? element :
                           element.querySelector?.('math');
            if (mathEl) {
                const latex = convertMathMLNodeToLatex(mathEl);
                if (latex) return { latex, source: 'mathml', exact: false, display: isDisplay };
            }

            // Priority 6: KaTeX MathML inside .katex-mathml
            const katexMathML = element.querySelector?.('.katex-mathml math') ||
                                element.closest?.('.katex')?.querySelector?.('.katex-mathml math');
            if (katexMathML) {
                // Check annotation first
                const katexAnnot = katexMathML.querySelector('annotation[encoding="application/x-tex"]');
                if (katexAnnot && katexAnnot.textContent.trim()) {
                    return { latex: katexAnnot.textContent.trim(), source: 'katex', exact: true, display: isDisplay };
                }
                const latex = convertMathMLNodeToLatex(katexMathML);
                if (latex) return { latex, source: 'katex-mathml', exact: false, display: isDisplay };
            }

            // Priority 7: MathJax assistive MML
            const mjxMml = element.querySelector?.('mjx-assistive-mml math');
            if (mjxMml) {
                const latex = convertMathMLNodeToLatex(mjxMml);
                if (latex) return { latex, source: 'mathjax-mml', exact: false, display: isDisplay };
            }

            // Priority 8: KaTeX HTML-only parsing (no MathML available)
            const katexHtml = element.querySelector?.('.katex-html') ||
                              (element.classList?.contains?.('katex-html') ? element : null) ||
                              element.closest?.('.katex')?.querySelector?.('.katex-html') ||
                              (element.classList?.contains?.('editor-equation') ? element.querySelector?.('.katex-html') || element.querySelector?.('.katex') : null);
            if (katexHtml) {
                try {
                    const latex = parseKaTeXNode(katexHtml);
                    if (latex && latex.trim()) {
                        return { latex: latex.trim().replace(/\s+/g, ' '), source: 'katex-html', exact: false, display: isDisplay };
                    }
                } catch (e) {
                    console.warn('UD/AA: KaTeX HTML parse error:', e);
                }
            }

            // Priority 9: .editor-equation without .katex wrapper
            if (element.classList?.contains?.('editor-equation')) {
                try {
                    const latex = parseKaTeXNode(element);
                    if (latex && latex.trim()) {
                        return { latex: latex.trim().replace(/\s+/g, ' '), source: 'editor-equation', exact: false, display: isDisplay };
                    }
                } catch (e) {
                    console.warn('UD/AA: editor-equation parse error:', e);
                }
            }

            return { latex: null, source: 'visual-fallback', exact: false, display: false,
                     warning: 'Formula source unavailable' };
        }

        // --- Detect if a DOM element is a math container ---
        function isMathContainer(el) {
            if (!el || el.nodeType !== 1) return false;
            const tag = (el.tagName || '').toLowerCase();

            // MathML
            if (isMathMLElement(el)) return true;

            // KaTeX
            if (el.classList?.contains?.('katex') ||
                el.classList?.contains?.('katex-display') ||
                el.classList?.contains?.('editor-equation')) return true;

            // .katex-html without .katex parent (rare but possible in fragments)
            if (el.classList?.contains?.('katex-html')) return true;

            // MathJax
            if (tag === 'mjx-container' || tag === 'mjx-math') return true;

            // data attributes
            if (el.hasAttribute?.('data-latex') || el.hasAttribute?.('data-tex') ||
                el.hasAttribute?.('data-mathml')) return true;

            // script type math/tex
            if (tag === 'script' && (el.type || '').startsWith('math/tex')) return true;

            return false;
        }

        function findMathAncestor(el) {
            let node = el;
            while (node) {
                if (isMathContainer(node)) return node;
                if (node.parentElement && isMathContainer(node.parentElement)) return node.parentElement;
                node = node.parentElement;
            }
            return null;
        }

        // -----------------------------------------------------------------
        // Table → Markdown helper
        // -----------------------------------------------------------------

        /**
         * Extract the text content of a single table cell (td/th),
         * handling:
         *  - Nested math formulae (KaTeX / MathML)
         *  - <select> dropdowns (shows selected option or placeholder)
         *  - Custom dropdown widgets (.MaD7T, .MQpzF, .DtVSJ, .qBIhg and similar)
         *  - Plain text
         */
        function getCellContent(cellEl) {
            if (!cellEl) return '';

            const parts = [];
            const processedMath = new Set();

            function walkCell(node) {
                if (!node) return;

                // Text node
                if (node.nodeType === 3) {
                    const t = (node.textContent || '').replace(/\s+/g, ' ');
                    if (t.trim()) parts.push(t.trim());
                    return;
                }
                if (node.nodeType !== 1) return;

                const tag = (node.tagName || '').toLowerCase();
                const cls = node.classList;

                // Skip decorative/layout
                if (tag === 'style' || tag === 'script' || tag === 'link') return;
                if (tag === 'svg') return; // decorative icons

                // Native <select>
                if (tag === 'select') {
                    const selected = node.options?.[node.selectedIndex];
                    if (selected && selected.value && selected.value !== '' &&
                        selected.text && selected.text.trim() && selected.text !== '–') {
                        parts.push(selected.text.trim());
                    } else {
                        parts.push('[Javobni tanlang]');
                    }
                    return;
                }

                // Custom dropdown widgets (typical platform patterns)
                // Check for elements that look like drop-down triggers/containers
                const isDropdownWidget =
                    (tag === 'button' || tag === 'div' || tag === 'span') && (
                        cls?.contains?.('MaD7T') || cls?.contains?.('MQpzF') ||
                        cls?.contains?.('DtVSJ') || cls?.contains?.('qBIhg') ||
                        node.getAttribute('role') === 'combobox' ||
                        node.getAttribute('role') === 'listbox' ||
                        node.getAttribute('aria-haspopup') === 'listbox' ||
                        node.getAttribute('aria-haspopup') === 'true' ||
                        node.getAttribute('data-placeholder') !== null
                    );

                if (isDropdownWidget) {
                    // Try to get the currently displayed value
                    const placeholder = node.getAttribute('data-placeholder') ||
                                        node.getAttribute('placeholder');
                    const displayText = (node.textContent || '').trim();
                    const isPlaceholder = !displayText ||
                        displayText === placeholder ||
                        displayText === 'Javobni tanlang' ||
                        displayText === 'Выберите ответ' ||
                        displayText === 'Select answer' ||
                        displayText === '–' || displayText === '-';
                    if (isPlaceholder) {
                        parts.push('[Javobni tanlang]');
                    } else {
                        parts.push(displayText);
                    }
                    return;
                }

                // Math container
                if (isMathContainer(node)) {
                    const key = node.outerHTML?.substring(0, 200) || node.textContent;
                    if (processedMath.has(key)) return;
                    processedMath.add(key);
                    const result = extractLatexFromMathElement(node);
                    if (result && result.latex) {
                        if (result.display) {
                            parts.push('\\[' + result.latex + '\\]');
                        } else {
                            parts.push('\\(' + result.latex + '\\)');
                        }
                    } else {
                        const fb = (node.textContent || '').trim();
                        if (fb) parts.push(fb);
                    }
                    return;
                }

                // Skip .katex-mathml / .katex-html children (handled by .katex parent)
                if (cls?.contains?.('katex-mathml') || cls?.contains?.('katex-html')) {
                    if (node.parentElement?.classList?.contains?.('katex')) return;
                }

                for (const child of node.childNodes) {
                    walkCell(child);
                }
            }

            walkCell(cellEl);

            return parts.join(' ').replace(/\s{2,}/g, ' ').trim();
        }

        /**
         * Convert an HTML <table> element to a Markdown table string.
         * Handles colspan/rowspan by duplicating cells (simplified).
         * Returns null if the table has no extractable content.
         */
        function extractTableToMarkdown(tableEl) {
            if (!tableEl) return null;

            // Collect all rows from thead, tbody, tfoot, or direct tr
            const allRows = [];
            const sections = tableEl.querySelectorAll('thead, tbody, tfoot');
            if (sections.length > 0) {
                for (const section of sections) {
                    for (const row of section.querySelectorAll('tr')) {
                        allRows.push(row);
                    }
                }
            } else {
                for (const row of tableEl.querySelectorAll('tr')) {
                    allRows.push(row);
                }
            }

            if (allRows.length === 0) return null;

            // Build rows as arrays of cell content strings
            const tableData = [];
            for (const row of allRows) {
                const cells = Array.from(row.querySelectorAll('td, th'));
                if (cells.length === 0) continue;
                const rowData = cells.map(cell => getCellContent(cell));
                tableData.push(rowData);
            }

            if (tableData.length === 0) return null;

            // Determine column count (max across all rows)
            const colCount = Math.max(...tableData.map(r => r.length));
            if (colCount === 0) return null;

            // Pad short rows
            for (const row of tableData) {
                while (row.length < colCount) row.push('');
            }

            // Build Markdown
            const lines = [];

            // First row as header
            const header = tableData[0];
            lines.push('| ' + header.join(' | ') + ' |');
            lines.push('|' + header.map(() => '---|').join(''));

            // Rest as data rows
            for (let i = 1; i < tableData.length; i++) {
                lines.push('| ' + tableData[i].join(' | ') + ' |');
            }

            // If only one row, there's no separator needed (treat single row as data)
            // But Markdown table requires header + separator, so for a single-row table:
            if (tableData.length === 1) {
                // Re-emit as a data row with a blank header
                const blankHeader = header.map(() => '');
                const mdLines = [];
                mdLines.push('| ' + blankHeader.join(' | ') + ' |');
                mdLines.push('|' + blankHeader.map(() => '---|').join(''));
                mdLines.push('| ' + header.join(' | ') + ' |');
                return mdLines.join('\n');
            }

            return lines.join('\n');
        }

        // --- Smart text extraction from selection Range ---
        function extractSmartContent(selection) {
            if (!selection || selection.rangeCount === 0) return '';

            const range = selection.getRangeAt(0);
            const fragment = range.cloneContents();

            // Quick check: is there any math content?
            const hasMathContent = fragment.querySelector(
                'math, .katex, .katex-display, .katex-html, mjx-container, ' +
                '[data-latex], [data-tex], [data-mathml], .editor-equation, ' +
                'script[type^="math/tex"], annotation[encoding="application/x-tex"], ' +
                '.msupsub, .mfrac, .mord > .msupsub'
            );

            // If no math, return plain text unchanged (original behavior)
            if (!hasMathContent) {
                return String(selection).trim();
            }

            // Walk the original DOM range to preserve structure
            const parts = [];
            const processedMathRoots = new Set();

            function walkNode(node) {
                if (!node) return;

                // Text node
                if (node.nodeType === 3) {
                    const text = node.textContent || '';
                    if (text.trim()) parts.push(text);
                    else if (text.includes('\n')) parts.push('\n');
                    else if (parts.length > 0 && text.includes(' ')) parts.push(' ');
                    return;
                }

                if (node.nodeType !== 1) return;

                // Skip hidden elements and decorative content
                const tag = (node.tagName || '').toLowerCase();
                if (tag === 'script' && !(node.type || '').startsWith('math/tex')) return;
                if (tag === 'style' || tag === 'link') return;
                if (tag === 'img' || tag === 'svg') {
                    // Check if it's a math-related SVG (MathJax)
                    if (!node.closest?.('mjx-container') && !node.closest?.('.katex')) return;
                }

                // Math container detection
                if (isMathContainer(node)) {
                    // Prevent duplicates
                    const mathKey = node.outerHTML?.substring(0, 200) || node.textContent;
                    if (processedMathRoots.has(mathKey)) return;
                    processedMathRoots.add(mathKey);

                    // Look for the original element in the live DOM (fragment loses context)
                    const result = extractLatexFromElement_InLiveDOM(node, range);
                    if (result && result.latex) {
                        if (result.display) {
                            parts.push('\n\\[\n' + result.latex + '\n\\]\n');
                        } else {
                            parts.push('\\(' + result.latex + '\\)');
                        }
                    } else if (result && result.warning) {
                        // Can't extract reliably, use text content
                        const fallback = (node.textContent || '').trim();
                        if (fallback) parts.push(fallback);
                    }
                    return;
                }

                // KaTeX .katex-html sibling (already processed via .katex parent)
                if (node.classList?.contains?.('katex-html') &&
                    node.parentElement?.classList?.contains?.('katex')) {
                    return; // Skip, .katex parent handled it
                }
                if (node.classList?.contains?.('katex-mathml')) {
                    return; // Skip, .katex parent handled it
                }

                // .msupsub or .mfrac appearing outside a recognized math container
                // (e.g., partial KaTeX structure in selection fragment)
                if ((node.classList?.contains?.('msupsub') ||
                     node.classList?.contains?.('mfrac') ||
                     node.classList?.contains?.('sqrt')) &&
                    !node.closest?.('.katex, .katex-html, .editor-equation')) {
                    // This is an orphaned KaTeX element — try to parse it
                    try {
                        const orphanLatex = parseKaTeXNode(node);
                        if (orphanLatex) {
                            parts.push(orphanLatex);
                            return;
                        }
                    } catch (_) {}
                }

                // --- TABLE: convert to Markdown, skip inner node walking ---
                if (tag === 'table') {
                    if (parts.length > 0) {
                        const last = parts[parts.length - 1];
                        if (last && last !== '\n' && !last.endsWith('\n')) parts.push('\n');
                    }
                    // Try to find the live table element for dropdown access
                    let liveTable = node;
                    try {
                        const container = range.commonAncestorContainer;
                        const root = container.nodeType === 1 ? container : container.parentElement;
                        if (root) {
                            const liveTables = Array.from(root.querySelectorAll('table')).filter(t => {
                                try { return range.intersectsNode(t); } catch (_) { return false; }
                            });
                            if (liveTables.length > 0) {
                                const fragRows = node.querySelectorAll('tr').length;
                                liveTable = liveTables.find(t => t.querySelectorAll('tr').length === fragRows)
                                            || liveTables[0];
                            }
                        }
                    } catch (_) {}

                    const mdTable = extractTableToMarkdown(liveTable);
                    if (mdTable) {
                        parts.push(mdTable);
                        parts.push('\n');
                    } else {
                        for (const child of node.childNodes) { walkNode(child); }
                    }
                    return;
                }

                // Skip td/th/tr/thead/tbody/tfoot — handled by extractTableToMarkdown above.
                // If orphaned, handle gracefully.
                if (tag === 'td' || tag === 'th') {
                    const cellContent = getCellContent(node);
                    if (cellContent) parts.push(cellContent + '\t');
                    return;
                }
                if (tag === 'tr' || tag === 'thead' || tag === 'tbody' || tag === 'tfoot') {
                    for (const child of node.childNodes) { walkNode(child); }
                    parts.push('\n');
                    return;
                }

                // Block elements add line breaks
                const isBlock = /^(p|div|h[1-6]|li|br|hr|blockquote|section|article|pre|ol|ul|dd|dt|dl|figcaption)$/.test(tag);
                if (isBlock && parts.length > 0) {
                    const last = parts[parts.length - 1];
                    if (last && last !== '\n' && !last.endsWith('\n')) parts.push('\n');
                }
                if (tag === 'br') { parts.push('\n'); return; }

                // List items
                if (tag === 'li') {
                    const parent = node.parentElement;
                    if (parent && parent.tagName?.toLowerCase() === 'ol') {
                        const idx = Array.from(parent.children).indexOf(node) + 1;
                        parts.push(idx + '. ');
                    }
                }

                // Recurse into children
                for (const child of node.childNodes) {
                    walkNode(child);
                }

                if (isBlock) {
                    const last = parts[parts.length - 1];
                    if (last && last !== '\n' && !last.endsWith('\n')) parts.push('\n');
                }
            }

            // Try to find math elements in the original live DOM
            function extractLatexFromElement_InLiveDOM(fragmentNode, selRange) {
                // The fragment is a copy; we need to find the matching element in
                // the live document to access sibling scripts, parents, etc.

                // Strategy: search the live DOM around the selection
                const container = selRange.commonAncestorContainer;
                const root = container.nodeType === 1 ? container : container.parentElement;
                if (!root) return extractLatexFromMathElement(fragmentNode);

                // Try to find matching live element by class / tag
                const fragTag = (fragmentNode.tagName || '').toLowerCase();
                const fragClass = fragmentNode.className || '';

                let candidates = [];
                if (fragClass && typeof fragClass === 'string') {
                    const mainClass = fragClass.split(/\s+/)[0];
                    if (mainClass) {
                        try {
                            candidates = Array.from(root.querySelectorAll('.' + CSS.escape(mainClass)));
                        } catch (_) {}
                    }
                }
                if (candidates.length === 0 && fragTag) {
                    candidates = Array.from(root.querySelectorAll(fragTag));
                }

                // IMPROVED: use range.intersectsNode() to narrow down to elements
                // actually inside the selection, before falling back to text matching.
                const intersecting = candidates.filter(c => {
                    try { return selRange.intersectsNode(c); } catch (_) { return false; }
                });

                if (intersecting.length === 1) {
                    return extractLatexFromMathElement(intersecting[0]);
                }

                if (intersecting.length > 1) {
                    // Multiple formulas in selection — match by text content
                    const fragText = (fragmentNode.textContent || '').trim().substring(0, 80);
                    for (const cand of intersecting) {
                        const candText = (cand.textContent || '').trim().substring(0, 80);
                        if (fragText && candText &&
                            (candText === fragText || fragText.includes(candText) || candText.includes(fragText))) {
                            return extractLatexFromMathElement(cand);
                        }
                    }
                    // Text match failed — return first intersecting candidate
                    return extractLatexFromMathElement(intersecting[0]);
                }

                // No intersecting candidates found — try text matching against all
                const fragText = (fragmentNode.textContent || '').trim().substring(0, 80);
                for (const cand of candidates) {
                    const candText = (cand.textContent || '').trim().substring(0, 80);
                    if (fragText && candText &&
                        (candText === fragText || fragText.includes(candText) || candText.includes(fragText))) {
                        return extractLatexFromMathElement(cand);
                    }
                }

                // Final fallback: use fragment node directly (cloneContents preserves inner HTML)
                return extractLatexFromMathElement(fragmentNode);
            }

            // FIXED: fragment is a DocumentFragment (nodeType 11), not an Element (nodeType 1).
            // walkNode(fragment) returned immediately because nodeType !== 1.
            // Must iterate its children directly.
            for (const child of fragment.childNodes) {
                walkNode(child);
            }

            // Clean up result
            let result = parts.join('')
                .replace(/\n{3,}/g, '\n\n')    // max 2 consecutive newlines
                .replace(/[ \t]{2,}/g, ' ')     // collapse spaces
                .trim();

            return result;
        }

        // --- Validate extracted content ---
        function validateLatexContent(text) {
            if (!text) return { valid: false, error: 'EMPTY_SELECTION' };

            // Check balanced braces
            let braceCount = 0;
            let inCommand = false;
            for (let i = 0; i < text.length; i++) {
                const ch = text[i];
                if (ch === '\\') { inCommand = true; continue; }
                if (inCommand) { inCommand = false; continue; }
                if (ch === '{') braceCount++;
                else if (ch === '}') braceCount--;
                if (braceCount < 0) return { valid: false, error: 'INVALID_LATEX_BRACES' };
            }
            if (braceCount !== 0) return { valid: false, error: 'INVALID_LATEX_BRACES' };

            // Check for duplicate formula wrappers
            if (/\\\(\s*\\\(/.test(text) || /\\\[\s*\\\[/.test(text)) {
                return { valid: false, error: 'DUPLICATE_MATH_EXTRACTION' };
            }

            return { valid: true };
        }


        // -----------------------------------------------------------------
        // Shadow DOM overlay host for UI isolation
        // -----------------------------------------------------------------
        let nxOverlayHost = null;
        let nxShadowRoot = null;

        // Helper: query by ID inside the shadow root (falls back to document)
        function nxById(id) {
            if (nxShadowRoot) return nxShadowRoot.getElementById(id);
            return document.getElementById(id);
        }

        // -----------------------------------------------------------------
        // Styling
        // -----------------------------------------------------------------
        function injectStyles() {
            if (document.getElementById('nerix-styles-injected')) return;

            // Mark that we've started injection (in document scope for dedup)
            const marker = document.createElement('meta');
            marker.id = 'nerix-styles-injected';
            (document.head || document.documentElement).appendChild(marker);

            const fontLink = document.createElement('link');
            fontLink.rel = 'stylesheet';
            fontLink.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap';
            fontLink.onerror = () => console.warn('UD/AA: Google Fonts yuklanmadi. System font ishlatiladi.');
            (document.head || document.documentElement).appendChild(fontLink);

            const iconLink = document.createElement('link');
            iconLink.rel = 'stylesheet';
            iconLink.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
            iconLink.onerror = () => console.warn('UD/AA: Font Awesome yuklanmadi.');
            (document.head || document.documentElement).appendChild(iconLink);

            // Create the isolated overlay host with Shadow DOM
            // This host sits directly on <html> and covers the viewport
            // with position:fixed so no website CSS can push it into document flow.
            if (!nxOverlayHost) {
                nxOverlayHost = document.createElement('div');
                nxOverlayHost.id = 'nerix-overlay-host';
                // Set a comprehensive reset + fixed positioning using cssText
                // so that website global CSS cannot override these.
                nxOverlayHost.setAttribute('style', [
                    'all:initial',
                    'position:fixed',
                    'top:0',
                    'left:0',
                    'width:0',
                    'height:0',
                    'min-width:0',
                    'min-height:0',
                    'max-width:none',
                    'max-height:none',
                    'overflow:visible',
                    'z-index:2147483647',
                    'pointer-events:none',
                    'margin:0',
                    'padding:0',
                    'border:none',
                    'background:transparent',
                    'display:block',
                    'box-sizing:border-box',
                    'transform:none',
                    'filter:none',
                    'opacity:1',
                    'visibility:visible',
                    'contain:none',
                    'isolation:isolate',
                ].join(';'));

                nxShadowRoot = nxOverlayHost.attachShadow({ mode: 'open' });

                // Font links must be duplicated inside shadow root for fonts to work
                const shadowFontLink = document.createElement('link');
                shadowFontLink.rel = 'stylesheet';
                shadowFontLink.href = 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap';
                nxShadowRoot.appendChild(shadowFontLink);

                const shadowIconLink = document.createElement('link');
                shadowIconLink.rel = 'stylesheet';
                shadowIconLink.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
                nxShadowRoot.appendChild(shadowIconLink);

                document.documentElement.appendChild(nxOverlayHost);
            }

            // Guard: never insert a second style block into the shadow root.
            if (nxShadowRoot && nxShadowRoot.getElementById('nerix-styles')) return;

            const style = document.createElement('style');
            style.id = 'nerix-styles';
            style.textContent = `
                :root, :host {
                    --nx-bg:#F5F5F5; --nx-surface:#FFFFFF; --nx-lavender:#EEEDF8;
                    --nx-accent:#5452D3; --nx-accent-dark:#3E3CAD; --nx-text:#1A1A2E;
                    --nx-muted:#8A8A9A; --nx-border:#E0E0E8; --nx-bubble-own:#5452D3;
                    --nx-bubble-in:#FFFFFF;
                }
                #nerix-stealth-popup {
                    position:fixed; top:2vh; right:-${POPUP_WIDTH + 30}px; width:${POPUP_WIDTH}px; height:96vh;
                    background:rgba(247,246,251,.94); backdrop-filter:blur(18px) saturate(140%);
                    -webkit-backdrop-filter:blur(18px) saturate(140%); border-radius:14px 0 0 14px;
                    z-index:2147483640; box-shadow:-4px 0 32px rgba(169,155,203,.18),0 8px 40px rgba(80,60,120,.10);
                    border:1.5px solid var(--nx-border); border-right:none; transition:right .42s cubic-bezier(.2,.8,.2,1),opacity .2s ease;
                    display:flex; flex-direction:column; overflow:hidden; font-family:Poppins,sans-serif;
                    color:var(--nx-text); pointer-events:none; opacity:0;
                }
                #nerix-stealth-popup.popup-open { pointer-events:auto; opacity:.18; }
                #nerix-stealth-popup.popup-open:hover { opacity:.82; }
                #nerix-stealth-popup.popup-open:focus-within { opacity:.92; }

                #nerix-iframe-container { flex:1; min-height:0; position:relative; background:transparent; }
                #nerix-iframe { width:100%; height:100%; border:0!important; display:block; background:transparent!important; }

                #nerix-large-chat {
                    position:fixed; top:8vh; left:-520px; width:400px; height:80vh; background:#F0F2F8;
                    border-radius:18px; z-index:2147483647; display:flex; flex-direction:column; overflow:hidden;
                    box-shadow:0 10px 48px rgba(84,82,211,.18),0 2px 16px rgba(84,82,211,.08);
                    border:1px solid #DDD; opacity:0; pointer-events:none;
                    transition:left .42s cubic-bezier(.2,.8,.2,1),opacity .2s ease;
                    font-family:Poppins,sans-serif; color:var(--nx-text);
                }
                #nerix-large-chat.open { left:20px; opacity:.18; pointer-events:auto; }
                #nerix-large-chat.open:hover { opacity:.88; }
                #nerix-large-chat.open:focus-within { opacity:.96; }
                @media (hover:none) {
                    #nerix-stealth-popup.popup-open,#nerix-large-chat.open { opacity:.82!important; }
                }
                .chat-header {
                    background:#FFFFFF; padding:0 16px; height:60px; font-weight:600; font-size:15px;
                    display:flex; justify-content:space-between; align-items:center;
                    border-bottom:1px solid #EBEBEB; gap:8px; flex-shrink:0;
                    box-shadow:0 1px 4px rgba(84,82,211,.06);
                }
                .chat-header-title { display:flex; align-items:center; gap:10px; min-width:0; flex:1; }
                .chat-header-title i { color:var(--nx-accent); font-size:15px; }

                /* Telegram-style header avatar */
                .nx-chat-avatar {
                    width:38px; height:38px; border-radius:50%; background:linear-gradient(135deg,#5452D3,#7B79E8);
                    display:flex; align-items:center; justify-content:center; flex-shrink:0;
                    color:#fff; font-size:15px; font-weight:700; letter-spacing:.5px;
                    box-shadow:0 2px 8px rgba(84,82,211,.3);
                }
                .nx-chat-name-wrap { display:flex; flex-direction:column; min-width:0; }
                .nx-chat-name {
                    font-size:15px; font-weight:700; color:#1A1A2E; white-space:nowrap;
                    overflow:hidden; text-overflow:ellipsis; line-height:1.2;
                }
                .nx-chat-status { font-size:11px; color:var(--nx-muted); font-weight:400; }

                /* Header action buttons */
                .nx-hdr-btn {
                    background:none; border:none; cursor:pointer; border-radius:50%;
                    width:34px; height:34px; display:flex; align-items:center; justify-content:center;
                    color:var(--nx-muted); font-size:16px; transition:background .15s, color .15s;
                    flex-shrink:0; padding:0;
                }
                .nx-hdr-btn:hover { background:#F0F0F8; color:#5452D3; }
                .nx-hdr-btn.nx-delete-btn:hover { color:#E05A5A; background:#FEF0F0; }

                .chat-header-identity { font-size:11px; color:var(--nx-accent-dark); background:var(--nx-lavender); padding:3px 9px; border-radius:10px; white-space:nowrap; cursor:default; transition:background .2s; font-weight:600; border:1px solid #d0c8ee; }

                /* --- Unread badge (chat sarlavha yonida) --- */
                #nerix-unread-badge {
                    display:none; background:#E05A5A; color:#fff; font-size:10px; font-weight:700;
                    min-width:18px; height:18px; border-radius:9px; padding:0 5px;
                    align-items:center; justify-content:center; line-height:1;
                    box-shadow:0 1px 4px rgba(224,90,90,.4); flex-shrink:0;
                }
                #nerix-unread-badge.visible { display:flex; }

                /* --- Preview toggle button --- */
                #nerix-preview-toggle {
                    font-size:10px; color:var(--nx-muted); background:none; border:1px solid var(--nx-border);
                    border-radius:8px; padding:2px 8px; cursor:pointer; font-family:Poppins,sans-serif;
                    transition:background .15s,color .15s; flex-shrink:0; white-space:nowrap;
                }
                #nerix-preview-toggle.on { background:var(--nx-lavender); color:var(--nx-accent-dark); border-color:#d0c8ee; }
                #nerix-preview-toggle:hover { background:var(--nx-lavender); }

                /* --- Chat body & bubbles --- */
                .chat-body {
                    flex:1; padding:12px 14px; overflow-y:auto; display:flex; flex-direction:column; gap:4px;
                    background:#F0F2F8; min-height:0;
                }
                .chat-body::-webkit-scrollbar { width:4px; }
                .chat-body::-webkit-scrollbar-thumb { background:#C8CCE0; border-radius:4px; }

                /* Date separator */
                .nx-date-sep {
                    display:flex; align-items:center; justify-content:center; margin:10px 0 6px;
                }
                .nx-date-sep span {
                    font-size:10.5px; color:var(--nx-muted); background:rgba(255,255,255,.8);
                    padding:2px 12px; border-radius:10px; font-weight:500;
                    box-shadow:0 1px 3px rgba(0,0,0,.06);
                }

                .message-row { display:flex; flex-direction:column; margin:1px 0; max-width:100%; }
                .message-row.me { align-items:flex-end; }
                .message-row.them { align-items:flex-start; }
                .msg-sender {
                    font-size:10.5px; font-weight:700; color:#5452D3; letter-spacing:.2px;
                    margin:0 6px 2px; display:none;
                }
                .message-row.them .msg-sender { display:block; }

                /* Consecutive message grouping — reduce top margin */
                .message-row.nx-grouped { margin-top:1px; }

                .message-bubble {
                    max-width:78%; padding:9px 13px 7px; border-radius:18px 18px 18px 4px;
                    background:#FFFFFF; color:#1A1A2E;
                    box-shadow:0 1px 2px rgba(0,0,0,.08);
                    border:1px solid #EBEBEB;
                    display:flex; flex-direction:column; gap:1px; font-size:13.5px; line-height:1.5;
                    word-break:break-word; white-space:pre-wrap;
                }
                .message-bubble.me {
                    background:#5452D3; color:#FFFFFF;
                    border-radius:18px 18px 4px 18px;
                    border-color:transparent;
                    box-shadow:0 2px 8px rgba(84,82,211,.35);
                }
                .msg-text { word-break:break-word; white-space:pre-wrap; font-size:13.5px; font-weight:400; overflow-wrap:anywhere; }
                .message-bubble.me .msg-text { color:#FFFFFF; }
                .message-bubble.me .msg-time { color:rgba(255,255,255,.65); }
                .msg-time {
                    font-size:9.5px; color:var(--nx-muted); align-self:flex-end;
                    margin-top:3px; white-space:nowrap; letter-spacing:.2px;
                }

                /* new-message highlight */
                .message-bubble.nx-new {
                    animation:nx-new-msg .35s ease;
                }
                @keyframes nx-new-msg {
                    0% { transform:translateY(8px); opacity:.4; }
                    100% { transform:translateY(0); opacity:1; }
                }

                /* Telegram-style footer */
                .chat-footer {
                    padding:10px 12px; background:#FFFFFF; display:flex; gap:9px;
                    border-top:1px solid #EBEBEB; align-items:flex-end; flex-shrink:0;
                    box-shadow:0 -1px 6px rgba(84,82,211,.05);
                }
                .chat-footer textarea {
                    flex:1; min-width:0; padding:10px 15px; border:1.5px solid #DDDDE8;
                    border-radius:22px; outline:none; background:#F8F8FC; color:var(--nx-text);
                    font-size:13.5px; font-family:Poppins,sans-serif; resize:none; line-height:1.45;
                    max-height:120px; overflow-y:auto; transition:border-color .2s;
                    scrollbar-width:thin;
                }
                .chat-footer textarea:focus { border-color:#5452D3; background:#FFFFFF; box-shadow:0 0 0 3px rgba(84,82,211,.12); }
                .chat-footer textarea::placeholder { color:#B0B0C0; }
                .chat-footer textarea:disabled { opacity:.55; }
                .chat-footer button {
                    background:#5452D3; color:white; border:none;
                    border-radius:50%; width:42px; height:42px; cursor:pointer;
                    display:flex; justify-content:center; align-items:center; flex-shrink:0;
                    transition:background .15s,transform .1s; font-size:15px;
                }
                .chat-footer button:hover:not(:disabled) { background:#3E3CAD; transform:scale(1.05); }
                .chat-footer button:disabled { opacity:.4; cursor:default; transform:none; }

                /* --- Delete confirmation dialog --- */
                .nx-del-overlay {
                    position:absolute; inset:0; background:rgba(0,0,0,.45);
                    display:flex; align-items:center; justify-content:center;
                    z-index:50; border-radius:18px;
                    animation:nx-fade-in .18s ease;
                }
                @keyframes nx-fade-in { from{opacity:0} to{opacity:1} }
                .nx-del-dialog {
                    background:#FFFFFF; border-radius:16px; padding:24px 22px 20px;
                    width:min(300px,90%); box-shadow:0 16px 48px rgba(84,82,211,.2);
                    display:flex; flex-direction:column; gap:14px;
                    animation:nx-slide-up .2s ease;
                }
                @keyframes nx-slide-up { from{transform:translateY(12px);opacity:0} to{transform:translateY(0);opacity:1} }
                .nx-del-icon {
                    width:52px; height:52px; background:#FEF0F0; border-radius:50%;
                    display:flex; align-items:center; justify-content:center;
                    margin:0 auto 2px; color:#E05A5A; font-size:22px;
                }
                .nx-del-title {
                    text-align:center; font-size:15px; font-weight:700; color:#1A1A2E;
                }
                .nx-del-body {
                    text-align:center; font-size:12.5px; color:#666; line-height:1.6;
                }
                .nx-del-actions { display:flex; gap:10px; }
                .nx-del-cancel {
                    flex:1; padding:10px; border:1.5px solid #E0E0E8; border-radius:12px;
                    background:#F8F8FC; color:#666; font-size:13px; font-weight:600;
                    cursor:pointer; font-family:Poppins,sans-serif; transition:background .15s;
                }
                .nx-del-cancel:hover { background:#EEEDF8; }
                .nx-del-confirm {
                    flex:1; padding:10px; border:none; border-radius:12px;
                    background:#E05A5A; color:#fff; font-size:13px; font-weight:600;
                    cursor:pointer; font-family:Poppins,sans-serif; transition:background .15s;
                }
                .nx-del-confirm:hover:not(:disabled) { background:#C94444; }
                .nx-del-confirm:disabled { opacity:.5; cursor:default; }
                .nx-del-error {
                    text-align:center; font-size:11.5px; color:#C0392B;
                    font-weight:600; min-height:16px;
                }

                #nerix-quick-reply {
                    position:fixed; left:50%; bottom:-80px; transform:translateX(-50%); width:min(380px,92vw);
                    z-index:2147483645; background:rgba(255,255,255,.98); backdrop-filter:blur(14px);
                    border:1.5px solid var(--nx-border); border-radius:26px; box-shadow:0 12px 34px rgba(80,60,120,.18);
                    padding:8px 12px 8px 18px; display:flex; align-items:center; gap:9px; transition:bottom .22s ease,opacity .22s ease;
                    opacity:0; font-family:Poppins,sans-serif;
                }
                #nerix-quick-reply.qr-open { bottom:26px; opacity:1; }
                #nerix-quick-reply.qr-open:hover,
                #nerix-quick-reply.qr-open:focus-within { border-color:var(--nx-accent); box-shadow:0 12px 36px rgba(80,60,120,.24),0 0 0 3px rgba(139,125,192,.2); }
                #nerix-qr-input { flex:1; min-width:0; border:0; outline:0; background:transparent; font-size:13.5px; color:var(--nx-text); font-family:Poppins,sans-serif; padding:9px 0; }

                /* --- Toast bottom (xabar bildirishnoma) --- */
                .nerix-toast-bottom {
                    position:fixed; left:50%; bottom:24px; transform:translateX(-50%) translateY(14px);
                    min-width:240px; max-width:min(360px,90vw); box-sizing:border-box;
                    background:#FFFFFF; color:var(--nx-text);
                    padding:12px 16px; border-radius:14px; font-size:12.5px; z-index:2147483646;
                    pointer-events:none; font-family:Poppins,sans-serif; text-align:left;
                    box-shadow:0 8px 30px rgba(30,32,48,.14),0 0 0 1px rgba(30,32,48,.06);
                    border:1.5px solid var(--nx-border);
                    opacity:0; transition:opacity .22s ease,transform .22s ease;
                    overflow-wrap:anywhere; display:flex; align-items:flex-start; gap:10px;
                }
                .nerix-toast-bottom.show { opacity:1; transform:translateX(-50%) translateY(0); }
                .nerix-toast-icon { font-size:16px; flex-shrink:0; margin-top:1px; }
                .nerix-toast-body { flex:1; min-width:0; }
                .nerix-toast-label { font-size:10.5px; font-weight:700; color:var(--nx-accent-dark); margin-bottom:2px; text-transform:uppercase; letter-spacing:.4px; }
                .nerix-toast-text { font-size:12.5px; color:var(--nx-text); word-break:break-word; }

                /* --- New message popup — Ghost Design (chat yopiq bo'lganda) --- */
                #nerix-new-msg-popup {
                    position:fixed; top:50%; left:-400px;
                    transform:translateY(-50%);
                    max-width:min(260px,80vw);
                    background:#FFFFFF;
                    font-family:Poppins,sans-serif; z-index:2147483646;
                    opacity:0; pointer-events:none;
                    transition:left .32s cubic-bezier(.2,.8,.2,1), opacity .28s ease;
                    padding:0; border:0; border-radius:0; box-shadow:none; overflow:visible;
                }
                #nerix-new-msg-popup.nx-popup-show {
                    left:0; opacity:1; pointer-events:auto;
                }
                /* Ghost notification inner body — the visible part */
                .nx-nmp-body {
                    padding:10px 14px; background:#FFFFFF;
                }
                .nx-nmp-text {
                    font-size:13px; color:#A400A4; word-break:break-word;
                    line-height:1.5; font-weight:500;
                }
                .nx-nmp-text.hidden-preview {
                    color:#A400A4; font-style:italic; font-size:12px; opacity:.7;
                }
                /* Hide all structural chrome — header, footer, buttons, sender, count */
                .nx-nmp-header,
                .nx-nmp-footer,
                .nx-nmp-sender,
                .nx-nmp-icon,
                .nx-nmp-title,
                .nx-nmp-count,
                .nx-nmp-close,
                .nx-nmp-btn { display:none !important; }

                /* --- Top success toast --- */
                .nerix-toast-top {
                    position:fixed; left:50%; top:-60px; transform:translateX(-50%); background:var(--nx-lavender);
                    color:var(--nx-accent-dark); padding:9px 20px; border-radius:22px; font-size:12.5px; font-weight:700;
                    z-index:2147483646; pointer-events:none; font-family:Poppins,sans-serif;
                    box-shadow:0 6px 20px rgba(169,155,203,.3); border:1.5px solid #C8C0E8; transition:top .22s ease;
                }
                .nerix-toast-top.show { top:20px; }

                /* --- Orange login-required toast --- */
                .nerix-toast-top--orange {
                    background:#FF8C00 !important;
                    color:#FFFFFF !important;
                    border:1.5px solid #E07000 !important;
                    box-shadow:0 6px 20px rgba(255,140,0,.35) !important;
                    font-size:13.5px !important;
                    font-weight:800 !important;
                    letter-spacing:.01em;
                }

                @media(max-width:768px) {
                    #nerix-stealth-popup { width:100%; right:-100%; border-radius:0; top:0; height:100vh; }
                    #nerix-large-chat { width:95%; left:-100%; top:5vh; height:90vh; }
                    #nerix-large-chat.open { left:2.5%; }
                    #nerix-quick-reply { width:94vw; }
                    #nerix-new-msg-popup { left:8px; bottom:10px; width:calc(100vw - 16px); }
                }

                /* --- Alt+Z: faqat oxirgi asosiy javob --- */
                #nerix-altz-popup {
                    position:fixed; bottom:24px; left:12px; width:max-content;
                    max-width:min(520px,calc(100vw - 24px)); max-height:45vh;
                    box-sizing:border-box; padding:6px 8px; margin:0;
                    background:#FFFFFF; color:#C46A22; border:0; border-radius:0;
                    box-shadow:none; font:500 14px/1.45 Arial,sans-serif;
                    white-space:pre-wrap; overflow-wrap:anywhere; overflow:auto;
                    z-index:2147483647; opacity:0;
                    transform:translateX(calc(-100% - 16px));
                    transition:opacity .22s ease,transform .28s cubic-bezier(.2,.75,.25,1);
                    pointer-events:none;
                }
                #nerix-altz-popup.altz-visible {
                    opacity:1; transform:translateX(0); pointer-events:none;
                }
                @media(max-width:768px) {
                    #nerix-altz-popup { bottom:10px; left:8px; max-width:calc(100vw - 16px); }
                }

                /* --- Alt+B: Broadcast panel (UMAROV owner only) --- */
                #nerix-broadcast-panel {
                    position:fixed; top:50%; right:-440px; transform:translateY(-50%);
                    width:min(380px,94vw); background:#FFFFFF; border:2px solid var(--nx-accent);
                    border-radius:18px; box-shadow:0 12px 48px rgba(80,60,120,.22),0 2px 12px rgba(80,60,120,.12);
                    font-family:Poppins,sans-serif; z-index:2147483647;
                    display:flex; flex-direction:column; overflow:hidden;
                    transition:right .35s cubic-bezier(.2,.8,.2,1),opacity .25s ease;
                    opacity:0; pointer-events:none;
                }
                #nerix-broadcast-panel.nx-bc-open {
                    right:24px; opacity:1; pointer-events:auto;
                }
                .nx-bc-header {
                    padding:13px 16px; background:var(--nx-accent); color:#fff;
                    display:flex; align-items:center; gap:10px; flex-shrink:0;
                }
                .nx-bc-header i { font-size:15px; }
                .nx-bc-header-title { flex:1; font-size:13px; font-weight:700; letter-spacing:.3px; }
                .nx-bc-close { background:none; border:0; color:rgba(255,255,255,.85); font-size:22px;
                    cursor:pointer; padding:0 4px; line-height:1; }
                .nx-bc-close:hover { color:#fff; }
                .nx-bc-body { padding:16px 18px 12px; }
                .nx-bc-label { font-size:10.5px; font-weight:700; color:var(--nx-accent-dark);
                    text-transform:uppercase; letter-spacing:.4px; margin-bottom:8px; }
                #nerix-bc-input {
                    width:100%; box-sizing:border-box; resize:vertical; min-height:90px; max-height:200px;
                    padding:10px 14px; border:1.5px solid var(--nx-border); border-radius:12px;
                    font-family:Poppins,sans-serif; font-size:13.5px; color:var(--nx-text);
                    background:var(--nx-bg); outline:none; line-height:1.5;
                }
                #nerix-bc-input:focus { border-color:var(--nx-accent); background:#fff;
                    box-shadow:0 0 0 3px rgba(139,125,192,.15); }
                .nx-bc-counter { font-size:10px; color:var(--nx-muted); text-align:right; margin-top:4px; }
                .nx-bc-counter.warn { color:#C0392B; font-weight:700; }
                .nx-bc-dur-row { display:flex; align-items:center; gap:8px; margin-top:6px; }
                .nx-bc-dur-label { font-size:11px; color:var(--nx-muted); white-space:nowrap; flex-shrink:0; }
                .nx-bc-dur-input { width:60px; padding:3px 6px;
                    border:1.5px solid var(--nx-border); border-radius:6px; font-size:12px;
                    background:rgba(255,255,255,.92); color:var(--nx-text); outline:none; }
                .nx-bc-dur-input:focus { border-color:var(--nx-accent); box-shadow:0 0 0 2px rgba(108,122,224,.18); }
                .nx-bc-footer { padding:10px 18px 16px; display:flex; gap:10px; }
                #nerix-bc-send {
                    flex:1; padding:10px 14px; background:var(--nx-accent); color:#fff;
                    border:1.5px solid var(--nx-accent-dark); border-radius:12px;
                    font-family:Poppins,sans-serif; font-size:13px; font-weight:700;
                    cursor:pointer; transition:background .15s;
                }
                #nerix-bc-send:hover:not(:disabled) { background:var(--nx-accent-dark); }
                #nerix-bc-send:disabled { opacity:.45; cursor:default; }
                #nerix-bc-send i { margin-right:6px; }
                .nx-bc-error { font-size:11.5px; color:#C0392B; padding:2px 18px 10px; min-height:20px; }

                /* --- Broadcast overlay (receiver side) --- */
                #nerix-broadcast-overlay {
                    position:fixed; inset:0; background:rgba(255,255,255,.97);
                    backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);
                    z-index:2147483647; display:flex; flex-direction:column;
                    align-items:center; justify-content:center; padding:40px 32px;
                    font-family:Poppins,sans-serif; cursor:pointer;
                    opacity:0; pointer-events:none;
                    transition:opacity .25s ease;
                }
                #nerix-broadcast-overlay.nx-bco-show {
                    opacity:1; pointer-events:auto;
                }
                .nx-bco-badge {
                    display:inline-flex; align-items:center; gap:8px; padding:6px 16px;
                    background:var(--nx-lavender); color:var(--nx-accent-dark);
                    border-radius:20px; border:1.5px solid #C8C0E8; font-size:11px;
                    font-weight:700; text-transform:uppercase; letter-spacing:.5px; margin-bottom:22px;
                }
                .nx-bco-badge i { font-size:13px; }
                .nx-bco-message {
                    max-width:600px; width:100%; font-size:clamp(18px, 3vw, 28px);
                    font-weight:700; color:var(--nx-text); text-align:center;
                    line-height:1.45; word-break:break-word; white-space:pre-wrap;
                    background:#fff; border:2px solid var(--nx-accent);
                    border-radius:20px; padding:28px 32px;
                    box-shadow:0 16px 60px rgba(139,125,192,.2);
                }
                .nx-bco-hint {
                    margin-top:20px; font-size:11.5px; color:var(--nx-muted);
                    text-align:center;
                }
                @media(max-width:600px) {
                    #nerix-broadcast-panel { right:-100%; }
                    #nerix-broadcast-panel.nx-bc-open { right:0; border-radius:18px 18px 0 0; top:auto; bottom:0; transform:none; }
                    .nx-bco-message { font-size:16px; padding:18px 16px; }
                }

                /* --- Alt+W: O'qish qulayligi (Opacity 1 ga yaqinlashadi) --- */
                .nx-alt-w-active #nerix-stealth-popup.popup-open,
                .nx-alt-w-active #nerix-large-chat.open,
                #nerix-stealth-popup.popup-open.alt-w-opaque,
                #nerix-large-chat.open.alt-w-opaque {
                    opacity:.98!important;
                    box-shadow:-6px 0 40px rgba(50,40,90,.26),0 10px 40px rgba(50,40,90,.20)!important;
                }
                .nx-alt-w-active #nerix-stealth-popup.popup-open:hover,
                .nx-alt-w-active #nerix-large-chat.open:hover,
                .nx-alt-w-active #nerix-stealth-popup.popup-open:focus-within,
                .nx-alt-w-active #nerix-large-chat.open:focus-within,
                #nerix-stealth-popup.popup-open.alt-w-opaque:hover,
                #nerix-large-chat.open.alt-w-opaque:hover,
                #nerix-stealth-popup.popup-open.alt-w-opaque:focus-within,
                #nerix-large-chat.open.alt-w-opaque:focus-within {
                    opacity:1!important;
                }
                .nx-alt-w-active #nerix-quick-reply.qr-open,
                #nerix-quick-reply.qr-open.alt-w-opaque {
                    opacity:1!important;
                    box-shadow:0 14px 40px rgba(60,45,110,.25)!important;
                }
                .nx-alt-w-active #nerix-altz-popup.altz-visible,
                .nx-alt-w-active #nerix-new-msg-popup.nx-popup-show,
                .nx-alt-w-active .nerix-toast-bottom.show,
                .nx-alt-w-active #nerix-fullpage-answer-popup {
                    opacity:1!important;
                }
            `;
            // Inject styles into shadow root for complete CSS isolation
            if (nxShadowRoot) {
                nxShadowRoot.appendChild(style);
            } else {
                (document.head || document.documentElement).appendChild(style);
            }
        }

        // -----------------------------------------------------------------
        // UI construction
        // -----------------------------------------------------------------
        function makeUserCard(id, name, label, locked) {
            const card = makeElement('button', { id, className: 'nerix-user-card' });
            card.type = 'button';
            const avatar = makeElement('div', { className: 'nerix-user-avatar' });
            avatar.appendChild(makeElement('i', {
                className: locked ? 'fa-solid fa-lock' : 'fa-solid fa-user'
            }));
            const info = makeElement('div', { className: 'nerix-user-info' });
            info.append(
                makeElement('div', { className: 'nerix-user-name', text: name }),
                makeElement('div', { className: 'nerix-user-label', text: label })
            );
            card.append(avatar, info, makeElement('span', {
                className: 'nerix-user-arrow', text: '›'
            }));
            return card;
        }

        function buildUI() {
            if (uiBuilt || !document.body) return;
            injectStyles();

            // Gemini side popup.
            stealthPopup = makeElement('div', { id: 'nerix-stealth-popup' });
            const popupHeader = makeElement('div', { className: 'chat-header' });
            const popupTitle = makeElement('div', { className: 'chat-header-title' });
            popupTitle.append(
                makeElement('i', { className: 'fa-solid fa-sparkles' }),
                makeElement('span', { text: 'Umarov AI' })
            );
            const popupClose = makeElement('button', { text: '×' });
            popupClose.type = 'button';
            popupClose.setAttribute('aria-label', 'Gemini oynasini yopish');
            popupClose.style.cssText = 'border:0;background:transparent;font-size:24px;cursor:pointer;color:#777;padding:0 5px';
            popupClose.addEventListener('click', () => PanelManager.closeGemini());
            popupHeader.append(popupTitle, popupClose);

            const iframeContainer = makeElement('div', { id: 'nerix-iframe-container' });
            siteIframe = makeElement('iframe', { id: 'nerix-iframe' });
            siteIframe.src = GEMINI_URL;
            siteIframe.title = 'Umarov AI Gemini';
            siteIframe.setAttribute('allow', 'clipboard-read; clipboard-write');
            siteIframe.referrerPolicy = 'strict-origin-when-cross-origin';
            iframeContainer.appendChild(siteIframe);
            stealthPopup.append(popupHeader, iframeContainer);

            // Large two-person chat panel.
            largeChatPanel = makeElement('div', { id: 'nerix-large-chat' });
            const chatHeader = makeElement('div', { className: 'chat-header' });

            // === Telegram-style header: left side (avatar + name) ===
            const chatHeaderLeft = makeElement('div', { className: 'chat-header-title' });
            const chatAvatar = makeElement('div', { className: 'nx-chat-avatar' });
            chatAvatar.id = 'nx-chat-avatar';
            chatAvatar.textContent = 'D';
            const chatNameWrap = makeElement('div', { className: 'nx-chat-name-wrap' });
            const chatNameEl = makeElement('div', { className: 'nx-chat-name', text: 'Dilshod' });
            chatNameEl.id = 'nx-chat-name';
            const chatStatusEl = makeElement('div', { className: 'nx-chat-status', text: 'online' });
            chatNameWrap.append(chatNameEl, chatStatusEl);
            chatHeaderLeft.append(chatAvatar, chatNameWrap);

            // === Right side: badge, preview toggle, identity label, delete, close ===
            const chatHeaderRight = makeElement('div', {
                style: 'display:flex;align-items:center;gap:4px;flex-shrink:0;'
            });

            // Unread badge
            notifBadgeEl = makeElement('span', { id: 'nerix-unread-badge' });

            // Preview toggle (only visible for UMAROV)
            const previewToggle = makeElement('button', { id: 'nerix-preview-toggle', text: 'Preview: ON' });
            previewToggle.type = 'button';
            previewToggle.title = 'Yangi xabar preview yoqish/o’chirish';
            previewToggle.classList.add('on');
            previewToggle.addEventListener('click', () => {
                previewEnabled = !previewEnabled;
                previewToggle.textContent = previewEnabled ? 'Preview: ON' : 'Preview: OFF';
                previewToggle.classList.toggle('on', previewEnabled);
            });

            // Identity label (read-only - shows authenticated account name)
            const identityLabel = makeElement('span', {
                id: 'chat-identity-label',
                className: 'chat-header-identity',
                text: '--'
            });
            identityLabel.title = 'Faol hisob';
            // No click handler - account selection is done via Alt+CapsLock only.

            // Delete button (trash SVG icon)
            const chatDeleteBtn = makeElement('button', { className: 'nx-hdr-btn nx-delete-btn' });
            chatDeleteBtn.type = 'button';
            chatDeleteBtn.setAttribute('aria-label', 'Barcha xabarlarni o’chirish');
            chatDeleteBtn.title = 'Barcha xabarlarni o’chirish';
            chatDeleteBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>';
            chatDeleteBtn.addEventListener('click', () => {
                showDeleteConfirmDialog();
            });

            // Close button (X SVG icon)
            const chatClose = makeElement('button', { className: 'nx-hdr-btn' });
            chatClose.type = 'button';
            chatClose.setAttribute('aria-label', 'Chat oynasini yopish');
            chatClose.title = 'Yopish';
            chatClose.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
            chatClose.addEventListener('click', () => {
                PanelManager.closeChat();
            });

            chatHeaderRight.append(notifBadgeEl, previewToggle, identityLabel, chatDeleteBtn, chatClose);
            chatHeader.append(chatHeaderLeft, chatHeaderRight);

            // Message container.
            chatContainer = makeElement('div', {
                id: 'nerix-chat-messages',
                className: 'chat-body'
            });
            chatContainer.style.display = 'none';

            // Main chat input (textarea for multiline support).
            const chatFooter = makeElement('div', { className: 'chat-footer' });
            chatFooter.style.display = 'none';
            const chatInput = makeElement('textarea', { id: 'nerix-large-input' });
            chatInput.autocomplete = 'off';
            chatInput.placeholder = 'Xabar yozing...';
            chatInput.maxLength = 4000;
            chatInput.rows = 1;
            // Auto-grow textarea
            chatInput.addEventListener('input', () => {
                chatInput.style.height = 'auto';
                chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
            });
            const chatSendButton = makeElement('button', { id: 'nerix-large-send' });
            chatSendButton.type = 'button';
            chatSendButton.setAttribute('aria-label', 'Xabar yuborish');
            chatSendButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
            chatSendButton.addEventListener('click', () => {
                sendChatMessage(chatInput.value, chatInput, chatSendButton);
            });
            chatInput.addEventListener('keydown', event => {
                if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
                    event.preventDefault();
                    sendChatMessage(chatInput.value, chatInput, chatSendButton);
                }
                // Shift+Enter: newline (default textarea behavior)
            });
            chatFooter.append(chatInput, chatSendButton);
            largeChatPanel.append(chatHeader, chatContainer, chatFooter);

            // Quick reply panel.
            quickReplyPanel = makeElement('div', { id: 'nerix-quick-reply' });
            const quickInput = makeElement('input', { id: 'nerix-qr-input' });
            quickInput.type = 'text';
            quickInput.autocomplete = 'off';
            quickInput.placeholder = 'Tezkor xabar...';
            quickInput.maxLength = 4000;
            const quickSend = makeElement('button', {});
            quickSend.type = 'button';
            quickSend.setAttribute('aria-label', 'Tezkor xabar yuborish');
            quickSend.style.cssText = 'border:1.5px solid var(--nx-accent-dark);background:#A99BCB;color:white;border-radius:50%;width:34px;height:34px;cursor:pointer;flex-shrink:0';
            quickSend.appendChild(makeElement('i', { className: 'fa-solid fa-paper-plane' }));
            const quickClose = makeElement('button', { text: '×' });
            quickClose.type = 'button';
            quickClose.setAttribute('aria-label', 'Tezkor javobni yopish');
            quickClose.style.cssText = 'border:0;background:transparent;color:#888;font-size:21px;cursor:pointer;padding:0 3px';
            quickSend.addEventListener('click', () => sendQuickReply(quickInput.value, quickInput));
            quickInput.addEventListener('keydown', event => {
                if (event.key === 'Enter' && !event.isComposing) {
                    event.preventDefault();
                    sendQuickReply(quickInput.value, quickInput);
                } else if (event.key === 'Escape') {
                    PanelManager.closeQuickReply();
                }
            });
            quickClose.addEventListener('click', () => PanelManager.closeQuickReply());
            quickReplyPanel.append(quickInput, quickSend, quickClose);

            // Append panels into the Shadow DOM overlay host.
            // The host is position:fixed on <html> with its own stacking context,
            // so no website CSS (transform, filter, contain, etc.) can break
            // the fixed positioning of the panels.
            if (nxShadowRoot) {
                nxShadowRoot.append(stealthPopup, largeChatPanel, quickReplyPanel);
            } else {
                (document.documentElement || document.body).append(stealthPopup, largeChatPanel, quickReplyPanel);
            }
            uiBuilt = true;

            // Account authentication is now handled via chrome.storage.local (Alt+CapsLock).
            // The chat waits for initializeMainPage() to restore the saved account.
            // No automatic account selection here.
        }

        // =====================================================================
        // CENTRAL PANEL STATE MANAGER (Exclusive Mode)
        // =====================================================================
        let lastPanelActionTs = 0;
        const PANEL_DEBOUNCE_MS = 150;

        function openStealthPopup() {
            if (!stealthPopup) return;
            isPopupOpen = true;
            stealthPopup.style.right = '0px';
            stealthPopup.classList.add('popup-open');
        }

        function closeStealthPopup() {
            if (!stealthPopup) return;
            isPopupOpen = false;
            const mobile = window.innerWidth <= 768;
            stealthPopup.style.right = mobile ? '-100%' : `-${POPUP_WIDTH + 30}px`;
            stealthPopup.classList.remove('popup-open');
        }

        function openLargeChat() {
            if (!largeChatPanel) return;
            isLargeChatOpen = true;
            largeChatPanel.classList.add('open');
            unreadCount = 0;
            updateUnreadBadge();
            dismissNewMsgPopup();
            if (chatIdentitySelected) {
                const input = nxById('nerix-large-input');
                if (input) setTimeout(() => input.focus(), 100);
            }
        }

        function closeLargeChat() {
            if (!largeChatPanel) return;
            isLargeChatOpen = false;
            pendingQuickReplyAfterIdentity = false;
            largeChatPanel.classList.remove('open');
        }

        function openQuickReplyPanel() {
            if (!quickReplyPanel) return;
            if (!chatIdentitySelected || !currentUser) {
                pendingQuickReplyAfterIdentity = true;
                PanelManager.openChat();
                return;
            }
            const quickReplyInput = quickReplyPanel.querySelector('#nerix-qr-input');
            isQuickReplyOpen = true;
            quickReplyPanel.classList.add('qr-open');
            if (quickReplyInput) {
                setTimeout(() => {
                    if (quickReplyInput.isConnected && !quickReplyInput.disabled) {
                        quickReplyInput.focus();
                    }
                }, 180);
            }
        }

        function closeQuickReplyPanel() {
            isQuickReplyOpen = false;
            if (quickReplyPanel) {
                quickReplyPanel.classList.remove('qr-open');
                const quickReplyInput = quickReplyPanel.querySelector('#nerix-qr-input');
                if (quickReplyInput) quickReplyInput.blur();
            }
        }

        const PanelManager = {
            openGemini: async function() {
                const now = Date.now();
                if (now - lastPanelActionTs < PANEL_DEBOUNCE_MS) return;
                lastPanelActionTs = now;

                // Exclusive mode: Chat va Quick Reply yopiladi
                closeLargeChat();
                closeQuickReplyPanel();

                openStealthPopup();
                await delay(350);
                if (siteIframe?.contentWindow) {
                    try {
                        siteIframe.contentWindow.postMessage(
                            { type: 'NERIX_FOCUS_COMPOSER' },
                            GEMINI_TARGET_ORIGIN
                        );
                    } catch (_) {}
                }
            },

            closeGemini: function() {
                closeStealthPopup();
            },

            toggleGemini: function() {
                if (isPopupOpen) {
                    this.closeGemini();
                } else {
                    void this.openGemini();
                }
            },

            openChat: function() {
                const now = Date.now();
                if (now - lastPanelActionTs < PANEL_DEBOUNCE_MS) return;
                lastPanelActionTs = now;

                // Exclusive mode: Gemini va Quick Reply yopiladi
                closeStealthPopup();
                closeQuickReplyPanel();

                openLargeChat();
            },

            closeChat: function() {
                closeLargeChat();
            },

            toggleChat: function() {
                if (isLargeChatOpen) {
                    this.closeChat();
                } else {
                    this.openChat();
                }
            },

            openQuickReply: function() {
                const now = Date.now();
                if (now - lastPanelActionTs < PANEL_DEBOUNCE_MS) return;
                lastPanelActionTs = now;

                // Exclusive mode: Gemini va Chat yopiladi
                closeStealthPopup();
                closeLargeChat();

                openQuickReplyPanel();
            },

            closeQuickReply: function() {
                closeQuickReplyPanel();
            },

            toggleQuickReply: function() {
                if (isQuickReplyOpen) {
                    this.closeQuickReply();
                } else {
                    this.openQuickReply();
                }
            },

            closeAll: function() {
                closeStealthPopup();
                closeLargeChat();
                closeQuickReplyPanel();
            }
        };

        // Mavjud nomlar uchun backward compatibility aliaslar
        // Screenshot workflow: reveal the existing Gemini iframe without
        // toggling it closed or constructing a second iframe.
        window.__nerixEnsureGeminiPopupOpen = async function() {
            try {
                if (!uiBuilt && document.body) buildUI();

                if (!siteIframe || !siteIframe.contentWindow) {
                    return {
                        ok: false,
                        error: "Gemini iframe UI hali yaratilmagan."
                    };
                }

                closeLargeChat();
                closeQuickReplyPanel();
                openStealthPopup();

                // Let the popup become visible before the iframe composer is focused.
                await delay(120);

                return {
                    ok: true,
                    reused: true
                };
            } catch (error) {
                return {
                    ok: false,
                    error: error?.message || String(error)
                };
            }
        };

        function toggleQuickReply() { PanelManager.toggleQuickReply(); }
        function toggleGeminiPopup() { PanelManager.toggleGemini(); }
        function closeQuickReply() { PanelManager.closeQuickReply(); }
        function ensureGeminiPopupOpen() { return PanelManager.openGemini(); }
        function openQuickReply() { PanelManager.openQuickReply(); }

        // -----------------------------------------------------------------
        // Identity and chat panel (account set via Alt+CapsLock storage only)
        // -----------------------------------------------------------------
        // showProfileSelector / showPinScreen / hidePinShowSelector removed.
        // Account switching in-chat is no longer supported.

        function enterChatAs(user) {
            currentUser = user;
            chatIdentitySelected = true;
            const label = nxById('chat-identity-label');
            const footer = largeChatPanel?.querySelector('.chat-footer');
            const input = nxById('nerix-large-input');

            // Update Telegram-style header avatar + name
            const avatarEl = nxById('nx-chat-avatar');
            const nameEl = nxById('nx-chat-name');
            if (user === 'UMAROV') {
                if (avatarEl) avatarEl.textContent = 'U';
                if (nameEl) nameEl.textContent = 'Umarov';
                if (label) label.textContent = 'Umarov';
            } else {
                if (avatarEl) avatarEl.textContent = 'D';
                if (nameEl) nameEl.textContent = 'Dilshod';
                if (label) label.textContent = 'Dilshod';
            }

            if (chatContainer) chatContainer.style.display = 'flex';
            if (footer) footer.style.display = 'flex';
            if (input) input.placeholder = user === 'DILSHOD'
                ? 'Dilshod sifatida xabar yozing...'
                : 'Umarov sifatida xabar yozing...';

            initialChatLoadDone = false;
            lastMessageIds.clear();
            lastRenderedSignature = '';
            void fetchChatMessages();
            setTimeout(() => { if (input) input.focus(); }, 100);

            if (pendingQuickReplyAfterIdentity) {
                pendingQuickReplyAfterIdentity = false;
                PanelManager.closeChat();
                setTimeout(() => PanelManager.openQuickReply(), 150);
            }
            // Preview toggle: faqat UMAROV profili uchun ko'rinadi
            const prevToggle = nxById('nerix-preview-toggle');
            if (prevToggle) prevToggle.style.display = user === 'UMAROV' ? '' : 'none';
        }





        // -----------------------------------------------------------------
        // Delete all messages — confirmation dialog + database operation
        // -----------------------------------------------------------------
        let isDeletingMessages = false;

        function showDeleteConfirmDialog() {
            if (!largeChatPanel || !chatIdentitySelected) return;
            if (isDeletingMessages) return;
            // Remove any existing dialog
            const existing = largeChatPanel.querySelector('.nx-del-overlay');
            if (existing) existing.remove();

            const overlay = makeElement('div', { className: 'nx-del-overlay' });
            const dialog = makeElement('div', { className: 'nx-del-dialog' });

            // Icon
            const iconWrap = makeElement('div', { className: 'nx-del-icon' });
            iconWrap.innerHTML = "<svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><polyline points='3 6 5 6 21 6'/><path d='M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6'/><path d='M10 11v6'/><path d='M14 11v6'/><path d='M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2'/></svg>";

            const title = makeElement('div', { className: 'nx-del-title', text: 'Tarixni o' + String.fromCharCode(0x2018) + 'chirish' });
            const body = makeElement('div', {
                className: 'nx-del-body',
                text: 'Barcha xabarlar doimiy ravishda o' + String.fromCharCode(0x2018) + 'chiriladi. Bu amalni bekor qilib bo' + String.fromCharCode(0x2018) + 'lmaydi.'
            });
            const errorEl = makeElement('div', { className: 'nx-del-error' });
            const actions = makeElement('div', { className: 'nx-del-actions' });

            const cancelBtn = makeElement('button', { className: 'nx-del-cancel', text: 'Bekor qilish' });
            cancelBtn.type = 'button';
            cancelBtn.addEventListener('click', () => overlay.remove());

            const confirmBtn = makeElement('button', { className: 'nx-del-confirm', text: 'O' + String.fromCharCode(0x2018) + 'chirish' });
            confirmBtn.type = 'button';
            confirmBtn.addEventListener('click', async () => {
                if (isDeletingMessages) return;
                isDeletingMessages = true;
                confirmBtn.disabled = true;
                confirmBtn.textContent = 'O' + String.fromCharCode(0x2018) + 'chirilmoqda...';
                cancelBtn.disabled = true;
                errorEl.textContent = '';

                try {
                    const result = await sendBg({ type: 'NERIX_SUPABASE_DELETE_ALL' });
                    if (result && result.ok) {
                        overlay.remove();
                        // Clear UI messages immediately
                        if (chatContainer) chatContainer.replaceChildren();
                        lastRenderedSignature = '';
                        lastMessageIds.clear();
                        seenMessageIds.clear();
                        initialChatLoadDone = false;
                        showBottomToast('Barcha xabarlar o' + String.fromCharCode(0x2018) + 'chirildi.');
                    } else {
                        // Show a compact, human-readable error — not raw JSON
                        const rawError = result?.error || '';
                        console.error('[UD/AA] Delete error (raw):', rawError);
                        let friendlyMsg = 'Xabarlarni o' + String.fromCharCode(0x2018) + 'chirib bo' + String.fromCharCode(0x2018) + 'lmadi.';
                        if (rawError.includes('permission denied') || rawError.includes('42501')) {
                            friendlyMsg += ' Ruxsat xatosi — SQL funksiya yaratilganligini tekshiring.';
                        } else if (rawError.includes('does not exist') || rawError.includes('404')) {
                            friendlyMsg += ' RPC funksiya topilmadi — SQL ni ishga tushiring.';
                        } else if (rawError.includes('vaqti tugadi') || rawError.includes('timeout')) {
                            friendlyMsg += ' Internet aloqasini tekshiring.';
                        } else if (rawError) {
                            // Truncate to a reasonable length
                            friendlyMsg += ' ' + rawError.slice(0, 120);
                        }
                        errorEl.textContent = friendlyMsg;
                        confirmBtn.disabled = false;
                        confirmBtn.textContent = 'O' + String.fromCharCode(0x2018) + 'chirish';
                        cancelBtn.disabled = false;
                    }
                } catch (err) {
                    console.error('[UD/AA] Delete exception:', err);
                    errorEl.textContent = 'Kutilmagan xatolik. Konsolni tekshiring.';
                    confirmBtn.disabled = false;
                    confirmBtn.textContent = 'O' + String.fromCharCode(0x2018) + 'chirish';
                    cancelBtn.disabled = false;
                } finally {
                    isDeletingMessages = false;
                }
            });

            // Close on overlay backdrop click
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) overlay.remove();
            });

            actions.append(cancelBtn, confirmBtn);
            dialog.append(iconWrap, title, body, errorEl, actions);
            overlay.appendChild(dialog);
            largeChatPanel.style.position = 'relative'; // ensure positioning context
            largeChatPanel.appendChild(overlay);
        }

        // -----------------------------------------------------------------
        // Chat send and polling helpers
        // -----------------------------------------------------------------
        async function sendChatMessage(text, inputElement, sendButton) {
            const trimmed = String(text || '').trim();
            if (!trimmed || !currentUser || isSendingMessage) return;
            if (currentUser !== 'DILSHOD' && currentUser !== 'UMAROV') {
                showBottomToast('Xatolik: profil tasdiqlanmagan.');
                return;
            }

            isSendingMessage = true;
            if (inputElement) inputElement.disabled = true;
            if (sendButton) sendButton.disabled = true;

            try {
                const result = await sendBg({
                    type: 'NERIX_SUPABASE_INSERT',
                    user: currentUser,
                    text: trimmed
                });

                if (result?.ok) {
                    if (inputElement) {
                        inputElement.value = '';
                        inputElement.style.height = 'auto'; // reset textarea height
                        inputElement.focus();
                    }
                    await fetchChatMessages();
                } else {
                    showBottomToast('Xabar ketmadi: ' + (result?.error || 'Internet aloqasini tekshiring.'));
                }
            } catch (error) {
                showBottomToast('Xabar ketmadi: ' + (error?.message || String(error)));
            } finally {
                isSendingMessage = false;
                if (inputElement) inputElement.disabled = false;
                if (sendButton) sendButton.disabled = false;
            }
        }

        async function sendQuickReply(text, inputElement) {
            if (isSendingQuickReply) return;
            const trimmed = String(text || '').trim();
            if (!trimmed || !currentUser) return;
            if (currentUser !== 'DILSHOD' && currentUser !== 'UMAROV') {
                showBottomToast('Xatolik: profil tasdiqlanmagan.');
                return;
            }

            isSendingQuickReply = true;
            if (inputElement) inputElement.disabled = true;

            try {
                const result = await sendBg({
                    type: 'NERIX_SUPABASE_INSERT',
                    user: currentUser,
                    text: trimmed
                });

                if (result?.ok) {
                    if (inputElement) inputElement.value = '';
                    if (result.message?.id) lastMessageIds.add(String(result.message.id));
                    showTopSuccessNotification('Xabar yuborildi');
                    closeQuickReply();
                    void fetchChatMessages();
                } else {
                    showBottomToast('Xabar yuborilmadi: ' + (result?.error || 'Noma’lum xatolik'));
                    if (inputElement) inputElement.focus();
                }
            } catch (error) {
                showBottomToast('Xabar yuborilmadi: ' + (error?.message || String(error)));
                if (inputElement) inputElement.focus();
            } finally {
                isSendingQuickReply = false;
                if (inputElement) inputElement.disabled = false;
            }
        }

        function normalizeMessage(message) {
            if (!message || typeof message !== 'object') return null;
            const user = message.user ?? message.sender ?? message.sender_type ?? message.author;
            const text = message.text ?? message.content ?? message.message;
            const id = message.id ?? message.message_id;
            const createdAt = message.createdAt ?? message.created_at ?? message.timestamp;
            if (user === undefined || text === undefined || text === null) return null;
            return {
                id: id === undefined || id === null ? '' : String(id),
                user: String(user),
                text: String(text),
                createdAt: createdAt ?? null
            };
        }

        // -----------------------------------------------------------------
        // fetchChatMessages: chat yopiq bo‘lsa ham background polling ishlaydi
        // -----------------------------------------------------------------
        async function fetchChatMessages() {
            if (isFetchingMessages) return;
            isFetchingMessages = true;

            try {
                const result = await sendBg({
                    type: 'NERIX_SUPABASE_GET',
                    limit: MAX_CHAT_MESSAGES
                });

                if (!result?.ok || !Array.isArray(result.messages)) {
                    if (result?.error) console.warn('UD/AA chat:', result.error);
                    return;
                }

                const messages = result.messages.map(normalizeMessage).filter(Boolean);
                const signature = messages.map(m =>
                    `${m.id}|${m.user}|${m.createdAt ?? ''}|${m.text}`
                ).join('\n');

                if (signature !== lastRenderedSignature) {
                    lastRenderedSignature = signature;
                    if (chatIdentitySelected) renderMessages(messages);
                }

                // Yangi xabarlarni aniqlash
                let newMsgCount = 0;
                let lastNewMsg = null;
                for (const msg of messages) {
                    if (!msg.id || seenMessageIds.has(msg.id)) continue;
                    seenMessageIds.add(msg.id);
                    if (!initialChatLoadDone) continue; // birinchi yuklanish
                    if (currentUser && msg.user === currentUser) continue; // o'z xabari
                    newMsgCount++;
                    lastNewMsg = msg;
                    lastMessageIds.add(msg.id);
                }

                while (seenMessageIds.size > 400) {
                    seenMessageIds.delete(seenMessageIds.values().next().value);
                }
                while (lastMessageIds.size > 200) {
                    lastMessageIds.delete(lastMessageIds.values().next().value);
                }

                if (newMsgCount > 0 && lastNewMsg && initialChatLoadDone) {
                    nxLastChatMsg = lastNewMsg; // Shift+Alt preview uchun saqlash
                    unreadCount += newMsgCount;
                    updateUnreadBadge();
                    if (!isLargeChatOpen) showNewMsgPopup(lastNewMsg, unreadCount);
                }

                // Chat ochiq bo'lsa unread tozalanadi
                if (isLargeChatOpen && unreadCount > 0) {
                    unreadCount = 0;
                    updateUnreadBadge();
                }

                initialChatLoadDone = true;
            } catch (error) {
                console.warn('UD/AA: Xabarlarni olishda xatolik:', error);
            } finally {
                isFetchingMessages = false;
            }
        }

        function renderMessages(messages) {
            if (!chatContainer) return;
            const wasNearBottom = chatContainer.scrollHeight - chatContainer.scrollTop - chatContainer.clientHeight < 80;

            // Existing IDs for new-message animation
            const existingIds = new Set(
                Array.from(chatContainer.querySelectorAll('[data-msg-id]')).map(el => el.dataset.msgId)
            );

            chatContainer.replaceChildren();

            let lastUser = null;
            let lastDateStr = null;

            for (const message of messages) {
                const isMe = message.user === currentUser;
                const isNew = message.id && !existingIds.has(String(message.id));
                let timeText = '';
                let dateStr = '';
                if (message.createdAt) {
                    const parsedDate = new Date(message.createdAt);
                    if (!Number.isNaN(parsedDate.getTime())) {
                        timeText = parsedDate.toLocaleTimeString('uz-UZ', {
                            hour: '2-digit', minute: '2-digit'
                        });
                        dateStr = parsedDate.toLocaleDateString('uz-UZ', {
                            day: 'numeric', month: 'long', year: 'numeric'
                        });
                    }
                }

                // Date separator
                if (dateStr && dateStr !== lastDateStr) {
                    lastDateStr = dateStr;
                    const sep = makeElement('div', { className: 'nx-date-sep' });
                    sep.appendChild(makeElement('span', { text: dateStr }));
                    chatContainer.appendChild(sep);
                    lastUser = null; // reset grouping after date separator
                }

                // Group consecutive messages from same sender (no sender label for grouped)
                const isGrouped = lastUser === message.user;
                lastUser = message.user;

                const displayName = message.user === 'UMAROV'
                    ? 'Umarov'
                    : (message.user === 'DILSHOD' ? 'Dilshod' : message.user);

                const row = makeElement('div', {
                    className: 'message-row ' + (isMe ? 'me' : 'them') + (isGrouped ? ' nx-grouped' : '')
                });
                if (message.id) row.dataset.msgId = message.id;

                // Sender name (only for "them" and only if not grouped)
                if (!isMe && !isGrouped) {
                    const sender = makeElement('div', { className: 'msg-sender', text: displayName });
                    row.appendChild(sender);
                }

                const bubble = makeElement('div', {
                    className: 'message-bubble' + (isMe ? ' me' : '') + (isNew && initialChatLoadDone ? ' nx-new' : '')
                });
                const messageText = makeElement('span', { className: 'msg-text', text: message.text });
                const time = makeElement('span', { className: 'msg-time', text: timeText });
                bubble.append(messageText, time);
                row.append(bubble);
                chatContainer.appendChild(row);
            }

            if (wasNearBottom || chatContainer.scrollTop === 0) {
                chatContainer.scrollTop = chatContainer.scrollHeight;
            }
        }

        // -----------------------------------------------------------------
        // Notifications & unread badge
        // -----------------------------------------------------------------

        function updateUnreadBadge() {
            if (!notifBadgeEl) return;
            if (unreadCount > 0) {
                notifBadgeEl.textContent = unreadCount > 99 ? '99+' : String(unreadCount);
                notifBadgeEl.classList.add('visible');
            } else {
                notifBadgeEl.classList.remove('visible');
            }
        }

        let newMsgPopupEl = null;
        let newMsgPopupTimer = null;

        function showNewMsgPopup(msg, count) {
            if (!document.body) return;
            if (!newMsgPopupEl) {
                newMsgPopupEl = makeElement('div', { id: 'nerix-new-msg-popup' });
                if (nxShadowRoot) {
                    nxShadowRoot.appendChild(newMsgPopupEl);
                } else {
                    document.body.appendChild(newMsgPopupEl);
                }
            }
            const senderName = msg.user === 'UMAROV' ? 'Umarov' : (msg.user === 'DILSHOD' ? 'Dilshod' : msg.user);
            const isLoggedIn = chatIdentitySelected && currentUser;
            newMsgPopupEl.replaceChildren();

            const header = makeElement('div', { className: 'nx-nmp-header' });
            header.append(
                makeElement('i', { className: 'fa-solid fa-message nx-nmp-icon' }),
                makeElement('span', { className: 'nx-nmp-title', text: 'Yangi xabar' }),
                makeElement('span', { className: 'nx-nmp-count', text: count > 99 ? '99+' : String(count) })
            );
            const nmpClose = makeElement('button', { className: 'nx-nmp-close', text: '×' });
            nmpClose.type = 'button';
            nmpClose.setAttribute('aria-label', 'Yopish');
            nmpClose.addEventListener('click', () => dismissNewMsgPopup());
            header.appendChild(nmpClose);

            const body = makeElement('div', { className: 'nx-nmp-body' });
            body.appendChild(makeElement('div', { className: 'nx-nmp-sender', text: senderName }));
            const previewText = isLoggedIn && previewEnabled
                ? msg.text.slice(0, 120) + (msg.text.length > 120 ? '…' : '')
                : '🔒 Xabar yashirin';
            const isHidden = !(isLoggedIn && previewEnabled);
            body.appendChild(makeElement('div', {
                className: 'nx-nmp-text' + (isHidden ? ' hidden-preview' : ''),
                text: previewText
            }));

            const footer = makeElement('div', { className: 'nx-nmp-footer' });
            const openBtn = makeElement('button', { className: 'nx-nmp-btn nx-nmp-btn-open', text: 'Chatni ochish' });
            openBtn.type = 'button';
            openBtn.addEventListener('click', () => {
                dismissNewMsgPopup();
                PanelManager.openChat();
            });
            const dismissBtn = makeElement('button', { className: 'nx-nmp-btn nx-nmp-btn-dismiss', text: 'Etiborsiz' });
            dismissBtn.type = 'button';
            dismissBtn.addEventListener('click', () => dismissNewMsgPopup());
            footer.append(openBtn, dismissBtn);

            newMsgPopupEl.append(header, body, footer);
            clearTimeout(newMsgPopupTimer);
            requestAnimationFrame(() => requestAnimationFrame(() => {
                newMsgPopupEl.classList.add('nx-popup-show');
            }));
            newMsgPopupTimer = setTimeout(() => dismissNewMsgPopup(), 3000);
        }

        function dismissNewMsgPopup() {
            clearTimeout(newMsgPopupTimer);
            if (newMsgPopupEl) newMsgPopupEl.classList.remove('nx-popup-show');
        }

        function showBottomToast(text) {
            if (!document.body) return;
            const toast = makeElement('div', { className: 'nerix-toast-bottom' });
            const icon = makeElement('span', { className: 'nerix-toast-icon', text: '✉️' });
            const bodyEl = makeElement('div', { className: 'nerix-toast-body' });
            bodyEl.append(
                makeElement('div', { className: 'nerix-toast-label', text: 'Xabar' }),
                makeElement('div', { className: 'nerix-toast-text', text: String(text || '') })
            );
            toast.append(icon, bodyEl);
            if (nxShadowRoot) {
                nxShadowRoot.appendChild(toast);
            } else {
                document.body.appendChild(toast);
            }
            requestAnimationFrame(() => toast.classList.add('show'));
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 280);
            }, 3000);
        }

        function showTopSuccessNotification(text) {
            if (!document.body) return;
            const toast = makeElement('div', {
                className: 'nerix-toast-top',
                text: String(text || '')
            });
            if (nxShadowRoot) {
                nxShadowRoot.appendChild(toast);
            } else {
                document.body.appendChild(toast);
            }
            requestAnimationFrame(() => toast.classList.add('show'));
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 280);
            }, 1800);
        }

        // ================================================================
        // GLOBAL LOGIN GUARD — Orange notification + auth check helper
        // ================================================================

        // Shows an orange "Avval akkauntga kiring!" toast using the existing
        // notification system (nerix-toast-top + nerix-toast-top--orange).
        // Deduped: at most one orange toast visible at a time.
        let _loginNotifActive = false;
        function showLoginRequiredNotification() {
            if (!document.body || _loginNotifActive) return;
            _loginNotifActive = true;
            const toast = makeElement('div', {
                className: 'nerix-toast-top nerix-toast-top--orange',
                text: '🔒 Avval akkauntga kiring!'
            });
            if (nxShadowRoot) {
                nxShadowRoot.appendChild(toast);
            } else {
                document.body.appendChild(toast);
            }
            requestAnimationFrame(() => toast.classList.add('show'));
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => { toast.remove(); _loginNotifActive = false; }, 280);
            }, 2200);
        }

        // Returns true only when a real successful authentication has been
        // performed (chatIdentitySelected && currentUser both truthy).
        function isAuthenticated() {
            return !!(chatIdentitySelected && currentUser);
        }

        function clearFullPageAnswer() {
            if (fullPagePopupTimer) {
                clearTimeout(fullPagePopupTimer);
                fullPagePopupTimer = null;
            }
            if (fullPageAnswerPopup) fullPageAnswerPopup.remove();
            fullPageAnswerPopup = null;
            fullPageAnswerCard = null;
            lastSavedGeminiAnswer = '';
        }

        function showFullPageAnswer(answer, questionRow, fullText, mainAnswer) {
            try {
                if (!document.body) {
                    nerixLog('warn', 'NOTIFICATION', 'showFullPageAnswer called but document.body is not available.');
                    return;
                }
                const answerText = String(answer || '').trim();
                if (!answerText) {
                    nerixLog('warn', 'NOTIFICATION', 'showFullPageAnswer received an empty answer; nothing to display.');
                    return;
                }

                // Store the exact answer for Alt+Z — must match what the notification displays.
                lastSavedGeminiAnswer = answerText;
                if (altZHeld) showAltZPopup(lastSavedGeminiAnswer);

                if (!fullPageAnswerPopup?.isConnected || !fullPageAnswerCard) {
                    const overlay = createAnswerOverlayHost('nerix-fullpage-answer-popup', 'top');
                    if (!overlay) {
                        nerixReportError('NOTIFICATION', new Error('createAnswerOverlayHost returned null'), {
                            operation: 'showFullPageAnswer — overlay creation'
                        });
                        return;
                    }
                    fullPageAnswerPopup = overlay.host;
                    fullPageAnswerCard = overlay.card;
                }

                const { answerLine, rowLine } = udaaBuildAnswerCardDOM(answerText, questionRow);
                fullPageAnswerCard.replaceChildren(answerLine, rowLine);
                animateAnswerOverlayIn(fullPageAnswerCard);
                clearTimeout(fullPageAnswerCard._autoHideTimer);
                fullPageAnswerCard._autoHideTimer = setTimeout(() => { fullPageAnswerCard.classList.remove('visible'); }, 3000);
                nerixLog('info', 'NOTIFICATION', 'Notification displayed.');
            } catch (err) {
                nerixReportError('NOTIFICATION', err, { operation: 'showFullPageAnswer' });
            }
        }

        // Alt+Z shows only Gemini's extracted main answer, using the same
        // isolated horizontal layout as the J/Q notification.
        function showAltZPopup(text) {
            if (!document.body) return;
            if (!altZPopupEl?.isConnected || !altZPopupCard) {
                const overlay = createAnswerOverlayHost('nerix-altz-popup', 'bottom');
                if (!overlay) return;
                altZPopupEl = overlay.host;
                altZPopupCard = overlay.card;
            }
            const altZText = String(text || '').trim() || 'Hali Gemini javobi yo\'q.';
            altZPopupCard.replaceChildren(udaaRenderMixedText(altZText));
            animateAnswerOverlayIn(altZPopupCard);
        }

        function hideAltZPopup() {
            if (altZPopupCard) altZPopupCard.classList.remove('visible');
        }

        function setAltWState(active) {
            isAltWHeld = !!active;
            if (document.body) {
                document.body.classList.toggle('nx-alt-w-active', isAltWHeld);
            }
            if (stealthPopup) stealthPopup.classList.toggle('alt-w-opaque', isAltWHeld);
            if (largeChatPanel) largeChatPanel.classList.toggle('alt-w-opaque', isAltWHeld);
            if (quickReplyPanel) quickReplyPanel.classList.toggle('alt-w-opaque', isAltWHeld);
        }

        // -----------------------------------------------------------------
        // Alt+B Broadcast panel (UMAROV owner only)
        // -----------------------------------------------------------------
        function showBroadcastPanel() {
            if (!currentUser || currentUser !== 'UMAROV') return;
            if (!document.body) return;
            if (!broadcastPanelEl) {
                broadcastPanelEl = document.createElement('div');
                broadcastPanelEl.id = 'nerix-broadcast-panel';

                const header = document.createElement('div');
                header.className = 'nx-bc-header';
                const ico = document.createElement('i');
                ico.className = 'fa-solid fa-bullhorn';
                const titleSpan = document.createElement('span');
                titleSpan.className = 'nx-bc-header-title';
                titleSpan.textContent = 'Global Broadcast (UMAROV)';
                const closeBtn = document.createElement('button');
                closeBtn.type = 'button'; closeBtn.className = 'nx-bc-close'; closeBtn.textContent = '×';
                closeBtn.addEventListener('click', hideBroadcastPanel);
                header.append(ico, titleSpan, closeBtn);

                const body = document.createElement('div');
                body.className = 'nx-bc-body';
                const lbl = document.createElement('div');
                lbl.className = 'nx-bc-label';
                lbl.textContent = 'Barcha foydalanuvchilarga xabar';
                const textarea = document.createElement('textarea');
                textarea.id = 'nerix-bc-input'; textarea.maxLength = 500;
                textarea.placeholder = 'Broadcast xabarini yozing (max 500 belgi)...';
                textarea.autocomplete = 'off';
                const counter = document.createElement('div');
                counter.className = 'nx-bc-counter'; counter.textContent = '0 / 500';
                textarea.addEventListener('input', () => {
                    const len = textarea.value.length;
                    counter.textContent = `${len} / 500`;
                    counter.classList.toggle('warn', len > 450);
                });
                textarea.addEventListener('keydown', event => {
                    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
                        event.preventDefault();
                        sendBroadcastMessage(textarea, sendBtn, errorEl);
                    } else if (event.key === 'Escape') {
                        hideBroadcastPanel();
                    }
                });
                const durRow = document.createElement('div');
                durRow.className = 'nx-bc-dur-row';
                const durLbl = document.createElement('label');
                durLbl.className = 'nx-bc-dur-label';
                durLbl.setAttribute('for', 'nerix-bc-duration');
                durLbl.textContent = 'Ko\u02BBindirish vaqti (soniya):';
                const durInput = document.createElement('input');
                durInput.type = 'number';
                durInput.id = 'nerix-bc-duration';
                durInput.min = '1';
                durInput.max = '60';
                durInput.value = '2';
                durInput.className = 'nx-bc-dur-input';
                durRow.append(durLbl, durInput);
                body.append(lbl, textarea, counter, durRow);

                const errorEl = document.createElement('div');
                errorEl.className = 'nx-bc-error';

                const footer = document.createElement('div');
                footer.className = 'nx-bc-footer';
                const sendBtn = document.createElement('button');
                sendBtn.type = 'button'; sendBtn.id = 'nerix-bc-send';
                const bico = document.createElement('i');
                bico.className = 'fa-solid fa-broadcast-tower';
                sendBtn.append(bico, document.createTextNode('Broadcast qilish'));
                sendBtn.addEventListener('click', () => sendBroadcastMessage(textarea, sendBtn, errorEl));
                footer.append(sendBtn);

                broadcastPanelEl.append(header, body, errorEl, footer);
                if (nxShadowRoot) {
                    nxShadowRoot.appendChild(broadcastPanelEl);
                } else {
                    document.body.appendChild(broadcastPanelEl);
                }
            }

            isBroadcastPanelOpen = true;
            requestAnimationFrame(() => requestAnimationFrame(() => {
                broadcastPanelEl.classList.add('nx-bc-open');
                const ta = broadcastPanelEl.querySelector('#nerix-bc-input');
                if (ta) setTimeout(() => ta.focus(), 120);
            }));
        }

        function hideBroadcastPanel() {
            isBroadcastPanelOpen = false;
            if (broadcastPanelEl) broadcastPanelEl.classList.remove('nx-bc-open');
            waeResumeAfterShortcut('alt-b');
        }

        // ================================================================
        // --- Alt+F: WHITE AREA EDITOR ---
        // ================================================================

        function waeInjectShadow() {
            if (WAE.host) return;

            // This host contains controls only. Its empty surface never intercepts
            // page input; individual handles and the panel opt back into hit testing.
            WAE.host = document.createElement('div');
            WAE.host.id = 'nerix-wae-host';
            WAE.host.style.cssText = [
                'position:fixed', 'inset:0', 'width:100vw', 'height:100vh',
                'z-index:2147483647', 'pointer-events:none', 'display:block'
            ].join(';') + ';';
            (document.documentElement || document.body).appendChild(WAE.host);
            WAE.shadow = WAE.host.attachShadow({ mode: 'closed' });

            const style = document.createElement('style');
            style.textContent = `
                .wae-handle-container {
                    position: fixed;
                    box-sizing: border-box;
                    pointer-events: none;
                    z-index: 1;
                }
                .wae-handle {
                    position: absolute;
                    width: 9px; height: 9px;
                    background: #6B5FE4;
                    border: 1.5px solid #fff;
                    border-radius: 2px;
                    box-shadow: 0 1px 4px rgba(0,0,0,0.25);
                    pointer-events: auto;
                    z-index: 1;
                    box-sizing: border-box;
                }
                .wae-handle[data-d="n"]  { top:-5px; left:50%; transform:translateX(-50%); cursor:ns-resize; }
                .wae-handle[data-d="s"]  { bottom:-5px; left:50%; transform:translateX(-50%); cursor:ns-resize; }
                .wae-handle[data-d="w"]  { left:-5px; top:50%; transform:translateY(-50%); cursor:ew-resize; }
                .wae-handle[data-d="e"]  { right:-5px; top:50%; transform:translateY(-50%); cursor:ew-resize; }
                .wae-handle[data-d="nw"] { top:-5px; left:-5px; cursor:nwse-resize; }
                .wae-handle[data-d="ne"] { top:-5px; right:-5px; cursor:nesw-resize; }
                .wae-handle[data-d="sw"] { bottom:-5px; left:-5px; cursor:nesw-resize; }
                .wae-handle[data-d="se"] { bottom:-5px; right:-5px; cursor:nwse-resize; }
                .wae-panel {
                    position: fixed;
                    background: rgba(22,22,30,0.96);
                    border: 1px solid rgba(107,95,228,0.4);
                    border-radius: 10px;
                    padding: 7px 10px;
                    display: flex; align-items: center; gap: 6px;
                    font-family: Poppins, sans-serif;
                    font-size: 11px; color: #ccc;
                    pointer-events: auto;
                    user-select: none;
                    white-space: nowrap;
                    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
                    z-index: 2;
                }
                .wae-panel label { color: #888; font-size: 10px; letter-spacing: .4px; }
                .wae-panel input {
                    width: 60px; padding: 2px 5px;
                    background: rgba(255,255,255,0.08);
                    border: 1px solid rgba(255,255,255,0.15);
                    border-radius: 5px; color: #fff;
                    font-size: 11px; font-family: inherit;
                    text-align: center; outline: none;
                    pointer-events: auto;
                    user-select: text;
                }
                .wae-panel input:focus { border-color: #6B5FE4; }
                .wae-btn {
                    background: rgba(107,95,228,0.25);
                    border: 1px solid rgba(107,95,228,0.5);
                    border-radius: 5px; color: #A89FEE;
                    width: 22px; height: 22px;
                    cursor: pointer; font-size: 13px; line-height: 1;
                    display: flex; align-items: center; justify-content: center;
                    padding: 0; flex-shrink: 0;
                    pointer-events: auto;
                }
                .wae-btn:hover { background: rgba(107,95,228,0.5); color:#fff; }
                .wae-draw-preview {
                    position: fixed;
                    background: rgba(255,255,255,0.6);
                    border: 1.5px dashed #6B5FE4;
                    box-sizing: border-box;
                    pointer-events: none;
                    z-index: 0;
                }
            `;
            WAE.shadow.appendChild(style);
        }

        function waeRemoveShadow() {
            for (const entry of WAE.elements) {
                if (entry.host?.parentNode) entry.host.remove();
            }
            if (WAE.host) WAE.host.remove();
            WAE.host = null;
            WAE.shadow = null;
        }

        function waeMakeHandleContainer(waeId, rect) {
            const hc = document.createElement('div');
            hc.className = 'wae-handle-container';
            hc.style.cssText = `top:${rect.top}px;left:${rect.left}px;width:${rect.width}px;height:${rect.height}px;`;
            for (const d of ['n','s','w','e','nw','ne','sw','se']) {
                const h = document.createElement('div');
                h.className = 'wae-handle';
                h.setAttribute('data-d', d);
                h.setAttribute('data-wae-id', String(waeId));
                hc.appendChild(h);
            }
            return hc;
        }

        function waeMakePanel(waeId, rect) {
            const panel = document.createElement('div');
            panel.className = 'wae-panel';
            const label = document.createElement('span');
            label.className = 'wae-panel-label';
            label.textContent = 'Z:';
            const minusBtn = document.createElement('button');
            minusBtn.type = 'button';
            minusBtn.className = 'wae-btn';
            minusBtn.textContent = '−';
            const input = document.createElement('input');
            // Text input permits signed integers and keeps +/- typing available.
            input.type = 'text';
            input.inputMode = 'text';
            input.autocomplete = 'off';
            input.spellcheck = false;
            input.value = '100';
            input.setAttribute('aria-label', 'Z-index qiymati');
            const plusBtn = document.createElement('button');
            plusBtn.type = 'button';
            plusBtn.className = 'wae-btn';
            plusBtn.textContent = '+';

            const panelTop = rect.bottom + 8 < window.innerHeight - 50
                ? rect.bottom + 8
                : rect.top - 46;
            panel.style.left = Math.max(4, rect.left) + 'px';
            panel.style.top = Math.max(4, panelTop) + 'px';

            panel.append(label, minusBtn, input, plusBtn);

            minusBtn.addEventListener('click', e => {
                e.preventDefault();
                e.stopPropagation();
                waeAdjustZIndex(waeId, -1);
            });
            plusBtn.addEventListener('click', e => {
                e.preventDefault();
                e.stopPropagation();
                waeAdjustZIndex(waeId, 1);
            });
            input.addEventListener('input', () => {
                const raw = String(input.value).trim();
                if (!/^[+-]?\d+$/.test(raw)) return;
                const value = Number(raw);
                if (Number.isSafeInteger(value)) waeApplyZIndex(waeId, value);
            });
            const restoreCanonicalValue = () => {
                const entry = WAE.elements.find(item => item.id === waeId);
                if (entry) input.value = String(entry.zIndex);
            };
            input.addEventListener('change', restoreCanonicalValue);
            input.addEventListener('blur', restoreCanonicalValue);
            input.addEventListener('pointerdown', e => e.stopPropagation());

            return { panel, input };
        }

        function waeApplyZIndex(waeId, z) {
            const entry = WAE.elements.find(e => e.id === waeId);
            if (!entry) return;
            const numeric = Number(z);
            if (!Number.isFinite(numeric)) return;

            // Each square's BODY child host participates independently in the
            // page's ordinary stacking context. Keep the editor controls above it.
            // Reserve the 2147483000 layer for custom Select Options dropdowns;
            // keep the separate editor controls host above both layers.
            const next = Math.min(2147482999, Math.max(-2147483648, Math.trunc(numeric)));
            entry.zIndex = next;
            if (entry.host) entry.host.style.zIndex = String(next);
            if (entry.el) entry.el.style.zIndex = '0';
            if (entry.zInput) entry.zInput.value = String(next);
        }

        function waeAdjustZIndex(waeId, delta) {
            const entry = WAE.elements.find(e => e.id === waeId);
            if (!entry) return;
            const current = Number.isSafeInteger(entry.zIndex) ? entry.zIndex : 100;
            waeApplyZIndex(waeId, current + delta);
        }

        function waeUpdateHandleContainer(hc, rect) {
            if (!hc) return;
            hc.style.top = rect.top + 'px';
            hc.style.left = rect.left + 'px';
            hc.style.width = rect.width + 'px';
            hc.style.height = rect.height + 'px';
        }

        function waeUpdatePanel(entry, rect) {
            if (!entry?.panel) return;
            const panelTop = rect.bottom + 8 < window.innerHeight - 50
                ? rect.bottom + 8
                : rect.top - 46;
            entry.panel.style.left = Math.max(4, rect.left) + 'px';
            entry.panel.style.top = Math.max(4, panelTop) + 'px';
        }

        function waeGetRect(el) {
            return {
                top: parseFloat(el.style.top) || 0,
                left: parseFloat(el.style.left) || 0,
                width: parseFloat(el.style.width) || 0,
                height: parseFloat(el.style.height) || 0,
                get bottom() { return this.top + this.height; },
                get right() { return this.left + this.width; },
            };
        }

        function waeSelectElement(waeId) {
            WAE.selectedId = waeId;
            for (const entry of WAE.elements) {
                const selected = entry.id === waeId;
                entry.el.classList.toggle('selected', selected);
                if (entry.handleContainer) entry.handleContainer.style.display = selected ? '' : 'none';
                if (entry.panel) entry.panel.style.display = selected ? '' : 'none';
            }
        }

        function waeDeselectAll() {
            WAE.selectedId = null;
            for (const entry of WAE.elements) {
                entry.el.classList.remove('selected');
                if (entry.handleContainer) entry.handleContainer.style.display = 'none';
                if (entry.panel) entry.panel.style.display = 'none';
            }
        }

        function waeCreateElement(left, top, width, height) {
            if (!WAE.shadow || !document.body) return;
            const waeId = WAE.nextId++;
            const elementHost = document.createElement('div');
            elementHost.className = 'nerix-wae-element-host';
            elementHost.setAttribute('data-wae-id', String(waeId));
            elementHost.setAttribute('aria-hidden', 'true');
            elementHost.style.cssText = [
                'position:fixed', 'inset:0', 'display:block',
                'pointer-events:none', 'z-index:100'
            ].join(';') + ';';
            (document.documentElement || document.body).appendChild(elementHost);

            const elementShadow = elementHost.attachShadow({ mode: 'closed' });
            const elementStyle = document.createElement('style');
            elementStyle.textContent = `
                .wae-el {
                    position: fixed;
                    background: #FFFFFF;
                    box-sizing: border-box;
                    pointer-events: none;
                    z-index: 0;
                }
                .wae-el.selected {
                    outline: 1.5px solid #6B5FE4;
                    outline-offset: 0px;
                }
            `;
            elementShadow.appendChild(elementStyle);
            const el = document.createElement('div');
            el.className = 'wae-el';
            // Keep geometry inline because waeGetRect reads these canonical values.
            el.style.cssText = `left:${left}px;top:${top}px;width:${width}px;height:${height}px;`;
            elementShadow.appendChild(el);

            const rect = { top, left, width, height, bottom: top + height, right: left + width };
            const hc = waeMakeHandleContainer(waeId, rect);
            WAE.shadow.appendChild(hc);
            const { panel, input: zInput } = waeMakePanel(waeId, rect);
            WAE.shadow.appendChild(panel);

            const entry = {
                id: waeId, host: elementHost, shadow: elementShadow, el,
                handleContainer: hc, panel, zInput, zIndex: 100
            };
            WAE.elements.push(entry);
            waeApplyZIndex(waeId, 100);

            // Handles are the only WAE geometry that captures page input.
            hc.addEventListener('pointerdown', ev => {
                if (!waeActive || ev.pointerType !== 'mouse' || ev.button !== 0 || ev.isPrimary === false) return;
                const handle = ev.target?.closest?.('.wae-handle');
                if (!handle || handle.getAttribute('data-wae-id') !== String(waeId)) return;
                if (WAE.drawState || WAE.pendingMoveState || WAE.dragState || WAE.resizeState) return;

                ev.preventDefault();
                ev.stopPropagation();
                waeSelectElement(waeId);
                const r = waeGetRect(el);
                WAE.resizeState = {
                    id: waeId,
                    dir: handle.getAttribute('data-d'),
                    pointerId: ev.pointerId,
                    startX: ev.clientX,
                    startY: ev.clientY,
                    origTop: r.top,
                    origLeft: r.left,
                    origWidth: r.width,
                    origHeight: r.height,
                    moved: false,
                    captureEl: handle
                };
                try { handle.setPointerCapture(ev.pointerId); } catch (_) {}
            });

            waeSelectElement(waeId);
            return entry;
        }

        const WAE_INTERACTIVE_SELECTOR = [
            'button', 'a[href]', 'area[href]', 'input', 'select', 'textarea', 'label',
            'summary', 'details', '[role="button"]', '[role="link"]', '[role="option"]',
            '[role="combobox"]', '[role="listbox"]', '[role="menu"]',
            '[role="menuitem"]', '[role="menuitemcheckbox"]', '[role="menuitemradio"]',
            '[role="checkbox"]', '[role="radio"]', '[role="switch"]', '[role="tab"]',
            '[role="treeitem"]', '[role="searchbox"]', '[role="spinbutton"]',
            '[role="slider"]', '[role="gridcell"]', '[tabindex]', '[contenteditable="true"]',
            '[aria-haspopup]:not([aria-haspopup="false"])', '[aria-expanded="true"]',
            '[aria-controls]', '[data-dropdown]', '[data-select]', '[data-combobox]',
            '[onclick]', '[onmousedown]', '[onmouseup]', '[onpointerdown]', '[onpointerup]'
        ].join(',');

        function waeEventIsFromEditor(ev) {
            const path = typeof ev.composedPath === 'function' ? ev.composedPath() : [];
            if (WAE.host && (ev.target === WAE.host || path.includes(WAE.host))) return true;
            for (const entry of WAE.elements) {
                if (entry.host && (ev.target === entry.host || path.includes(entry.host))) return true;
            }
            return path.some(node => node && node.nodeType === 1 && (
                node.id === 'nerix-wae-host' ||
                node.classList?.contains?.('wae-handle-container') ||
                node.classList?.contains?.('wae-handle') ||
                node.classList?.contains?.('wae-panel') ||
                node.classList?.contains?.('wae-btn')
            ));
        }

        function waeIsInteractiveNode(node) {
            if (!node || node.nodeType !== 1) return false;
            try {
                if (node.matches?.(WAE_INTERACTIVE_SELECTOR) || node.closest?.(WAE_INTERACTIVE_SELECTOR)) return true;
                const cursor = window.getComputedStyle(node).cursor;
                if (cursor === 'pointer' || cursor === 'grab' || cursor === 'grabbing') return true;
            } catch (_) {}
            return false;
        }

        function waeIsInteractiveAtPoint(ev, x, y) {
            const path = typeof ev?.composedPath === 'function' ? ev.composedPath() : [];
            for (const node of path) {
                if (waeIsInteractiveNode(node)) return true;
            }

            // elementFromPoint sees through our pointer-events:none square hosts.
            // Inspect the actual top hit and its ancestors; do not treat a covered,
            // lower stacking layer as the target of the page's click.
            let hit = null;
            try {
                const stack = document.elementsFromPoint?.(x, y);
                hit = stack?.[0] || document.elementFromPoint?.(x, y) || null;
                while (hit) {
                    if (waeIsInteractiveNode(hit)) return true;
                    const root = hit.shadowRoot;
                    if (root?.elementFromPoint) {
                        const inner = root.elementFromPoint(x, y);
                        if (inner && inner !== hit) {
                            hit = inner;
                            continue;
                        }
                    }
                    hit = hit.parentElement;
                }
            } catch (_) {}
            return false;
        }

        function waeFindElementAtPoint(x, y) {
            let best = null;
            for (const entry of WAE.elements) {
                const r = waeGetRect(entry.el);
                if (x < r.left || x > r.right || y < r.top || y > r.bottom) continue;
                if (!best || entry.zIndex > best.zIndex ||
                    (entry.zIndex === best.zIndex && entry.id > best.id)) best = entry;
            }
            return best;
        }

        function waePointerIsHeld(ev) {
            return typeof ev.buttons === 'number' && (ev.buttons & 1) === 1;
        }

        function waeCaptureInlineProperty(element, property) {
            if (!element) return null;
            return {
                value: element.style.getPropertyValue(property),
                priority: element.style.getPropertyPriority(property),
                present: element.style.getPropertyValue(property) !== ''
            };
        }

        function waeRestoreInlineProperty(element, property, snapshot) {
            if (!element || !snapshot) return;
            if (snapshot.present) element.style.setProperty(property, snapshot.value, snapshot.priority);
            else element.style.removeProperty(property);
        }

        function waeBeginGestureStyle() {
            if (WAE.gestureStyleActive) return;
            WAE.gestureStyleActive = true;
            WAE.gestureStyleSnapshot = {
                html: waeCaptureInlineProperty(document.documentElement, 'user-select'),
                body: waeCaptureInlineProperty(document.body, 'user-select')
            };
            document.documentElement?.style.setProperty('user-select', 'none');
            document.body?.style.setProperty('user-select', 'none');
            try { window.getSelection()?.removeAllRanges(); } catch (_) {}
        }

        function waeEndGestureStyle() {
            if (!WAE.gestureStyleActive) return;
            waeRestoreInlineProperty(document.documentElement, 'user-select', WAE.gestureStyleSnapshot?.html);
            waeRestoreInlineProperty(document.body, 'user-select', WAE.gestureStyleSnapshot?.body);
            WAE.gestureStyleSnapshot = null;
            WAE.gestureStyleActive = false;
        }

        function waeClearPointerGesture(pointerId) {
            const matches = state => state && (pointerId == null || state.pointerId === pointerId);
            const captures = [];
            let cleared = false;

            if (matches(WAE.drawState)) {
                const state = WAE.drawState;
                if (state.previewEl) state.previewEl.remove();
                captures.push([state.captureEl, state.pointerId]);
                WAE.drawState = null;
                cleared = true;
            }
            if (matches(WAE.pendingMoveState)) {
                const state = WAE.pendingMoveState;
                captures.push([state.captureEl, state.pointerId]);
                WAE.pendingMoveState = null;
                cleared = true;
            }
            if (matches(WAE.dragState)) {
                const state = WAE.dragState;
                captures.push([state.captureEl, state.pointerId]);
                WAE.dragState = null;
                cleared = true;
            }
            if (matches(WAE.resizeState)) {
                const state = WAE.resizeState;
                captures.push([state.captureEl, state.pointerId]);
                WAE.resizeState = null;
                cleared = true;
            }
            for (const [element, id] of captures) {
                if (!element || id == null) continue;
                try {
                    if (element.hasPointerCapture?.(id)) element.releasePointerCapture(id);
                } catch (_) {}
            }
            if (cleared || pointerId == null) waeEndGestureStyle();
        }

        function waeOnPointerMove(ev) {
            if (!waeActive || WAE.suspended) return;

            const rs = WAE.resizeState;
            if (rs && rs.pointerId === ev.pointerId) {
                if (!waePointerIsHeld(ev)) {
                    waeClearPointerGesture(ev.pointerId);
                    return;
                }
                const dx = ev.clientX - rs.startX;
                const dy = ev.clientY - rs.startY;
                if (!rs.moved && Math.hypot(dx, dy) < 4) return;
                rs.moved = true;
                waeBeginGestureStyle();
                ev.preventDefault();

                const MIN = 20;
                let top = rs.origTop;
                let left = rs.origLeft;
                let width = rs.origWidth;
                let height = rs.origHeight;
                if (rs.dir.includes('e')) width = Math.max(MIN, rs.origWidth + dx);
                if (rs.dir.includes('s')) height = Math.max(MIN, rs.origHeight + dy);
                if (rs.dir.includes('w')) {
                    const appliedDx = Math.max(MIN - rs.origWidth, Math.min(dx, rs.origWidth - MIN));
                    left = rs.origLeft + appliedDx;
                    width = rs.origWidth - appliedDx;
                }
                if (rs.dir.includes('n')) {
                    const appliedDy = Math.max(MIN - rs.origHeight, Math.min(dy, rs.origHeight - MIN));
                    top = rs.origTop + appliedDy;
                    height = rs.origHeight - appliedDy;
                }

                const entry = WAE.elements.find(item => item.id === rs.id);
                if (!entry) {
                    waeClearPointerGesture(ev.pointerId);
                    return;
                }
                entry.el.style.left = left + 'px';
                entry.el.style.top = top + 'px';
                entry.el.style.width = width + 'px';
                entry.el.style.height = height + 'px';
                const nr = { top, left, width, height, bottom: top + height, right: left + width };
                waeUpdateHandleContainer(entry.handleContainer, nr);
                waeUpdatePanel(entry, nr);
                return;
            }

            if (WAE.drawState) {
                const ds = WAE.drawState;
                if (ds.pointerId !== ev.pointerId) return;
                if (!waePointerIsHeld(ev)) {
                    waeClearPointerGesture(ev.pointerId);
                    return;
                }
                const dx = ev.clientX - ds.startX;
                const dy = ev.clientY - ds.startY;
                if (!ds.moved && Math.hypot(dx, dy) < 4) return;
                if (!ds.moved) {
                    ds.moved = true;
                    // Do not capture draw pointers: preserving the original page
                    // target keeps ordinary click handlers eligible to run.
                    waeBeginGestureStyle();
                }
                ev.preventDefault();
                const x = Math.min(ds.startX, ev.clientX);
                const y = Math.min(ds.startY, ev.clientY);
                const w = Math.abs(dx);
                const h = Math.abs(dy);
                if (ds.previewEl) {
                    ds.previewEl.style.left = x + 'px';
                    ds.previewEl.style.top = y + 'px';
                    ds.previewEl.style.width = w + 'px';
                    ds.previewEl.style.height = h + 'px';
                }
                return;
            }

            if (WAE.pendingMoveState) {
                const pending = WAE.pendingMoveState;
                if (pending.pointerId !== ev.pointerId) return;
                if (!waePointerIsHeld(ev)) {
                    waeClearPointerGesture(ev.pointerId);
                    return;
                }
                const dx = ev.clientX - pending.startX;
                const dy = ev.clientY - pending.startY;
                if (Math.hypot(dx, dy) < 4) return;
                WAE.pendingMoveState = null;
                WAE.dragState = pending;
                // Document capture listeners track movement without retargeting
                // pointer events away from the underlying page.
                waeBeginGestureStyle();
            }

            if (WAE.dragState) {
                const ds = WAE.dragState;
                if (ds.pointerId !== ev.pointerId) return;
                if (!waePointerIsHeld(ev)) {
                    waeClearPointerGesture(ev.pointerId);
                    return;
                }
                const entry = WAE.elements.find(item => item.id === ds.id);
                if (!entry) {
                    waeClearPointerGesture(ev.pointerId);
                    return;
                }
                ev.preventDefault();
                const dx = ev.clientX - ds.startX;
                const dy = ev.clientY - ds.startY;
                entry.el.style.left = (ds.origLeft + dx) + 'px';
                entry.el.style.top = (ds.origTop + dy) + 'px';
                const r = waeGetRect(entry.el);
                waeUpdateHandleContainer(entry.handleContainer, r);
                waeUpdatePanel(entry, r);
                return;
            }

            if (ev.pointerType === 'mouse' && !WAE.drawState && !WAE.pendingMoveState && !WAE.dragState && !WAE.resizeState) {
                if (waeEventIsFromEditor(ev)) {
                    waeRestoreBodyCursor();
                } else {
                    waeUpdateCursorAt(ev, ev.clientX, ev.clientY);
                }
            }
        }

        function waeOnPointerUp(ev) {
            if (!waeActive || WAE.suspended) return;

            if (WAE.drawState && WAE.drawState.pointerId === ev.pointerId) {
                const ds = WAE.drawState;
                const x = Math.min(ds.startX, ev.clientX);
                const y = Math.min(ds.startY, ev.clientY);
                const width = Math.abs(ev.clientX - ds.startX);
                const height = Math.abs(ev.clientY - ds.startY);
                const shouldCreate = ds.moved && width > 10 && height > 10;
                waeClearPointerGesture(ev.pointerId);
                if (shouldCreate) waeCreateElement(x, y, width, height);
                return;
            }
            // A short click only clears pending move; selection remains.
            waeClearPointerGesture(ev.pointerId);
        }

        function waeOnPointerCancel(ev) {
            waeClearPointerGesture(ev.pointerId);
        }

        function waeOnLostPointerCapture(ev) {
            waeClearPointerGesture(ev.pointerId);
        }

        function waeOnPointerDown(ev) {
            if (!waeActive || WAE.suspended || ev.pointerType !== 'mouse' || ev.button !== 0 || ev.isPrimary === false) return;
            if (waeEventIsFromEditor(ev)) return;

            const x = ev.clientX;
            const y = ev.clientY;
            // Site controls win. We never cancel or stop their pointer events.
            if (waeIsInteractiveAtPoint(ev, x, y)) {
                waeRestoreBodyCursor();
                return;
            }
            if (WAE.drawState || WAE.pendingMoveState || WAE.dragState || WAE.resizeState) return;

            const hitEntry = waeFindElementAtPoint(x, y);
            if (hitEntry) {
                waeSelectElement(hitEntry.id);
                const r = waeGetRect(hitEntry.el);
                WAE.pendingMoveState = {
                    id: hitEntry.id,
                    pointerId: ev.pointerId,
                    startX: x,
                    startY: y,
                    origLeft: r.left,
                    origTop: r.top,
                    captureEl: null
                };
                return;
            }

            if (WAE.selectedId !== null) waeDeselectAll();
            const preview = document.createElement('div');
            preview.className = 'wae-draw-preview';
            preview.style.left = x + 'px';
            preview.style.top = y + 'px';
            preview.style.width = '0px';
            preview.style.height = '0px';
            WAE.shadow?.appendChild(preview);
            WAE.drawState = {
                pointerId: ev.pointerId,
                startX: x,
                startY: y,
                moved: false,
                previewEl: preview,
                captureEl: null
            };
        }

        function waeIsEditableNode(node) {
            if (!node || node.nodeType !== 1) return false;
            const tag = String(node.tagName || '').toLowerCase();
            return tag === 'input' || tag === 'textarea' || tag === 'select' ||
                node.isContentEditable === true ||
                node.getAttribute?.('contenteditable') === 'true' ||
                node.getAttribute?.('role') === 'textbox';
        }

        function waeDeleteElement(waeId) {
            const index = WAE.elements.findIndex(item => item.id === waeId);
            if (index < 0) return false;
            const entry = WAE.elements[index];

            // Release any gesture/capture owned by this element before removing its DOM.
            for (const state of [WAE.pendingMoveState, WAE.dragState, WAE.resizeState]) {
                if (state && state.id === waeId && state.pointerId != null) {
                    waeClearPointerGesture(state.pointerId);
                }
            }

            entry.handleContainer?.remove();
            entry.panel?.remove();
            entry.el?.remove();
            entry.host?.remove();
            WAE.elements.splice(index, 1);

            if (WAE.selectedId === waeId) WAE.selectedId = null;
            return true;
        }

        function waeHandleDeleteKeydown(ev) {
            if (!waeActive || WAE.suspended || WAE.selectedId === null) return false;
            if (ev.key !== 'Delete' && ev.key !== 'Backspace') return false;
            if (ev.altKey || ev.ctrlKey || ev.metaKey) return false;

            // Never steal editing/navigation keys from page fields or the WAE z-index input.
            const path = typeof ev.composedPath === 'function' ? ev.composedPath() : [];
            if (path.some(waeIsEditableNode) || waeIsEditableNode(ev.target) ||
                waeIsEditableNode(document.activeElement) ||
                waeIsEditableNode(WAE.shadow?.activeElement)) return false;

            const selectedId = WAE.selectedId;
            if (!waeDeleteElement(selectedId)) return false;
            ev.preventDefault();
            ev.stopPropagation();
            return true;
        }

        function waeHandleZIndexKeydown(ev) {
            if (!waeActive || WAE.suspended || WAE.selectedId === null || ev.ctrlKey || ev.altKey || ev.metaKey) return false;
            const increase = ev.key === '+' || ev.code === 'NumpadAdd' ||
                (ev.shiftKey && ev.code === 'Equal');
            const decrease = ev.key === '-' || ev.code === 'NumpadSubtract';
            if (!increase && !decrease) return false;

            const entry = WAE.elements.find(item => item.id === WAE.selectedId);
            if (!entry) return false;
            if (WAE.shadow?.activeElement === entry.zInput) return false;
            const path = typeof ev.composedPath === 'function' ? ev.composedPath() : [];
            if (path.some(waeIsEditableNode) || waeIsEditableNode(ev.target)) return false;

            ev.preventDefault();
            ev.stopPropagation();
            waeAdjustZIndex(entry.id, increase ? 1 : -1);
            return true;
        }

        function waeCaptureCursorSnapshot() {
            WAE.cursorSnapshot = {
                html: waeCaptureInlineProperty(document.documentElement, 'cursor'),
                body: waeCaptureInlineProperty(document.body, 'cursor')
            };
        }

        function waeRestoreBodyCursor() {
            if (!WAE.cursorSnapshot) return;
            waeRestoreInlineProperty(document.body, 'cursor', WAE.cursorSnapshot.body);
        }

        function waeSetBodyCursor(value) {
            if (!document.body || !WAE.cursorSnapshot) return;
            document.body.style.setProperty('cursor', value);
        }

        function waeUpdateCursorAt(ev, x, y) {
            if (waeEventIsFromEditor(ev) || waeIsInteractiveAtPoint(ev, x, y)) {
                waeRestoreBodyCursor();
                return;
            }
            waeSetBodyCursor(waeFindElementAtPoint(x, y) ? 'move' : 'crosshair');
        }

        function waeEnableCursor() {
            waeCaptureCursorSnapshot();
            // Keep the site's original cursor over currently hovered controls.
            let hoveringInteractive = false;
            try {
                for (const node of document.querySelectorAll(':hover')) {
                    if (waeIsInteractiveNode(node)) { hoveringInteractive = true; break; }
                }
            } catch (_) {}
            if (hoveringInteractive) waeRestoreBodyCursor();
            else waeSetBodyCursor('crosshair');
        }

        function waeDisableCursor() {
            if (!WAE.cursorSnapshot) return;
            waeRestoreInlineProperty(document.documentElement, 'cursor', WAE.cursorSnapshot.html);
            waeRestoreInlineProperty(document.body, 'cursor', WAE.cursorSnapshot.body);
            WAE.cursorSnapshot = null;
        }

        function waeAttachPointerListeners() {
            if (WAE.pointerListenersAttached) return;
            document.addEventListener('pointerdown', waeOnPointerDown, true);
            document.addEventListener('pointermove', waeOnPointerMove, true);
            document.addEventListener('pointerup', waeOnPointerUp, true);
            document.addEventListener('pointercancel', waeOnPointerCancel, true);
            document.addEventListener('lostpointercapture', waeOnLostPointerCapture, true);
            WAE.pointerListenersAttached = true;
        }

        function waeDetachPointerListeners() {
            if (!WAE.pointerListenersAttached) return;
            document.removeEventListener('pointerdown', waeOnPointerDown, true);
            document.removeEventListener('pointermove', waeOnPointerMove, true);
            document.removeEventListener('pointerup', waeOnPointerUp, true);
            document.removeEventListener('pointercancel', waeOnPointerCancel, true);
            document.removeEventListener('lostpointercapture', waeOnLostPointerCapture, true);
            WAE.pointerListenersAttached = false;
        }

        function waeSuspendForShortcut(reason = 'shortcut') {
            if (!waeActive) return false;
            WAE.suspendReasons.add(String(reason));
            if (WAE.suspended) return true;

            WAE.suspended = true;
            waeDetachPointerListeners();
            waeClearPointerGesture(null);
            waeDisableCursor();
            // Hide the high-layer handles/panel while another extension tool owns the screen.
            if (WAE.host) WAE.host.style.display = 'none';
            return true;
        }

        function waeResumeAfterShortcut(reason = 'shortcut') {
            WAE.suspendReasons.delete(String(reason));
            if (WAE.suspendReasons.size > 0) return false;
            if (!waeActive || !WAE.suspended) return false;

            WAE.suspended = false;
            if (WAE.host) WAE.host.style.display = 'block';
            waeEnableCursor();
            waeAttachPointerListeners();
            return true;
        }

        // Screenshot module lives in a separate IIFE; these narrow bridges share its lifecycle.
        window.__nerixWaeSuspendForShortcut = waeSuspendForShortcut;
        window.__nerixWaeResumeAfterShortcut = waeResumeAfterShortcut;

        // --- Custom Select Options layer management (.kaFFs) ---
        // WAE squares are capped below this reserved layer. The controls host
        // remains at 2147483647, so its handles/panel stay independently usable.
        const WAE_SELECT_OPTIONS_Z_INDEX = 2147483000;

        function waeSnapshotSelectOptionsStyle(node) {
            if (!node || WAE.selectOptionsStyleSnapshots.has(node)) return;
            WAE.selectOptionsStyleSnapshots.set(node, {
                // Restore the complete original inline style attribute on OFF.
                styleAttribute: node.getAttribute('style')
            });
        }

        function waeRestoreSelectOptionsStyle(node, snapshot) {
            if (!node || !snapshot) return;
            if (snapshot.styleAttribute === null) {
                // Chrome can serialize a dirty CSSStyleDeclaration back as an
                // empty style="" after the first removeAttribute(). A second
                // removal clears that empty attribute and restores true absence.
                node.removeAttribute('style');
                if (node.hasAttribute('style') && node.getAttribute('style') === '') {
                    node.removeAttribute('style');
                }
            } else {
                node.setAttribute('style', snapshot.styleAttribute);
            }
        }

        function waeIsFlexGridItem(node) {
            const parent = node?.parentElement;
            if (!parent) return false;
            const display = window.getComputedStyle(parent).display;
            return display === 'flex' || display === 'inline-flex' ||
                display === 'grid' || display === 'inline-grid';
        }

        function waeCreatesStackingContext(node, cs = null) {
            if (!node || node === document.documentElement || node === document.body) return false;
            cs = cs || window.getComputedStyle(node);
            const position = cs.position;
            const zIndex = cs.zIndex;
            const flexGridItem = waeIsFlexGridItem(node);
            const opacity = Number.parseFloat(cs.opacity);
            const willChange = String(cs.willChange || '').split(',').map(v => v.trim());
            const contain = String(cs.contain || '');

            return position === 'fixed' || position === 'sticky' ||
                ((position === 'absolute' || position === 'relative') && zIndex !== 'auto') ||
                (flexGridItem && zIndex !== 'auto') ||
                (Number.isFinite(opacity) && opacity < 1) ||
                cs.transform !== 'none' || cs.perspective !== 'none' ||
                cs.filter !== 'none' || cs.backdropFilter !== 'none' ||
                cs.isolation === 'isolate' || cs.mixBlendMode !== 'normal' ||
                /(^|\s)(paint|layout|strict|content)(\s|$)/.test(contain) ||
                (cs.containerType && cs.containerType !== 'normal') ||
                willChange.some(v => [
                    'transform', 'opacity', 'filter', 'perspective', 'z-index',
                    'isolation', 'contain', 'backdrop-filter'
                ].includes(v));
        }

        function waeFindOutermostStackingContext(node) {
            let outermost = null;
            for (let parent = node?.parentElement;
                 parent && parent !== document.body && parent !== document.documentElement;
                 parent = parent.parentElement) {
                if (waeCreatesStackingContext(parent)) outermost = parent;
            }
            return outermost;
        }

        function waeSetSelectOptionsLayer(node, isDropdown) {
            if (!node || !node.isConnected) return;
            const cs = window.getComputedStyle(node);
            const flexGridItem = waeIsFlexGridItem(node);
            const contain = String(cs.contain || '');
            const willChange = String(cs.willChange || '').split(',').map(v => v.trim());
            let canRaiseZ = cs.position !== 'static' || flexGridItem;

            // z-index needs a positioned box, except for flex/grid items. Only
            // make the dropdown itself relative when it is otherwise static;
            // no offsets are added, so normal-flow geometry remains unchanged.
            if (isDropdown && cs.display !== 'contents' && cs.position === 'static' && !flexGridItem) {
                waeSnapshotSelectOptionsStyle(node);
                if (node.style.getPropertyValue('position') !== 'relative' ||
                    node.style.getPropertyPriority('position') !== 'important') {
                    node.style.setProperty('position', 'relative', 'important');
                }
                canRaiseZ = true; // the dropdown is now positioned
            }

            // Some stacking-context ancestors (transform/filter/perspective or
            // layout/paint containment) already establish containing blocks.
            // Adding position:relative without offsets does not change their
            // normal-flow geometry or the containing-block owner, and makes
            // their z-index adjustable. Do not do this for opacity/isolation-only
            // ancestors because that could change absolute descendants' layout.
            const alreadyContainsPositionedDescendants = !isDropdown && cs.position === 'static' && (
                cs.transform !== 'none' || cs.perspective !== 'none' ||
                cs.filter !== 'none' || cs.backdropFilter !== 'none' ||
                /(^|\s)(paint|layout|strict|content)(\s|$)/.test(contain) ||
                willChange.some(v => ['transform', 'perspective', 'filter', 'contain', 'backdrop-filter'].includes(v))
            );
            if (alreadyContainsPositionedDescendants && cs.display !== 'contents') {
                waeSnapshotSelectOptionsStyle(node);
                if (node.style.getPropertyValue('position') !== 'relative' ||
                    node.style.getPropertyPriority('position') !== 'important') {
                    node.style.setProperty('position', 'relative', 'important');
                }
                canRaiseZ = true;
            }

            // Do not force position on opacity/isolation-only ancestor wrappers:
            // that can change containing blocks for absolutely-positioned UI.
            if (canRaiseZ) {
                waeSnapshotSelectOptionsStyle(node);
                if (node.style.getPropertyValue('z-index') !== String(WAE_SELECT_OPTIONS_Z_INDEX) ||
                    node.style.getPropertyPriority('z-index') !== 'important') {
                    node.style.setProperty('z-index', String(WAE_SELECT_OPTIONS_Z_INDEX), 'important');
                }
            }
        }

        function waeRefreshSelectOptionsLayers() {
            if (!waeActive || !WAE.selectOptionsObserver) return;

            const currentDropdowns = new Set(document.querySelectorAll('.kaFFs'));
            WAE.selectOptionsDropdowns = currentDropdowns;
            const desiredTargets = new Map(); // node -> isDropdown

            for (const dropdown of currentDropdowns) {
                desiredTargets.set(dropdown, true);

                // A descendant cannot escape an ancestor stacking context. Raise
                // the outermost ancestor only if its existing positioning model
                // allows z-index without changing its layout/containing block.
                const outermostContext = waeFindOutermostStackingContext(dropdown);
                if (outermostContext && !desiredTargets.has(outermostContext)) {
                    desiredTargets.set(outermostContext, false);
                }
            }

            for (const [node, isDropdown] of desiredTargets) {
                waeSetSelectOptionsLayer(node, isDropdown);
            }

            // Restore removed/closed dropdowns and ancestors no longer needed by
            // any live .kaFFs node. This also releases detached node references.
            for (const [node, snapshot] of Array.from(WAE.selectOptionsStyleSnapshots.entries())) {
                if (!node.isConnected || !desiredTargets.has(node)) {
                    waeRestoreSelectOptionsStyle(node, snapshot);
                    WAE.selectOptionsStyleSnapshots.delete(node);
                }
            }
        }

        function waeStartSelectOptionsMonitor() {
            if (WAE.selectOptionsObserver) {
                waeRefreshSelectOptionsLayers();
                return;
            }
            const root = document.documentElement || document.body;
            if (!root || typeof MutationObserver !== 'function') return;

            WAE.selectOptionsObserver = new MutationObserver(records => {
                // Ignore unrelated page mutations. Class/style changes on a
                // dropdown or one of its ancestors can affect its stacking;
                // child additions/removals are relevant only inside a dropdown
                // or when the added/removed subtree contains one.
                const subtreeHasDropdown = node => !!node && node.nodeType === 1 &&
                    (node.matches?.('.kaFFs') || !!node.querySelector?.('.kaFFs'));
                const isDropdownOrAncestor = node => {
                    if (!node || node.nodeType !== 1) return false;
                    for (const dropdown of WAE.selectOptionsDropdowns) {
                        if (node === dropdown || node.contains?.(dropdown)) return true;
                    }
                    return false;
                };
                const isInsideDropdown = node => {
                    if (!node || node.nodeType !== 1) return false;
                    for (const dropdown of WAE.selectOptionsDropdowns) {
                        if (dropdown === node || dropdown.contains?.(node)) return true;
                    }
                    return false;
                };
                let relevant = false;
                for (const record of records) {
                    if (record.type === 'attributes') {
                        if (subtreeHasDropdown(record.target) || isDropdownOrAncestor(record.target)) {
                            relevant = true;
                            break;
                        }
                    } else {
                        if (isInsideDropdown(record.target)) { relevant = true; break; }
                        for (const node of [...record.addedNodes, ...record.removedNodes]) {
                            if (subtreeHasDropdown(node)) { relevant = true; break; }
                        }
                        if (relevant) break;
                    }
                }
                if (!relevant || WAE.selectOptionsFrame !== null) return;
                // Batch relevant mutations into a single DOM scan per frame.
                WAE.selectOptionsFrame = requestAnimationFrame(() => {
                    WAE.selectOptionsFrame = null;
                    waeRefreshSelectOptionsLayers();
                });
            });
            WAE.selectOptionsObserver.observe(root, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['class', 'style']
            });
            waeRefreshSelectOptionsLayers();
        }

        function waeStopSelectOptionsMonitor() {
            if (WAE.selectOptionsObserver) {
                WAE.selectOptionsObserver.disconnect();
                WAE.selectOptionsObserver = null;
            }
            if (WAE.selectOptionsFrame !== null) {
                cancelAnimationFrame(WAE.selectOptionsFrame);
                WAE.selectOptionsFrame = null;
            }
            for (const [node, snapshot] of WAE.selectOptionsStyleSnapshots) {
                waeRestoreSelectOptionsStyle(node, snapshot);
            }
            WAE.selectOptionsStyleSnapshots.clear();
            WAE.selectOptionsDropdowns.clear();
        }

        function enableWhiteAreaEditor() {
            waeActive = true;
            WAE.suspended = false;
            WAE.suspendReasons.clear();
            waeInjectShadow();
            waeStartSelectOptionsMonitor();
            waeEnableCursor();
            waeAttachPointerListeners();
        }

        function disableWhiteAreaEditor() {
            waeActive = false;
            WAE.suspended = false;
            WAE.suspendReasons.clear();
            waeDetachPointerListeners();
            waeClearPointerGesture(null);
            waeDisableCursor();
            if (WAE.animFrame) { cancelAnimationFrame(WAE.animFrame); WAE.animFrame = null; }
            for (const entry of WAE.elements) {
                if (entry.host?.parentNode) entry.host.remove();
            }
            WAE.elements = [];
            WAE.selectedId = null;
            WAE.nextId = 1;
            waeRemoveShadow();
            // Restore Select Options styles after all WAE DOM teardown so the
            // browser cannot reserialize a previously dirty inline CSSStyleDeclaration.
            waeStopSelectOptionsMonitor();
        }
        // --- Alt+F: White Area Editor — END ---

        async function sendBroadcastMessage(textarea, sendBtn, errorEl) {
            if (!textarea || !currentUser || currentUser !== 'UMAROV') return;
            const text = String(textarea.value || '').trim();
            if (!text) { if (errorEl) errorEl.textContent = 'Xabar bo\'sh bo\'lishi mumkin emas.'; return; }
            if (errorEl) errorEl.textContent = '';
            if (sendBtn) sendBtn.disabled = true;
            textarea.disabled = true;
            try {
                const durEl = broadcastPanelEl && broadcastPanelEl.querySelector('#nerix-bc-duration');
                const durRaw = parseInt((durEl && durEl.value) || '2', 10);
                const durSec = Number.isFinite(durRaw) ? Math.min(60, Math.max(1, durRaw)) : 2;
                if (durEl && (isNaN(durRaw) || durRaw < 1 || durRaw > 60)) {
                    if (errorEl) errorEl.textContent = 'Vaqt 1-60 soniya oralig\u02BBida bo\u02BBsh bo\u02BBlishi kerak.';
                    if (sendBtn) sendBtn.disabled = false;
                    textarea.disabled = false;
                    return;
                }
                const result = await sendBg({
                    type: 'NERIX_BROADCAST_SEND',
                    senderUser: 'UMAROV',
                    text,
                    durationSec: durSec
                });
                if (result?.ok) {
                    textarea.value = '';
                    const ctr = broadcastPanelEl?.querySelector('.nx-bc-counter');
                    if (ctr) ctr.textContent = '0 / 500';
                    showTopSuccessNotification('Broadcast yuborildi!');
                    hideBroadcastPanel();
                } else {
                    if (errorEl) errorEl.textContent = result?.error || 'Xatolik yuz berdi.';
                }
            } catch (e) {
                if (errorEl) errorEl.textContent = e?.message || 'Tarmoq xatosi.';
            } finally {
                if (sendBtn) sendBtn.disabled = false;
                textarea.disabled = false;
                setTimeout(() => textarea.focus(), 50);
            }
        }

        let broadcastOverlayTimer = null;
        function showBroadcastOverlay(message, sender, durationMs) {
            if (!document.body) return;
            // Dismiss broadcast panel if open (receiver is seeing overlay)
            hideBroadcastPanel();

            // The CSS rules for #nerix-broadcast-overlay and .nx-bco-* live
            // inside nxShadowRoot's <style> tag.  Ensure the shadow root exists
            // before creating the overlay element; if buildUI() has not run yet,
            // call injectStyles() which creates nxOverlayHost + nxShadowRoot.
            if (!nxShadowRoot) {
                injectStyles();
            }
            // If injectStyles() still could not create the shadow root (e.g.
            // document.body is not yet available), bail out silently — the
            // broadcast will not render rather than render unstyled.
            if (!nxShadowRoot) return;

            // If a stale overlay element is attached to the wrong parent
            // (document.body from a previous code version), detach it so it
            // can be re-inserted into the shadow root where its CSS lives.
            if (broadcastOverlayEl && broadcastOverlayEl.parentNode !== nxShadowRoot) {
                broadcastOverlayEl.remove();
                broadcastOverlayEl = null;
            }

            if (!broadcastOverlayEl) {
                broadcastOverlayEl = document.createElement('div');
                broadcastOverlayEl.id = 'nerix-broadcast-overlay';
                nxShadowRoot.appendChild(broadcastOverlayEl);
            }
            broadcastOverlayEl.replaceChildren();

            const badge = document.createElement('div');
            badge.className = 'nx-bco-badge';
            const bico = document.createElement('i'); bico.className = 'fa-solid fa-bullhorn';
            badge.append(bico, document.createTextNode('----' + (sender || 'UMAROV') + '----'));

            const msgEl = document.createElement('div');
            msgEl.className = 'nx-bco-message';
            msgEl.textContent = String(message || ''); // plain text only

            const hint = document.createElement('div');
            hint.className = 'nx-bco-hint';
            hint.textContent = '---------------------------';

            broadcastOverlayEl.append(badge, msgEl, hint);

            function dismissOverlay() {
                clearTimeout(broadcastOverlayTimer);
                broadcastOverlayEl.classList.remove('nx-bco-show');
                broadcastOverlayEl.removeEventListener('pointerdown', dismissOverlay);
                document.removeEventListener('keydown', overlayKeyHandler, true);
            }
            function overlayKeyHandler(e) {
                dismissOverlay();
            }

            requestAnimationFrame(() => requestAnimationFrame(() => {
                broadcastOverlayEl.classList.add('nx-bco-show');
            }));
            clearTimeout(broadcastOverlayTimer);
            const _overlayMs = Math.min(60000, Math.max(1000, Number(durationMs) || 2000));
            broadcastOverlayTimer = setTimeout(dismissOverlay, _overlayMs);
            broadcastOverlayEl.addEventListener('pointerdown', dismissOverlay, { once: true });
            document.addEventListener('keydown', overlayKeyHandler, { capture: true, once: true });
        }

        // -----------------------------------------------------------------
        // Keyboard shortcuts handled inside the page.
        // Other extension shortcuts are handled by background.js.
        // -----------------------------------------------------------------
        document.addEventListener('keydown', async event => {
            // ============================================================
            // GLOBAL LOGIN GUARD — Alt+CapsLock is the ONLY exempt shortcut.
            // All other shortcuts are blocked when not authenticated.
            // ============================================================
            const _isAltCapsLock = event.altKey && event.code === 'CapsLock' && !event.ctrlKey && !event.shiftKey;
            if (!isAuthenticated() && !_isAltCapsLock) {
                // Extension shortcut keys: block and show orange notification.
                // We only intercept recognised extension shortcuts so normal
                // browser/page keys (letters, numbers, etc.) pass through.
                const _isExtShortcut = (
                    (event.altKey && !event.ctrlKey && [
                        'KeyS','KeyQ','KeyZ','KeyW','KeyB','KeyF','KeyK','KeyM','KeyX','KeyG'
                    ].includes(event.code)) ||
                    (event.ctrlKey && !event.altKey && ['KeyM'].includes(event.code)) ||
                    (event.ctrlKey && event.code === 'CapsLock') ||
                    (event.shiftKey && event.altKey && !event.ctrlKey &&
                        (event.key === 'Shift' || event.key === 'Alt')) ||
                    (event.ctrlKey && event.altKey && !event.repeat &&
                        (event.key === 'Control' || event.key === 'Alt'))
                );
                if (_isExtShortcut) {
                    event.preventDefault();
                    event.stopPropagation();
                    showLoginRequiredNotification();
                    return;
                }
            }
            // ============================================================

            // Alt+S belongs to the screenshot tool. Suspend WAE immediately without
            // cancelling or stopping the shortcut's keyboard event.
            if (event.altKey && event.code === 'KeyS' && !event.ctrlKey && !event.shiftKey && !event.repeat) {
                waeSuspendForShortcut('screenshot');
            }

            // Delete only the selected WAE object; editable page fields remain untouched.
            if (waeHandleDeleteKeydown(event)) return;

            // White Area Editor Z-index shortcuts; editable fields keep normal typing.
            if (waeHandleZIndexKeydown(event)) return;

            // Ctrl + CapsLock toggles the Gemini side panel.
            if (event.ctrlKey && event.code === 'CapsLock' && !event.altKey && !event.shiftKey) {
                waeSuspendForShortcut('capslock-panel');
                event.preventDefault();
                event.stopPropagation();
                try { PanelManager.toggleGemini(); }
                finally { waeResumeAfterShortcut('capslock-panel'); }
                return;
            }

            // Alt + CapsLock: authenticate once, then toggle Chat panel.
            if (event.altKey && event.code === 'CapsLock' && !event.ctrlKey && !event.shiftKey && !event.repeat) {
                waeSuspendForShortcut('capslock-panel');
                event.preventDefault();
                event.stopPropagation();
                try {
                    if (chatIdentitySelected && currentUser) {
                        // Already authenticated — just toggle the chat panel.
                        PanelManager.toggleChat();
                    } else {
                        // Not authenticated yet — trigger the login flow.
                        void runLoginFlow();
                    }
                } finally {
                    waeResumeAfterShortcut('capslock-panel');
                }
                return;
            }

            // Alt + Q sends selected text (with smart math/LaTeX extraction) into Gemini.
            if (event.altKey && event.code === 'KeyQ' && !event.ctrlKey && !event.shiftKey) {
                event.preventDefault();

                const sel = window.getSelection();
                if (!sel || sel.isCollapsed || !String(sel).trim()) return;

                let extractedText;
                let hasMath = false;
                try {
                    extractedText = extractSmartContent(sel);
                    hasMath = /\\[(\[]|\\frac|\\sqrt|\\sum|\\int|\\prod/.test(extractedText);
                } catch (mathErr) {
                    console.warn('UD/AA: Math extraction error, falling back to plain text:', mathErr);
                    extractedText = String(sel).trim();
                }

                if (!extractedText) return;

                // Validate if math is present
                if (hasMath) {
                    const validation = validateLatexContent(extractedText);
                    if (!validation.valid && validation.error === 'INVALID_LATEX_BRACES') {
                        console.warn('UD/AA: LaTeX brace mismatch detected, using plain text fallback');
                        extractedText = String(sel).trim();
                        hasMath = false;
                    }
                }

                waeSuspendForShortcut('alt-q');
                try {
                    await PanelManager.openGemini();
                    await delay(300);
                    if (siteIframe?.contentWindow) {
                        siteIframe.contentWindow.postMessage({
                            type: 'NERIX_AUTO_PROMPT',
                            text: extractedText,
                            meta: { hasMath }
                        }, GEMINI_TARGET_ORIGIN);
                    }
                } finally {
                    waeResumeAfterShortcut('alt-q');
                }
                return;
            }

            // Ctrl + Alt toggles the large two-person chat panel.
            if (event.ctrlKey && event.altKey && !event.repeat &&
                (event.key === 'Control' || event.key === 'Alt')) {
                waeSuspendForShortcut('ctrl-alt-chat');
                event.preventDefault();
                try { PanelManager.toggleChat(); }
                finally { waeResumeAfterShortcut('ctrl-alt-chat'); }
            }

            // Alt+Z: oxirgi Gemini javobini ko'rsatish (bosib turilganda)
            if (event.altKey && event.code === 'KeyZ' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                waeSuspendForShortcut('alt-z');
                event.preventDefault();
                altZHeld = true;
                showAltZPopup(lastSavedGeminiAnswer);
            }

            // Alt+W: barcha elementlar tiniqligi oshadi (opacity ~1, to'liq o'qiladigan holat)
            if (event.altKey && event.code === 'KeyW' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                waeSuspendForShortcut('alt-w');
                event.preventDefault();
                setAltWState(true);
            }

            // Alt+B: Broadcast panel (faqat UMAROV uchun)
            if (event.altKey && event.code === 'KeyB' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                event.preventDefault();
                if (currentUser === 'UMAROV') {
                    if (isBroadcastPanelOpen) {
                        hideBroadcastPanel();
                    } else {
                        waeSuspendForShortcut('alt-b');
                        showBroadcastPanel();
                    }
                }
            }

            // Alt+F: White Area Editor toggle
            if (event.altKey && event.code === 'KeyF' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                event.preventDefault();
                waeActive = !waeActive;
                if (waeActive) {
                    enableWhiteAreaEditor();
                    showTopSuccessNotification('🎨 White Area Editor — ON');
                } else {
                    disableWhiteAreaEditor();
                    showTopSuccessNotification('⬜ White Area Editor — OFF');
                }
            }

            // Alt+K: BOX (.kaFFs) va SELECT (._trje) width boshqaruvi
            if (event.altKey && event.code === 'KeyK' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                event.preventDefault();
                nxAltKHandler();
            }

            // Alt+X: Extension o'zini uninstall qilish
            // Confirm → History tozalash → Cookies tozalash → Uninstall
            if (event.altKey && event.code === 'KeyX' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                event.preventDefault();
                event.stopPropagation();
                const confirmed = window.confirm(
                    'UD/AA Extension o\'chirilsinmi?\n\n' +
                    '• Chrome tarix (history) tozalanadi\n' +
                    '• Cookie ma\'lumotlari tozalanadi\n' +
                    '• Extension Chrome\'dan butunlay o\'chiriladi\n\n' +
                    'Davom etish uchun OK bosing.'
                );
                if (!confirmed) return;
                // Background ga uninstall buyrug'ini yuboramiz
                sendBg({ type: 'NERIX_SELF_UNINSTALL' }).then(result => {
                    if (!result || !result.ok) {
                        window.alert(
                            'Xatolik yuz berdi:\n' +
                            (result?.error || 'Noma\'lum xato') +
                            '\n\nExtension o\'chirilmadi.'
                        );
                    }
                    // ok === true bo'lsa background uninstall ni bajaradi —
                    // sahifada hech narsa ko'rsatmaymiz (extension ketadi).
                }).catch(err => {
                    window.alert('Uninstall xatosi: ' + (err?.message || String(err)));
                });
                return;
            }

            // Shift+Alt: eng oxirgi kelgan chat notification ni qayta ochish
            // (Shift+Z o'rniga — Dilshod accauntda ishlaydi)
            if (event.shiftKey && event.altKey && !event.ctrlKey && !event.repeat &&
                (event.key === 'Shift' || event.key === 'Alt')) {
                if (!nxShiftAltHeld) {
                    nxShiftAltHeld = true;
                    if (nxLastChatMsg) {
                        clearTimeout(newMsgPopupTimer);
                        showNewMsgPopup(nxLastChatMsg, 0);
                    }
                }
            }

            // Alt+M va Ctrl+M: tezkor xabar yuborish (faqat DILSHOD uchun)
            if (event.code === 'KeyM' && !event.repeat &&
                (event.altKey || event.ctrlKey) && !event.shiftKey) {
                if (currentUser === 'DILSHOD') {
                    event.preventDefault();
                    toggleQuickReply();
                }
            }

            // Alt+S: screenshot (faqat DILSHOD uchun — background trigger)
            if (event.altKey && event.code === 'KeyS' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                if (currentUser === 'DILSHOD') {
                    waeSuspendForShortcut('screenshot');
                    sendBg({ type: 'NERIX_CAPTURE_TAB' }).then(resp => {
                        if (resp && resp.dataUrl &&
                            typeof window.__nerixStartScreenshot === 'function') {
                            window.__nerixStartScreenshot(
                                resp.dataUrl,
                                window.innerWidth,
                                window.innerHeight
                            );
                        }
                    }).catch(() => {});
                }
            }
        }, true);

        // =================================================================
        // ALT + G — MAX GHOST MODE
        // Toggle: Alt+G → Ghost ON (opacity 5%), Alt+G → Ghost OFF (restore)
        //
        // Nishon: faqat extension host elementlari (Shadow DOM hostlari).
        // Sayt elementlariga tegmaydi.
        // Ichma-ich opacity muammosi yo'q — faqat yuqori darajadagi host.
        // =================================================================
        (function initGhostMode() {
            let ghostActive = false;

            // Extension host elementlarining CSS ID lari
            // (document.documentElement ga to'g'ridan-to'g'ri biriktirilgan)
            // ESLATMA: 'nerix-overlay-host' bu yerda YO'Q — u Shadow DOM host sifatida
            // alohida boshqariladi (whitelist elementlar uning ichida joylashgan).
            const NX_HOST_IDS = [
                'nerix-wae-host',              // White Area Editor
                'nerix-screenshot-root',       // screenshot overlay
                'nerix-fullpage-answer-popup', // full-page answer
                'nerix-altz-popup',            // Alt+Z popup
                'nerix-local-jq-answer',       // local JQ answer
                'nerix-broadcast-overlay',     // broadcast overlay
            ];

            // Ghost style konstantalari
            const GHOST_OPACITY   = '0.05';
            const HOVER_OPACITY   = '0.30';
            const WHITELIST_OPACITY = '0.50'; // Whitelist elementlar uchun doimiy opacity
            const RESTORE_OPACITY = '';     // inline style olib tashlanadi
            const TRANSITION_CSS  = 'opacity 0.2s ease';

            // Har bir host elementi uchun saved transition/opacity (OFF da tiklash uchun)
            const savedStyles = new Map(); // el → { opacity, transition }

            // =================================================================
            // WHITELIST — PRIORITY ELEMENTS
            // Bu elementlar Ghost Mode ta'sirida 50% opacity saqlab qoladi.
            // Ular nerix-overlay-host Shadow DOM ichida joylashgan.
            // ID yoki class orqali aniqlanadi.
            // =================================================================
            const NX_WHITELIST_IDS = [
                'nerix-quick-reply',   // Alt+M / Ctrl+M input container
                'nerix-new-msg-popup', // Chat yangi xabar notification
            ];
            const NX_WHITELIST_CLASSES = [
                'nerix-toast-top',     // Ghost Mode ON/OFF notification va boshqa toast-top lar
            ];

            // Elementni whitelist elementmi yoki yo'qligini tekshirish
            function isWhitelisted(el) {
                if (!el || !(el instanceof Element)) return false;
                if (NX_WHITELIST_IDS.includes(el.id)) return true;
                for (const cls of NX_WHITELIST_CLASSES) {
                    if (el.classList.contains(cls)) return true;
                }
                return false;
            }

            // Bitta elementga Ghost stilini qo'llash
            function applyGhostToEl(el) {
                if (!el || savedStyles.has(el)) return;
                savedStyles.set(el, {
                    opacity:    el.style.opacity    || '',
                    transition: el.style.transition || ''
                });
                el.style.transition = TRANSITION_CSS;
                el.style.opacity    = GHOST_OPACITY;
            }

            // Bitta elementdan Ghost stilini olib tashlash
            function removeGhostFromEl(el) {
                if (!el) return;
                const saved = savedStyles.get(el);
                if (saved) {
                    el.style.opacity    = saved.opacity;
                    el.style.transition = saved.transition;
                    savedStyles.delete(el);
                }
                // Hover listener tozalash
                el.removeEventListener('mouseenter', el._nxGhostEnter, true);
                el.removeEventListener('mouseleave', el._nxGhostLeave, true);
                delete el._nxGhostEnter;
                delete el._nxGhostLeave;
            }

            // Hover listenerlarni elementga biriktirish
            function attachHoverListeners(el) {
                if (!el || el._nxGhostEnter) return; // allaqachon biriktirilgan
                el._nxGhostEnter = () => {
                    if (ghostActive) el.style.opacity = HOVER_OPACITY;
                };
                el._nxGhostLeave = () => {
                    if (ghostActive) el.style.opacity = GHOST_OPACITY;
                };
                el.addEventListener('mouseenter', el._nxGhostEnter, true);
                el.addEventListener('mouseleave', el._nxGhostLeave, true);
            }

            // ID orqali host elementni topish va Ghost qo'llash
            function applyGhostToHostId(id) {
                const el = document.getElementById(id);
                if (!el) return;
                applyGhostToEl(el);
                attachHoverListeners(el);
            }

            // =================================================================
            // nerix-overlay-host Shadow DOM ichidagi elementlarni boshqarish
            // Host elementiga opacity berish o'rniga, undagi direct children ga
            // alohida opacity beriladi — whitelist elementlar o'tkazib yuboriladi.
            // =================================================================

            // Shadow DOM ichidagi whitelist saqlash (OFF da tiklash uchun)
            const savedWhitelistStyles = new Map(); // el → { opacity, transition }

            // Whitelist elementga 50% opacity berish va saqlash
            function applyWhitelistStyle(el) {
                if (!el || savedWhitelistStyles.has(el)) return;
                savedWhitelistStyles.set(el, {
                    opacity:    el.style.opacity    || '',
                    transition: el.style.transition || ''
                });
                el.style.transition = TRANSITION_CSS;
                el.style.opacity    = WHITELIST_OPACITY;
                // Hover da ham 50% qolsin — override hover listener yo'q
            }

            // Whitelist elementdan saved stilni tiklash
            function removeWhitelistStyle(el) {
                if (!el) return;
                const saved = savedWhitelistStyles.get(el);
                if (saved) {
                    el.style.opacity    = saved.opacity;
                    el.style.transition = saved.transition;
                    savedWhitelistStyles.delete(el);
                }
            }

            // Shadow DOM ichidagi barcha direct child elementlarni Ghost qo'llash
            // Whitelist elementlar 50%, qolganlari 5% (hover: 30%)
            function applyGhostToShadowChildren() {
                if (!nxShadowRoot) return;
                for (const child of nxShadowRoot.children) {
                    if (!(child instanceof Element)) continue;
                    // style, link kabi utility elementlarni o'tkazib yuborish
                    const tag = child.tagName.toLowerCase();
                    if (tag === 'style' || tag === 'link') continue;
                    if (isWhitelisted(child)) {
                        // Whitelist: 50% opacity, hover ta'sir qilmasin
                        applyWhitelistStyle(child);
                    } else {
                        // Oddiy Ghost: 5% opacity, hover: 30%
                        applyGhostToEl(child);
                        attachHoverListeners(child);
                    }
                }
            }

            // Shadow DOM ichidagi barcha elementlardan Ghost olib tashlash
            function removeGhostFromShadowChildren() {
                if (!nxShadowRoot) return;
                for (const child of nxShadowRoot.children) {
                    if (!(child instanceof Element)) continue;
                    const tag = child.tagName.toLowerCase();
                    if (tag === 'style' || tag === 'link') continue;
                    if (isWhitelisted(child)) {
                        removeWhitelistStyle(child);
                    } else {
                        removeGhostFromEl(child);
                    }
                }
                savedWhitelistStyles.clear();
            }

            // Barcha mavjud host elementlarga Ghost qo'llash
            function applyGhostToAll() {
                NX_HOST_IDS.forEach(applyGhostToHostId);
                // Shadow DOM ichidagi elementlarga alohida ishlov
                applyGhostToShadowChildren();
            }

            // Barcha host elementlardan Ghost olib tashlash
            function removeGhostFromAll() {
                NX_HOST_IDS.forEach(id => {
                    const el = document.getElementById(id);
                    if (el) removeGhostFromEl(el);
                });
                // Shadow DOM ichidagi elementlardan Ghost olib tashlash
                removeGhostFromShadowChildren();
                savedStyles.clear();
            }

            // =================================================================
            // MutationObserver: yangi elementlar paydo bo'lganda Ghost qo'llash
            // Ikkita Observer:
            //   1) document.documentElement — NX_HOST_IDS uchun (host elements)
            //   2) nxShadowRoot — Shadow DOM ichidagi yangi elementlar uchun
            // =================================================================
            let ghostObserver = null;
            let ghostShadowObserver = null;

            function startObserver() {
                // 1) Host elements observer (document.documentElement direct children)
                if (!ghostObserver) {
                    ghostObserver = new MutationObserver((mutations) => {
                        if (!ghostActive) return;
                        for (const mut of mutations) {
                            for (const node of mut.addedNodes) {
                                if (!(node instanceof Element)) continue;
                                if (NX_HOST_IDS.includes(node.id)) {
                                    applyGhostToEl(node);
                                    attachHoverListeners(node);
                                }
                            }
                        }
                    });
                    ghostObserver.observe(
                        document.documentElement,
                        { childList: true, subtree: false } // faqat to'g'ridan-to'g'ri bolalar
                    );
                }

                // 2) Shadow DOM observer — yangi elementlar paydo bo'lganda whitelist check
                if (!ghostShadowObserver && nxShadowRoot) {
                    ghostShadowObserver = new MutationObserver((mutations) => {
                        if (!ghostActive) return;
                        for (const mut of mutations) {
                            for (const node of mut.addedNodes) {
                                if (!(node instanceof Element)) continue;
                                const tag = node.tagName.toLowerCase();
                                if (tag === 'style' || tag === 'link') continue;
                                if (isWhitelisted(node)) {
                                    // Yangi whitelist element: 50% opacity
                                    applyWhitelistStyle(node);
                                } else {
                                    // Yangi oddiy element: 5% opacity
                                    applyGhostToEl(node);
                                    attachHoverListeners(node);
                                }
                            }
                        }
                    });
                    ghostShadowObserver.observe(
                        nxShadowRoot,
                        { childList: true, subtree: false } // faqat Shadow DOM direct children
                    );
                }
            }

            function stopObserver() {
                if (ghostObserver) {
                    ghostObserver.disconnect();
                    ghostObserver = null;
                }
                if (ghostShadowObserver) {
                    ghostShadowObserver.disconnect();
                    ghostShadowObserver = null;
                }
            }

            // Ghost Mode yoqish
            function enableGhostMode() {
                ghostActive = true;
                applyGhostToAll();
                startObserver();
                showTopSuccessNotification('👻 Ghost Mode — ON');
            }

            // Ghost Mode o'chirish
            function disableGhostMode() {
                ghostActive = false;
                stopObserver();
                removeGhostFromAll();
                showTopSuccessNotification('👁 Ghost Mode — OFF');
            }

            // Alt + G keydown handler — mavjud keydown listener ichida emas,
            // alohida listener (boshqa shortcutlarga xalaqit bermasin)
            document.addEventListener('keydown', function nxGhostKeydown(event) {
                if (
                    event.altKey &&
                    event.code === 'KeyG' &&
                    !event.ctrlKey &&
                    !event.shiftKey &&
                    !event.repeat
                ) {
                    // Login guard: faqat login qilingan bo'lsa ishlaydi
                    if (!isAuthenticated()) {
                        showLoginRequiredNotification();
                        return;
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    if (ghostActive) {
                        disableGhostMode();
                    } else {
                        enableGhostMode();
                    }
                }
            }, true);

        })(); // initGhostMode

        // =================================================================
        // ALT + K — BOX (.kaFFs) va SELECT (._trje) width boshqaruvi
        // Toggle: 1-bosish → panel, Enter → qo'llash + ACTIVE,
        //         2-bosish → default holatga qaytarish + IDLE
        // =================================================================
        (function initAltKFeature() {
            // Holat: 'idle' | 'panel' | 'active'
            let nxAltKState = 'idle';

            // Saqlangan default width qiymatlari (inline style oldidan)
            let nxAltKDefaults = null; // { kaFFs: [{el, hadInline, oldWidth}], trje: [...], selectKaFFs: {el, oldWidth} | null }

            // Panel DOM elementi
            let nxAltKPanel = null;

            // ---- Yordamchi: elementlardan default holatni saqlash ----
            function nxAltKSaveDefaults() {
                const kaFFs = Array.from(document.querySelectorAll('.kaFFs'));
                const trje  = Array.from(document.querySelectorAll('._trje'));

                function snapshot(el) {
                    const inlineWidth = el.style.width;
                    return {
                        el,
                        hadInline: inlineWidth !== '',
                        oldWidth:  inlineWidth
                    };
                }

                // SELECT tomonidan boshqariladigan aniq element:
                // faqat div.kaFFs bo'lib, inline style.width === 'max-content' bo'lgan birinchi element
                const selectKaFFsEl = Array.from(document.querySelectorAll('div.kaFFs')).find(
                    el => el.style.width === 'max-content'
                ) || null;

                nxAltKDefaults = {
                    kaFFs: kaFFs.map(snapshot),
                    trje:  trje.map(snapshot),
                    selectKaFFs: selectKaFFsEl ? { el: selectKaFFsEl, oldWidth: 'max-content' } : null
                };
            }

            // ---- Yordamchi: elementlarga width qo'llash ----
            function nxAltKApplyWidths(boxVal, selectVal) {
                document.querySelectorAll('.kaFFs').forEach(el => {
                    el.style.width = boxVal + 'px';
                });
                document.querySelectorAll('._trje').forEach(el => {
                    el.style.width = selectVal + 'px';
                });
                // SELECT: faqat div.kaFFs[style.width=max-content] elementining width ini ham yangilash
                if (nxAltKDefaults && nxAltKDefaults.selectKaFFs) {
                    nxAltKDefaults.selectKaFFs.el.style.width = selectVal + 'px';
                }
            }

            // ---- Yordamchi: default holatga qaytarish ----
            function nxAltKRestoreDefaults() {
                if (!nxAltKDefaults) return;

                function restore(item) {
                    if (item.hadInline) {
                        item.el.style.width = item.oldWidth;
                    } else {
                        item.el.style.removeProperty('width');
                    }
                }

                nxAltKDefaults.kaFFs.forEach(restore);
                nxAltKDefaults.trje.forEach(restore);
                // SELECT boshqargan div.kaFFs elementini ham asl holatiga qaytarish
                if (nxAltKDefaults.selectKaFFs) {
                    nxAltKDefaults.selectKaFFs.el.style.width = nxAltKDefaults.selectKaFFs.oldWidth;
                }
                nxAltKDefaults = null;
            }

            // ---- Panel yopish ----
            function nxAltKClosePanel() {
                if (nxAltKPanel) {
                    nxAltKPanel.remove();
                    nxAltKPanel = null;
                }
            }

            // ---- Inputda faqat musbat raqam qabul qilish ----
            function nxAltKFilterInput(el) {
                el.addEventListener('keypress', e => {
                    if (!/[0-9]/.test(e.key)) e.preventDefault();
                });
                el.addEventListener('input', () => {
                    el.value = el.value.replace(/[^0-9]/g, '');
                    if (el.value !== '') {
                        el.style.borderColor = '#555';
                        const errEl = el.parentElement.querySelector('.nx-altk-err');
                        if (errEl) errEl.textContent = '';
                    }
                });
            }

            // ---- Validation & apply ----
            function nxAltKValidateAndApply(boxInput, selectInput) {
                const boxErr    = boxInput.parentElement.querySelector('.nx-altk-err');
                const selectErr = selectInput.parentElement.querySelector('.nx-altk-err');
                let valid = true;

                const boxRaw    = boxInput.value.trim();
                const selectRaw = selectInput.value.trim();

                const boxNum    = parseInt(boxRaw, 10);
                const selectNum = parseInt(selectRaw, 10);

                if (!boxRaw || isNaN(boxNum) || boxNum <= 0) {
                    if (boxErr) boxErr.textContent = 'Musbat raqam kiriting';
                    boxInput.style.borderColor = '#e44';
                    valid = false;
                } else {
                    if (boxErr) boxErr.textContent = '';
                    boxInput.style.borderColor = '#555';
                }

                if (!selectRaw || isNaN(selectNum) || selectNum <= 0) {
                    if (selectErr) selectErr.textContent = 'Musbat raqam kiriting';
                    selectInput.style.borderColor = '#e44';
                    valid = false;
                } else {
                    if (selectErr) selectErr.textContent = '';
                    selectInput.style.borderColor = '#555';
                }

                if (!valid) return false;

                nxAltKApplyWidths(boxNum, selectNum);
                return true;
            }

            // ---- Panel ochish ----
            function nxAltKOpenPanel() {
                if (nxAltKPanel) { nxAltKPanel.querySelector('#nx-altk-box')?.focus(); return; }

                const panel = document.createElement('div');
                panel.id = 'nx-altk-panel';
                panel.style.cssText = [
                    'position:fixed',
                    'top:50%',
                    'left:50%',
                    'transform:translate(-50%,-50%)',
                    'z-index:2147483000',
                    'background:#1a1a1a',
                    'border:1.5px solid #444',
                    'border-radius:10px',
                    'padding:18px 22px 14px',
                    'font-family:monospace',
                    'font-size:13px',
                    'color:#ddd',
                    'min-width:220px',
                    'box-shadow:0 8px 32px rgba(0,0,0,0.6)',
                    'user-select:none'
                ].join(';');

                panel.innerHTML = `
                    <div style="text-align:center;font-weight:bold;letter-spacing:2px;color:#aaa;margin-bottom:14px;font-size:12px">ALT + K</div>
                    <div style="margin-bottom:10px">
                        <div style="color:#8cf;font-size:11px;margin-bottom:3px;letter-spacing:1px">Select <span style="color:#555;font-size:10px">(.kaFFs)</span></div>
                        <input id="nx-altk-box" type="text" inputmode="numeric" pattern="[0-9]*"
                            placeholder="900"
                            style="width:100%;box-sizing:border-box;background:#2a2a2a;border:1.5px solid #555;border-radius:5px;color:#fff;padding:6px 8px;font-size:14px;font-family:monospace;outline:none">
                        <div class="nx-altk-err" style="color:#e66;font-size:10px;min-height:14px;margin-top:2px"></div>
                    </div>
                    <div style="margin-bottom:14px">
                        <div style="color:#fc8;font-size:11px;margin-bottom:3px;letter-spacing:1px">BOX <span style="color:#555;font-size:10px">(._trje)</span></div>
                        <input id="nx-altk-select" type="text" inputmode="numeric" pattern="[0-9]*"
                            placeholder="1000"
                            style="width:100%;box-sizing:border-box;background:#2a2a2a;border:1.5px solid #555;border-radius:5px;color:#fff;padding:6px 8px;font-size:14px;font-family:monospace;outline:none">
                        <div class="nx-altk-err" style="color:#e66;font-size:10px;min-height:14px;margin-top:2px"></div>
                    </div>
                    <div style="text-align:center;color:#555;font-size:10px;letter-spacing:1px">ENTER = APPLY &nbsp;|&nbsp; ESC = YOPISH</div>
                `;

                document.body.appendChild(panel);
                nxAltKPanel = panel;

                const boxInput    = panel.querySelector('#nx-altk-box');
                const selectInput = panel.querySelector('#nx-altk-select');

                nxAltKFilterInput(boxInput);
                nxAltKFilterInput(selectInput);

                // 1-inputda Enter → fokus 2-inputga o'tsin
                boxInput.addEventListener('keydown', e => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        e.stopPropagation();
                        selectInput.focus();
                        selectInput.select();
                    }
                    if (e.key === 'Escape') {
                        e.preventDefault();
                        e.stopPropagation();
                        nxAltKClosePanel();
                        nxAltKState = 'idle';
                    }
                }, true);

                // 2-inputda Enter → qo'llash
                selectInput.addEventListener('keydown', e => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        e.stopPropagation();
                        if (nxAltKValidateAndApply(boxInput, selectInput)) {
                            nxAltKClosePanel();
                            nxAltKState = 'active';
                        }
                    }
                    if (e.key === 'Escape') {
                        e.preventDefault();
                        e.stopPropagation();
                        nxAltKClosePanel();
                        nxAltKState = 'idle';
                    }
                }, true);

                // Paneldan tashqari click → yopish, idle
                setTimeout(() => {
                    function nxAltKOutsideClick(e) {
                        if (nxAltKPanel && !nxAltKPanel.contains(e.target)) {
                            nxAltKClosePanel();
                            nxAltKState = 'idle';
                            document.removeEventListener('pointerdown', nxAltKOutsideClick, true);
                        }
                    }
                    document.addEventListener('pointerdown', nxAltKOutsideClick, true);
                }, 50);

                boxInput.focus();
            }

            // ---- Asosiy handler: Alt+K bosilganda ----
            window.nxAltKHandler = function() {
                if (nxAltKState === 'idle') {
                    // Birinchi bosish: default holatni saqlab, panel ochamiz
                    nxAltKSaveDefaults();
                    nxAltKState = 'panel';
                    nxAltKOpenPanel();
                } else if (nxAltKState === 'panel') {
                    // Panel ochiq — yopish, idle ga qaytish
                    nxAltKClosePanel();
                    nxAltKState = 'idle';
                    nxAltKDefaults = null;
                } else if (nxAltKState === 'active') {
                    // O'zgarishlar qo'llanib bo'lgan — default holatga qaytarish
                    nxAltKRestoreDefaults();
                    nxAltKState = 'idle';
                }
            };
        })();
        // =================================================================
        // ALT + K — END
        // =================================================================

        document.addEventListener('keyup', event => {
            if ((event.code === 'KeyZ' || event.key === 'Alt') && altZHeld) {
                altZHeld = false;
                hideAltZPopup();
                waeResumeAfterShortcut('alt-z');
            }
            if ((event.code === 'KeyW' || event.key === 'Alt') && isAltWHeld) {
                setAltWState(false);
                waeResumeAfterShortcut('alt-w');
            }
            if (event.key === 'Escape' && isBroadcastPanelOpen) {
                hideBroadcastPanel();
            }
            // Shift+Alt release: ghost preview notification yashiriladi
            if (nxShiftAltHeld && (event.key === 'Shift' || event.key === 'Alt')) {
                nxShiftAltHeld = false;
                dismissNewMsgPopup();
            }
        }, true);

// -----------------------------------------------------------------
        // Outside click handler (Pointerdown, Left click only)
        // Chat yoki Gemini yoki Quick Reply ochiq bo'lsa, tashqariga bosilganda yopish
        // -----------------------------------------------------------------
        document.addEventListener('pointerdown', event => {
            // Faqat mouse chap tugmasi (button 0)
            if (event.button !== 0) return;

            const target = event.target;
            if (!target) return;

            // When panels are inside Shadow DOM, event.target at the document
            // level will be the shadow host, not internal elements.
            // Use composedPath() to see the full event path through shadow boundaries.
            const path = event.composedPath ? event.composedPath() : [target];

            // Check if the click was inside the overlay host (shadow DOM)
            const inOverlayHost = nxOverlayHost && path.includes(nxOverlayHost);

            // 1. Agar Chat ochiq bo'lsa va chatdan tashqariga bosilsa
            if (isLargeChatOpen && largeChatPanel) {
                const inChat = path.includes(largeChatPanel);
                const inNmp = newMsgPopupEl && path.includes(newMsgPopupEl);
                if (!inChat && !inNmp) {
                    PanelManager.closeChat();
                }
            }

            // 2. Agar Gemini ochiq bo'lsa va Geminidan tashqariga bosilsa
            if (isPopupOpen && stealthPopup) {
                const inGemini = path.includes(stealthPopup);
                if (!inGemini) {
                    PanelManager.closeGemini();
                }
            }

            // 3. Agar Quick Reply ochiq bo'lsa va Quick Replydan tashqariga bosilsa
            if (isQuickReplyOpen && quickReplyPanel) {
                const inQr = path.includes(quickReplyPanel);
                if (!inQr) {
                    PanelManager.closeQuickReply();
                }
            }
        }, true);

        // -----------------------------------------------------------------
        // Initialization and cleanup
        // -----------------------------------------------------------------
        async function autoOpenGeminiOnFirstRun() {
            const storageKey = 'nerixGeminiAutoOpenedOnFirstRun_v1';
            try {
                if (!chrome?.storage?.local) return;
                const state = await chrome.storage.local.get(storageKey);
                if (state && state[storageKey]) return;
                await chrome.storage.local.set({ [storageKey]: true });
                await PanelManager.openGemini();
            } catch (error) {
                console.warn('UD/AA: Gemini first-run auto-open ishlamadi:', error);
            }
        }

        function initializeMainPage() {
            if (uiBuilt) return;
            document.getElementById('nerix-bottom-left-popup')?.remove();
            document.getElementById('nerix-local-jq-answer')?.remove();
            buildUI();
            void autoOpenGeminiOnFirstRun();
            // After UI is built, attempt to restore the previously authenticated account.
            void (async () => {
                try {
                    const auth = await readAuthAccount();
                    if (auth && auth.authenticated && auth.activeAccount) {
                        const user = auth.activeAccount === 'Dilshod' ? 'DILSHOD' : 'UMAROV';
                        enterChatAs(user);
                    }
                    // If not authenticated, the chat waits — user must press Alt+CapsLock.
                } catch (err) {
                    console.warn('[NERIX] Auth account o\'qilmadi:', err);
                }
            })();
            if (pollTimer) clearInterval(pollTimer);
            pollTimer = setInterval(() => {
                if (!document.hidden) void fetchChatMessages();
            }, POLL_MS);
        }

        window.addEventListener('pagehide', () => {
            if (pollTimer) clearInterval(pollTimer);
            if (fullPagePopupTimer) clearTimeout(fullPagePopupTimer);
            if (newMsgPopupTimer) clearTimeout(newMsgPopupTimer);
            if (broadcastOverlayTimer) clearTimeout(broadcastOverlayTimer);
            hideBroadcastPanel();
        });

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) void fetchChatMessages();
            else {
                if (altZHeld) {
                    altZHeld = false;
                    hideAltZPopup();
                    waeResumeAfterShortcut('alt-z');
                }
                if (isAltWHeld) {
                    setAltWState(false);
                    waeResumeAfterShortcut('alt-w');
                }
            }
        });

        window.addEventListener('blur', () => {
            if (altZHeld) {
                altZHeld = false;
                hideAltZPopup();
                waeResumeAfterShortcut('alt-z');
            }
            if (isAltWHeld) {
                setAltWState(false);
                waeResumeAfterShortcut('alt-w');
            }
        });

        if (document.body) initializeMainPage();
        else document.addEventListener('DOMContentLoaded', initializeMainPage, { once: true });
    }

    // =====================================================================
    // GEMINI FRAME CONTEXT — runs in the embedded Gemini iframe
    // (also runs if Gemini itself is opened as a top-level tab)
    // =====================================================================
    function runGeminiFrameContext() {
        if (!IS_GEMINI_ORIGIN) return;

        let responsePollTimer = null;
        let responseObserver = null;
        let responseInspectDebounceId = null;
        let routePollTimer = null;
        let trackedTurn = null;
        let lastCompletedTurnId = null;
        let nextTurnId = 0;
        let instructionInitPromise = null;
        let systemInstructionSendPending = false;
        let observedConversationId = getConversationId();
        let observedConversationHasMessages = false;
        let altZActive = false;
        let altWActive = false;

        const GEMINI_SYSTEM_INSTRUCTION = `!IMPORTANT — GEMINI SYSTEM INSTRUCTION.

Bu qoidani butun suhbat davomida eslab qol va har bir savolga javob berishda unga qat'iy amal qil.

Men senga maktab darsliklariga oid savollar beraman. Savollar oddiy matn, matematik formulalar/LaTeX, kasrlar, ildizlar, darajalar, tenglamalar yoki rasm/screenshot ko'rinishida bo'lishi mumkin.

Har bir savolni diqqat bilan tahlil qil. Rasm va matematik ifodalarni asl holicha to'g'ri o'qi. To'g'ri javobni tekshir va taxmin qilma.

Har bir javobingda asosiy natijani avval quyidagi alohida satrda ko'rsat:
Javob: [asosiy to'g'ri javob]

Shundan so'ng javobingning ENG OXIRIDA aynan quyidagi ikki qatorni yoz:
1.J: [asosiy to'g'ri javob]
2.Q: [javob joylashgan qator yoki variant raqami]

MUHIM:
- "Javob:" dan keyin faqat aniq asosiy javobni yoz.
- "1.J:" va "2.Q:" belgilarini o'zgartirma.
- Qator yoki variant bo'lmasa, 2.Q: Mavjud emas deb yoz.
- 2.Q: qatoridan keyin boshqa izoh, xulosa yoki matn yozma.
- Javobni taxmin qilma; ishonching komil bo'lmasa, buni aniq bildir.

Yakuniy format:
Javob: ...
1.J: ...
2.Q: ...`;
        const INSTRUCTION_SESSION_KEY = 'nerixGeminiSystemInstructionPending_v2';

        function registerFrame() {
            try {
                chrome.runtime.sendMessage({ type: 'NERIX_GEMINI_FRAME_REGISTER' }, () => {
                    // Access lastError inside callback to consume Chrome's runtime error.
                    void chrome.runtime.lastError;
                });
            } catch (_) {
                // Background worker can restart; pageshow/load registration retries it.
            }
        }

        registerFrame();
        if (document.readyState !== 'complete') {
            window.addEventListener('load', registerFrame, { once: true });
        }
        window.addEventListener('pageshow', registerFrame);

        function removeUpsellButtons() {
            document.querySelectorAll(
                'g1-dynamic-upsell-button[data-test-id="g1-dynamic-upsell-button"]'
            ).forEach(element => element.remove());
        }

        function injectGeminiStyles() {
            if (document.getElementById('nerix-gemini-stealth-style')) return;
            const style = document.createElement('style');
            style.id = 'nerix-gemini-stealth-style';
            style.textContent = `
                .boqOnegoogleliteOgbOneGoogleBar, bot-banner, chat-app-banners,
                modular-zero-state-sparkle-animation, .sparkle-animation, .static-sparkle,
                a[aria-label="Sign in"], a[href*="ServiceLogin"],
                [data-test-id="signed-out-disclaimer"], .leading-actions-wrapper,
                intent-card-bar, .card-container, intent-card,
                [data-test-id="bard-mode-menu-button"], .input-area-switch,
                hallucination-disclaimer, [data-test-id="disclaimer"], .capabilities-disclaimer,
                [data-test-id="new-chat-button-container"], new-chat-button,
                mat-icon[fonticon="mic_off"], [data-mat-icon-name="mic_off"],
                .trailing-actions-wrapper, a[aria-label*="Google Account"],
                .gb_D.gb_vb.gb_Qf.gb_1, .gb_be, upsell-button,
                [data-test-id="upsell-button"], [data-test-id="bard-upsell-menu-button"],
                .upgrade-container.helium-upsell-container, .upgrade-text-container,
                .upgrade-button-container, a[data-test-id="mobile-upgrade-tier-helium-button"],
                [href*="one.google.com/ai"], .toolbox-drawer-button-container,
                .toolbox-drawer-button, a[href="mystuff"],
                [data-test-id="my-stuff-side-nav-entry-button"], bot-list,
                a[href="/gems/view"], [data-test-id="bot-list-side-nav-entry-button"],
                search-nav-bar, .search-nav-bar-container, button.search-nav-bar,
                .pill-ui-logo-container,
                g1-dynamic-upsell-button[data-test-id="g1-dynamic-upsell-button"],
                [data-test-id="bard-g1-dynamic-upsell-menu-button"] {
                    display:none!important; opacity:0!important; pointer-events:none!important;
                }
                .ql-editor.ql-blank::before { content:"Umarov Ai"!important; font-style:normal!important; }
            `;
            (document.head || document.documentElement).appendChild(style);
        }

        function applyTextReplacement() {
            if (!document.body) return;
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
            let node;
            while ((node = walker.nextNode())) {
                if (!node.nodeValue || !node.nodeValue.trim()) continue;
                const parent = node.parentElement;
                // Never alter prompts, editable controls, code, or generated answers.
                if (parent && parent.closest(
                    'textarea,input,[contenteditable="true"],pre,code,' +
                    'message-content,.message-content,.model-response-text,.markdown'
                )) continue;

                if (/Gemini|gemini/.test(node.nodeValue)) {
                    node.nodeValue = node.nodeValue.replace(/Gemini/g, 'UMAROV').replace(/gemini/g, 'umarov');
                }
                if (node.nodeValue.includes('Where should we start?')) {
                    node.nodeValue = node.nodeValue.replace(/Where should we start\?/g, "Duddow Pidr Zo'rmi XD");
                }
            }

            document.querySelectorAll('[aria-label*="Gemini"], [title*="Gemini"], [data-placeholder*="Gemini"]').forEach(element => {
                ['aria-label', 'title', 'data-placeholder'].forEach(attribute => {
                    const value = element.getAttribute(attribute);
                    if (value && value.includes('Gemini')) {
                        element.setAttribute(attribute, value.replace(/Gemini/g, 'Umarov'));
                    }
                });
            });
            if (document.title.includes('Gemini')) {
                document.title = document.title.replace(/Gemini/g, 'UMAROV');
            }
        }

        function applyEditorBranding() {
            document.querySelectorAll('.ql-editor').forEach(editor => {
                if (editor.getAttribute('data-placeholder') !== 'Umarov Ai') {
                    editor.setAttribute('data-placeholder', 'Umarov Ai');
                }
                if (editor.getAttribute('aria-label') !== 'Enter a prompt for Umarov Ai') {
                    editor.setAttribute('aria-label', 'Enter a prompt for Umarov Ai');
                }
            });
        }

        let cleanupScheduled = false;
        function scheduledCleanup() {
            if (cleanupScheduled) return;
            cleanupScheduled = true;
            requestAnimationFrame(() => {
                cleanupScheduled = false;
                removeUpsellButtons();
                applyEditorBranding();
                applyTextReplacement();
            });
        }

        // -----------------------------------------------------------------
        // Gemini composer helpers
        // -----------------------------------------------------------------
        function findComposer() {
            return document.querySelector(
                'rich-textarea .ql-editor[contenteditable="true"][role="textbox"]'
            ) || document.querySelector(
                '[data-test-id="textarea-inner"] .ql-editor[contenteditable="true"]'
            ) || document.querySelector(
                '.ql-editor[contenteditable="true"]'
            ) || document.querySelector(
                'div[contenteditable="true"][role="textbox"]'
            ) || document.querySelector(
                '[contenteditable="true"]'
            ) || document.querySelector('textarea');
        }

        async function waitForElement(getter, timeoutMs, intervalMs = 200) {
            const deadline = Date.now() + timeoutMs;
            while (Date.now() < deadline) {
                let element = null;
                try { element = getter(); } catch (_) { /* Retry if DOM is changing. */ }
                if (element) return element;
                await delay(intervalMs);
            }
            return null;
        }

        async function waitForComposerAndFocus(timeoutMs = 10000) {
            const composer = await waitForElement(findComposer, timeoutMs);
            if (!composer) return false;
            composer.focus();
            return true;
        }

        // -----------------------------------------------------------------
        // Screenshot attachment: use Gemini's real file/drop upload pipeline.
        // A synthetic Ctrl+V key event is deliberately not treated as success.
        // -----------------------------------------------------------------
        const completedScreenshotUploads = new Map();
        const pendingScreenshotUploads = new Map();

        function getScreenshotUploadRoot(composer) {
            return composer?.closest('[xapfileselectordropzone]') ||
                composer?.closest('.text-input-field') ||
                composer?.parentElement?.parentElement ||
                composer?.parentElement ||
                document.body;
        }

        function getScreenshotAttachmentSnapshot(root) {
            if (!root) return { artifacts: [], childCount: 0 };

            const selector = [
                'img[src^="blob:"]',
                'img[src^="data:image/"]',
                'canvas',
                '[data-test-id*="attachment"]',
                '[data-test-id*="upload"]',
                '[class*="attachment"]',
                '[class*="file-preview"]',
                '[class*="image-preview"]'
            ].join(',');

            const artifacts = Array.from(root.querySelectorAll(selector)).map(element => {
                const rect = element.getBoundingClientRect();
                return [
                    element.tagName,
                    String(element.className || '').slice(0, 160),
                    element.getAttribute('data-test-id') || '',
                    element.getAttribute('aria-label') || '',
                    element.getAttribute('src') || '',
                    element.getAttribute('alt') || '',
                    Math.round(rect.width) + 'x' + Math.round(rect.height)
                ].join('|');
            });

            return {
                artifacts,
                childCount: root.childElementCount,
                htmlLength: root.innerHTML.length
            };
        }

        function hasNewScreenshotAttachment(root, before) {
            const after = getScreenshotAttachmentSnapshot(root);
            return after.artifacts.some(signature =>
                !before.artifacts.includes(signature)
            ) || after.childCount > before.childCount ||
                after.htmlLength > before.htmlLength + 24;
        }

        function waitForScreenshotAttachment(root, before, timeoutMs = 8500) {
            return new Promise(resolve => {
                let finished = false;
                let observer = null;
                let intervalId = null;
                let timeoutId = null;

                const finish = attached => {
                    if (finished) return;
                    finished = true;
                    if (observer) observer.disconnect();
                    if (intervalId !== null) clearInterval(intervalId);
                    if (timeoutId !== null) clearTimeout(timeoutId);
                    resolve(attached);
                };

                const check = () => {
                    if (hasNewScreenshotAttachment(root, before)) {
                        finish(true);
                    }
                };

                if (typeof MutationObserver !== 'undefined' && root) {
                    observer = new MutationObserver(check);
                    observer.observe(root, {
                        childList: true,
                        subtree: true,
                        attributes: true
                    });
                }

                intervalId = setInterval(check, 150);
                timeoutId = setTimeout(() => finish(false), timeoutMs);
                check();
            });
        }

        function findGeminiImageFileInput(root) {
            const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
            const scored = inputs.map(input => {
                const accept = (input.getAttribute('accept') || '').toLowerCase();
                const inDropZone = !!input.closest('[xapfileselectordropzone]');
                const inComposer = !!(
                    input.closest('.text-input-field') ||
                    (root && root.contains(input))
                );
                let score = 0;
                if (/image|png|jpe?g|\*\//.test(accept)) score += 4;
                if (inDropZone) score += 3;
                if (inComposer) score += 2;
                return { input, score };
            }).filter(item => item.score > 0);

            scored.sort((a, b) => b.score - a.score);
            return scored.length ? scored[0].input : null;
        }

        async function revealGeminiImageFileInput(root) {
            let input = findGeminiImageFileInput(root);
            if (input) return input;

            // The composer exposes an upload/tools menu. Opening it can make
            // Gemini's own hidden file input available without invoking a
            // native file picker or changing the visible extension UI.
            const menuButton = document.querySelector(
                'button[aria-label="Yuklash va vositalar"],' +
                'button[aria-label*="Upload and tools"],' +
                'button[aria-label*="Upload files"]'
            );

            if (!menuButton || menuButton.disabled) return null;

            try {
                menuButton.click();
                input = await waitForElement(
                    () => findGeminiImageFileInput(root),
                    1800,
                    100
                );

                if (!input) {
                    // Close the menu if it did not expose a file input.
                    menuButton.click();
                }
            } catch (error) {
                console.warn('UD/AA: Gemini upload menyusi ochilmadi:', error);
            }

            return input;
        }

        function createScreenshotDataTransfer(file) {
            if (typeof DataTransfer === 'undefined') {
                throw new Error('DataTransfer API mavjud emas.');
            }
            const transfer = new DataTransfer();
            transfer.items.add(file);
            return transfer;
        }

        async function attachScreenshotFileToGemini(file, composer) {
            const root = getScreenshotUploadRoot(composer);
            const before = getScreenshotAttachmentSnapshot(root);

            // First choice: Gemini's own hidden <input type="file">.
            const fileInput = await revealGeminiImageFileInput(root);
            if (fileInput) {
                try {
                    const transfer = createScreenshotDataTransfer(file);
                    fileInput.files = transfer.files;

                    if (
                        fileInput.files &&
                        fileInput.files.length === 1 &&
                        fileInput.files[0].type === 'image/png' &&
                        fileInput.files[0].name === file.name
                    ) {
                        fileInput.dispatchEvent(new Event('input', { bubbles: true }));
                        fileInput.dispatchEvent(new Event('change', { bubbles: true }));

                        if (await waitForScreenshotAttachment(root, before, 6500)) {
                            composer.focus();
                            return { ok: true, method: 'file-input' };
                        }
                    }
                } catch (error) {
                    console.warn('UD/AA: Gemini file input upload ishlamadi:', error);
                }
            }

            // Second choice: Gemini's xapfileselectordropzone (present in the
            // current composer DOM) and its normal drag/drop upload handlers.
            const dropZone = composer.closest('[xapfileselectordropzone]') ||
                document.querySelector('[xapfileselectordropzone]') ||
                root;

            if (dropZone) {
                try {
                    const transfer = createScreenshotDataTransfer(file);
                    const beforeDrop = getScreenshotAttachmentSnapshot(root);

                    for (const type of ['dragenter', 'dragover', 'drop']) {
                        dropZone.dispatchEvent(new DragEvent(type, {
                            bubbles: true,
                            cancelable: true,
                            dataTransfer: transfer
                        }));
                    }

                    if (await waitForScreenshotAttachment(root, beforeDrop, 8500)) {
                        composer.focus();
                        return { ok: true, method: 'drop-zone' };
                    }
                } catch (error) {
                    console.warn('UD/AA: Gemini drop-zone upload ishlamadi:', error);
                }
            }

            // Last fallback: provide a real File in ClipboardEvent.clipboardData.
            // This is an actual paste payload, not a synthetic Ctrl+V keypress.
            try {
                const transfer = createScreenshotDataTransfer(file);
                const beforePaste = getScreenshotAttachmentSnapshot(root);
                composer.focus();
                const pasteEvent = new ClipboardEvent('paste', {
                    bubbles: true,
                    cancelable: true,
                    clipboardData: transfer
                });
                composer.dispatchEvent(pasteEvent);

                if (await waitForScreenshotAttachment(root, beforePaste, 6500)) {
                    composer.focus();
                    return { ok: true, method: 'clipboard-paste-event' };
                }
            } catch (error) {
                console.warn('UD/AA: Gemini paste fallback ishlamadi:', error);
            }

            return {
                ok: false,
                error:
                    "Gemini rasmni qabul qilmadi. Chat inputidagi upload/drop mexanizmi " +
                    "orqali preview paydo bo'lgani tasdiqlanmadi."
            };
        }

        async function attachScreenshotRequest(message) {
            const requestId = String(message.requestId || ('legacy-' + Date.now()));

            if (completedScreenshotUploads.has(requestId)) {
                const previous = completedScreenshotUploads.get(requestId) || {};
                if (previous.promptAdded === true) {
                    return {
                        ok: true, attached: true, promptAdded: true,
                        duplicate: true, method: previous.method || null
                    };
                }

                // Recover a prior image-only attachment without uploading the same image twice.
                const composer = await waitForElement(findComposer, 10000);
                const prompt = String(message.prompt || SCREENSHOT_GEMINI_PROMPT).trim();
                const promptAdded = composer ? appendTextToComposer(composer, prompt) : false;
                if (composer) composer.focus();
                completedScreenshotUploads.set(requestId, {
                    promptAdded,
                    method: previous.method || null
                });
                return {
                    ok: true,
                    attached: true,
                    promptAdded,
                    duplicate: true,
                    method: previous.method || null,
                    promptError: promptAdded ? null : 'Prompt matnini Gemini inputiga qo\'shib bo\'lmadi.'
                };
            }

            if (pendingScreenshotUploads.has(requestId)) {
                return pendingScreenshotUploads.get(requestId);
            }

            const task = (async () => {
                if (
                    typeof message.dataUrl !== 'string' ||
                    !message.dataUrl.startsWith('data:image/png;base64,')
                ) {
                    return { ok: false, error: 'Screenshot PNG ma’lumoti noto‘g‘ri.' };
                }

                const composer = await waitForElement(findComposer, 25000);
                if (!composer) {
                    return {
                        ok: false,
                        error: 'Gemini chat inputi 25 soniya ichida tayyor bo‘lmadi.'
                    };
                }

                // Convert the exact PNG payload sent for this request into a File.
                const response = await fetch(message.dataUrl);
                if (!response.ok) {
                    return { ok: false, error: 'Screenshot PNG ma’lumoti o‘qilmadi.' };
                }

                const blob = await response.blob();
                if (!blob.size || blob.type !== 'image/png') {
                    return { ok: false, error: 'Screenshot image/png formatida emas.' };
                }

                const safeId = requestId.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 80);
                const file = new File(
                    [blob],
                    'screenshot-' + safeId + '.png',
                    { type: 'image/png', lastModified: Date.now() }
                );

                composer.focus();
                const result = await attachScreenshotFileToGemini(file, composer);

                if (!result.ok) return result;

                // Gemini can re-render its composer after the image preview appears.
                const activeComposer = await waitForElement(findComposer, 6000, 120);
                // Put the instruction in the SAME message composer as the image.
                // Keep the message unsent so the user can review it before sending.
                const prompt = String(message.prompt || SCREENSHOT_GEMINI_PROMPT).trim();
                const promptAdded = activeComposer
                    ? appendTextToComposer(activeComposer, prompt)
                    : false;
                if (activeComposer) activeComposer.focus();

                return {
                    ok: true,
                    attached: true,
                    promptAdded,
                    promptError: promptAdded ? null : 'Rasm biriktirildi, lekin prompt matni inputga yozilmadi.',
                    method: result.method
                };
            })();

            pendingScreenshotUploads.set(requestId, task);

            try {
                const result = await task;
                if (result.attached) {
                    completedScreenshotUploads.set(requestId, {
                        promptAdded: result.promptAdded === true,
                        method: result.method || null
                    });
                    if (completedScreenshotUploads.size > 60) {
                        const oldest = completedScreenshotUploads.keys().next().value;
                        completedScreenshotUploads.delete(oldest);
                    }
                }
                return result;
            } catch (error) {
                return {
                    ok: false,
                    error: error?.message || String(error)
                };
            } finally {
                pendingScreenshotUploads.delete(requestId);
            }
        }

        if (globalThis.chrome?.runtime?.onMessage) {
            chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
                if (!message || message.type !== 'NERIX_UPLOAD_SCREENSHOT_IFRAME') {
                    return false;
                }

                if (sender?.id && sender.id !== chrome.runtime.id) return false;

                attachScreenshotRequest(message).then(
                    result => sendResponse(result),
                    error => sendResponse({
                        ok: false,
                        error: error?.message || String(error)
                    })
                );

                return true;
            });
        }

        function insertTextIntoComposer(element, text) {
            if (!element || typeof text !== 'string') return false;
            element.focus();

            if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
                const prototype = element.tagName === 'TEXTAREA'
                    ? HTMLTextAreaElement.prototype
                    : HTMLInputElement.prototype;
                const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
                if (setter) setter.call(element, text);
                else element.value = text;
                element.dispatchEvent(new Event('input', { bubbles: true }));
                element.dispatchEvent(new Event('change', { bubbles: true }));
                return element.value === text;
            }

            // Prefer the editor's normal input mutation path.
            try {
                const selection = window.getSelection();
                const range = document.createRange();
                range.selectNodeContents(element);
                selection.removeAllRanges();
                selection.addRange(range);
                document.execCommand('delete', false);
                document.execCommand('insertText', false, text);
            } catch (_) {
                // Fall through to the contenteditable fallback.
            }

            const currentText = () => String(element.innerText || element.textContent || '').trim();
            if (currentText() !== text.trim()) {
                element.replaceChildren(document.createTextNode(text));
                const range = document.createRange();
                range.selectNodeContents(element);
                range.collapse(false);
                const selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(range);
                try {
                    element.dispatchEvent(new InputEvent('input', {
                        bubbles: true,
                        inputType: 'insertText',
                        data: text
                    }));
                } catch (_) {
                    element.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }

            return currentText().includes(text.trim());
        }

        function appendTextToComposer(element, text) {
            if (!element || typeof text !== 'string' || !text.trim()) return false;
            const value = text.trim();
            element.focus();

            const isField = element.tagName === 'TEXTAREA' || element.tagName === 'INPUT';
            if (isField) {
                const current = String(element.value || '').trim();
                if (current.includes(value)) return true;
                const next = current ? current + '\n' + value : value;
                const prototype = element.tagName === 'TEXTAREA'
                    ? HTMLTextAreaElement.prototype
                    : HTMLInputElement.prototype;
                const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
                if (setter) setter.call(element, next);
                else element.value = next;
                element.dispatchEvent(new InputEvent('input', {
                    bubbles: true, inputType: 'insertText', data: value
                }));
                element.dispatchEvent(new Event('change', { bubbles: true }));
                return String(element.value || '').includes(value);
            }

            const readText = () => String(element.innerText || element.textContent || '').trim();
            const before = readText();
            if (before.includes(value)) return true;

            try {
                const selection = window.getSelection();
                const range = document.createRange();
                range.selectNodeContents(element);
                range.collapse(false);
                selection.removeAllRanges();
                selection.addRange(range);
                const insertion = (before ? '\n' : '') + value;
                const inserted = document.execCommand('insertText', false, insertion);
                element.dispatchEvent(new InputEvent('input', {
                    bubbles: true, inputType: 'insertText', data: insertion
                }));
                if (inserted && readText().includes(value)) return true;
            } catch (_) {
                // Use the contenteditable's native DOM surface below.
            }

            try {
                const paragraph = document.createElement('p');
                paragraph.textContent = value;
                element.appendChild(paragraph);
                element.dispatchEvent(new InputEvent('input', {
                    bubbles: true, inputType: 'insertText', data: value
                }));
            } catch (insertErr) {
                nerixReportError('INSERT_COMPOSER', insertErr, { operation: 'insertTextIntoComposer DOM mutation' });
            }
            return readText().includes(value);
        }

        function findSendButton(composer) {
            const selectors = [
                'button[aria-label*="send" i]',
                'button[aria-label*="yubor" i]',
                'button[aria-label*="jo.nat" i]',
                'button[data-testid*="send" i]',
                'button[data-test-id*="send" i]',
                'button.send-button'
            ];

            // Prefer a send button close to the composer to avoid clicking an
            // unrelated button elsewhere on the Gemini page.
            const scope = composer?.closest('form') ||
                composer?.parentElement?.parentElement?.parentElement || document;
            for (const selector of selectors) {
                const button = scope.querySelector?.(selector);
                if (button && !button.disabled && button.getAttribute('aria-disabled') !== 'true') {
                    return button;
                }
            }

            const buttons = Array.from(document.querySelectorAll('button'));
            return buttons.find(button => {
                const label = (button.getAttribute('aria-label') || button.title || '').toLowerCase();
                return /send|yuborish|jo.natish/.test(label) &&
                    !button.disabled && button.getAttribute('aria-disabled') !== 'true';
            }) || null;
        }

        async function clickSend(composer) {
            const button = await waitForElement(
                () => findSendButton(composer),
                3500,
                150
            );
            if (button) {
                button.click();
                return true;
            }

            if (!composer) return false;
            const before = String(composer.innerText || composer.value || composer.textContent || '').trim();
            composer.focus();
            composer.dispatchEvent(new KeyboardEvent('keydown', {
                key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
                bubbles: true, cancelable: true
            }));
            composer.dispatchEvent(new KeyboardEvent('keyup', {
                key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
                bubbles: true, cancelable: true
            }));
            await delay(900);
            const after = String(composer.innerText || composer.value || composer.textContent || '').trim();

            // A cleared composer is the best available confirmation when the
            // Send button was not found. Otherwise ask the user to send manually.
            return before.length > 0 && after.length === 0;
        }

        // -----------------------------------------------------------------
        // Messages from the parent webpage
        // -----------------------------------------------------------------
        window.addEventListener('message', event => {
            if (!event.data || event.source !== window.parent) return;
            if (window.parent !== window && event.origin === 'null') return;

            if (event.data.type === 'NERIX_AUTO_PROMPT') {
                if (typeof event.data.text !== 'string' || !event.data.text.trim()) return;
                const rawText = event.data.text.trim();
                const hasMath = event.data.meta?.hasMath === true;
                let instruction;
                if (hasMath) {
                    instruction = "Senga berilgan misol ni yoki Savolni yech";
                } else {
                    instruction = "\n\nJavob: [asosiy to'g'ri javob] deb aniq yoz. Javobingning oxirida aynan ikki qatorni ber: 1.J: [asosiy to'g'ri javob] va 2.Q: [javob nechanchi qator yoki variant]. Ulardan keyin boshqa izoh yozma.";
                }
                const reportFormat = "\n\nAsosiy javobni alohida 'Javob: ...' satrida yoz. Eng oxirida aynan ikki qatorni ber: \n1.J: [asosiy to'g'ri javob]\n2.Q: [javob nechanchi qator yoki variant]. 2.Q dan keyin boshqa izoh yozma.";
                const prompt = rawText + instruction + reportFormat;
                void insertAndSend(prompt);
            } else if (event.data.type === 'NERIX_FOCUS_COMPOSER') {
                void waitForComposerAndFocus(10000);
            }
        });

        // Alt+Z inside Gemini iframe: relay to parent page
        document.addEventListener('keydown', event => {
            if (event.altKey && event.code === 'KeyZ' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                event.preventDefault();
                event.stopPropagation();
                if (!altZActive) {
                    altZActive = true;
                    try { window.parent.postMessage({ type: 'NERIX_ALT_Z_DOWN' }, '*'); } catch (_) {}
                }
            }
        }, true);

        document.addEventListener('keyup', event => {
            if ((event.code === 'KeyZ' || event.key === 'Alt') && altZActive) {
                altZActive = false;
                try { window.parent.postMessage({ type: 'NERIX_ALT_Z_UP' }, '*'); } catch (_) {}
            }
        }, true);

        // Alt+W inside Gemini iframe: relay to parent page
        document.addEventListener('keydown', event => {
            if (event.altKey && event.code === 'KeyW' &&
                !event.ctrlKey && !event.shiftKey && !event.repeat) {
                event.preventDefault();
                event.stopPropagation();
                if (!altWActive) {
                    altWActive = true;
                    try { window.parent.postMessage({ type: 'NERIX_ALT_W_DOWN' }, '*'); } catch (_) {}
                }
            }
        }, true);

        document.addEventListener('keyup', event => {
            if ((event.code === 'KeyW' || event.key === 'Alt') && altWActive) {
                altWActive = false;
                try { window.parent.postMessage({ type: 'NERIX_ALT_W_UP' }, '*'); } catch (_) {}
            }
        }, true);

        // Ctrl+CapsLock pressed while focus is inside Gemini iframe.
        document.addEventListener('keydown', event => {
            if (event.ctrlKey && event.code === 'CapsLock' && !event.altKey && !event.shiftKey) {
                event.preventDefault();
                event.stopPropagation();
                try {
                    chrome.runtime.sendMessage({ type: 'NERIX_RELAY_TOGGLE_GEMINI_POPUP' }, () => {
                        void chrome.runtime.lastError;
                    });
                } catch (_) {
                    // Ignore transient service-worker/context errors.
                }
            }
        }, true);

        // Alt+CapsLock inside Gemini iframe: relay to toggle Chat panel.
        document.addEventListener('keydown', event => {
            if (event.altKey && event.code === 'CapsLock' && !event.ctrlKey && !event.shiftKey) {
                event.preventDefault();
                event.stopPropagation();
                try {
                    chrome.runtime.sendMessage({ type: 'NERIX_RELAY_TOGGLE_CHAT' }, () => {
                        void chrome.runtime.lastError;
                    });
                } catch (relayErr) {
                    nerixReportError('MESSAGE_BUS', relayErr, { operation: 'sendMessage NERIX_RELAY_TOGGLE_CHAT' });
                }
            }
        }, true);

        async function insertAndSend(text) {
            const composer = await waitForElement(findComposer, 10000);
            if (!composer) return false;
            const inserted = insertTextIntoComposer(composer, text);
            if (!inserted) return false;
            await delay(350);
            return clickSend(composer);
        }

        // -----------------------------------------------------------------
        // Final assistant answer tracking + exact J/Q extraction.
        // Only a newly-started, completed assistant turn is eligible.
        // -----------------------------------------------------------------
        function getConversationId() {
            const parts = String(location.pathname || '').split('/').filter(Boolean);
            const appIndex = parts.indexOf('app');
            const candidate = appIndex >= 0 ? parts[appIndex + 1] : null;
            if (!candidate || candidate === 'new' || candidate === 'recent') return null;
            return /^[a-zA-Z0-9_-]{6,}$/.test(candidate) ? candidate : null;
        }

        function getConversationInstructionKey(conversationId) {
            return 'nerixGeminiSystemInstruction:' + String(conversationId);
        }

        function safeSessionGet(key) {
            try { return sessionStorage.getItem(key); } catch (_) { return null; }
        }

        function safeSessionSet(key, value) {
            try { sessionStorage.setItem(key, value); } catch (_) {}
        }

        function safeSessionRemove(key) {
            try { sessionStorage.removeItem(key); } catch (_) {}
        }

        function isVisibleElement(element) {
            if (!element || !element.isConnected || element.hidden) return false;
            const style = getComputedStyle(element);
            return style.display !== 'none' && style.visibility !== 'hidden';
        }

        function getAssistantMessages() {
            // Prefer Gemini's semantic response containers; avoid generic .markdown
            // nodes, which also occur inside old messages and user content.
            const selectors = [
                'model-response',
                '[data-message-author-role="assistant"]',
                '[data-test-id="response-container"]',
                '[data-test-id*="model-response"]',
                'message-content',
                '.message-content',
                '.model-response-text',
                '.markdown'
            ];

            for (const selector of selectors) {
                let nodes = [];
                try { nodes = Array.from(document.querySelectorAll(selector)); } catch (qErr) {
                    nerixReportError('RESPONSE_DETECTION', qErr, { selector });
                }
                nodes = nodes.filter(node => {
                    if (!isVisibleElement(node) ||
                        !String(node.innerText || node.textContent || '').trim()) return false;
                    // Never accept a user turn as a Gemini assistant answer.
                    if (node.closest('user-query,[data-message-author-role="user"],[data-test-id*="user-query"],[data-message-type="user"]')) return false;
                    return true;
                });
                if (!nodes.length) continue;

                // Remove nested duplicate candidates, keeping the outer assistant turn.
                return nodes.filter(node => !nodes.some(other =>
                    other !== node && other.contains(node)
                ));
            }
            return [];
        }

        function getLatestAssistantMessage() {
            try {
                const messages = getAssistantMessages();
                if (!messages.length) return null;
                return messages[messages.length - 1];
            } catch (err) {
                nerixReportError('GET_LATEST_ASSISTANT_MSG', err, { operation: 'getLatestAssistantMessage' });
                return null;
            }
        }

        function getAssistantMessageText(element) {
            if (!element) return '';
            try {
                return String(element.innerText || element.textContent || '')
                    .replace(/\u00a0/g, ' ')
                    .replace(/\r\n?/g, '\n')
                    .replace(/[\u200B-\u200D\uFEFF]/g, '')
                    .trim();
            } catch (err) {
                nerixReportError('GET_ASSISTANT_MSG_TEXT', err, { tagName: element?.tagName });
                return '';
            }
        }

        function normalizeReportLine(line) {
            return String(line || '')
                .replace(/^\s*(?:[-*•]\s+)?/, '')
                .replace(/^\s*#{1,6}\s*/, '')
                // Remove Markdown emphasis without deleting a math "*" operator.
                .replace(/\*\*/g, '')
                .replace(/__/g, '')
                .replace(/^\*([^*]+)\*(?=\s|$)/, '$1')
                .replace(/^_([^_]+)_(?=\s|$)/, '$1')
                .replace(/`/g, '')
                .trim();
        }

        function matchReportMarker(line, markerNumber, markerLetter) {
            const cleaned = normalizeReportLine(line);
            const expression = new RegExp('^' + markerNumber + '\\s*\\.\\s*' + markerLetter + '\\s*:\\s*(.*)$', 'i');
            return cleaned.match(expression);
        }

        function extractMainAnswerFromResponse(rawText, fallbackAnswer = '') {
            const normalized = String(rawText || '')
                .replace(/\u00a0/g, ' ')
                .replace(/\r\n?/g, '\n')
                .replace(/[\u200B-\u200D\uFEFF]/g, '');
            const lines = normalized.split('\n');

            for (let index = lines.length - 1; index >= 0; index--) {
                const line = normalizeReportLine(lines[index]);
                // Gemini may write either "Javob: 25" or put the value on
                // the next line under a standalone "Javob" heading.
                const label = line.match(/^Javob\s*(?:[:：-]\s*)?(.*)$/i);
                if (!label) continue;

                const parts = [label[1]];
                for (let next = index + 1; next < lines.length; next++) {
                    if (matchReportMarker(lines[next], 1, 'J') ||
                        matchReportMarker(lines[next], 2, 'Q')) break;
                    parts.push(lines[next]);
                }
                const result = parts.map(part => String(part || '').trim())
                    .filter(Boolean).join('\n').trim();
                if (result) return result;
            }

            return String(fallbackAnswer || '').trim();
        }

        function parseTerminalReport(rawText) {
            const normalized = String(rawText || '')
                .replace(/\u00a0/g, ' ')
                .replace(/\r\n?/g, '\n')
                .replace(/[\u200B-\u200D\uFEFF]/g, '');
            const lines = normalized.split('\n');
            while (lines.length && !normalizeReportLine(lines[lines.length - 1])) lines.pop();
            if (!lines.length) return null;

            // Find the final Q marker from the bottom; supports 2.Q:, 2. Q:, and Markdown.
            let qIndex = -1;
            let qMatch = null;
            for (let index = lines.length - 1; index >= 0; index--) {
                const match = matchReportMarker(lines[index], 2, 'Q');
                if (match) {
                    qIndex = index;
                    qMatch = match;
                    break;
                }
            }
            if (qIndex < 0 || !qMatch) return null;

            // Use the closest preceding J marker so multi-line math stays intact.
            let jIndex = -1;
            let jMatch = null;
            for (let index = qIndex - 1; index >= 0; index--) {
                const match = matchReportMarker(lines[index], 1, 'J');
                if (match) {
                    jIndex = index;
                    jMatch = match;
                    break;
                }
            }
            if (jIndex < 0 || !jMatch) return null;

            const answerParts = [jMatch[1], ...lines.slice(jIndex + 1, qIndex)];
            const answer = answerParts.map(line => String(line || '').trim())
                .filter((line, index) => line || index === 0).join('\n').trim();
            const questionRow = [qMatch[1], ...lines.slice(qIndex + 1)]
                .map(line => String(line || '').trim()).filter(Boolean).join('\n').trim();
            if (!answer || !questionRow) return null;

            return {
                answer,
                questionRow,
                mainAnswer: extractMainAnswerFromResponse(normalized, answer)
            };
        }

        // -----------------------------------------------------------------
        // DOM-aware extraction using data-path-to-node (Gemini-specific)
        // -----------------------------------------------------------------

        /**
         * compareNodePaths(a, b)
         * Compare two comma-separated numeric path strings left-to-right.
         * Returns negative if a < b, positive if a > b, 0 if equal.
         * "10" > "2", "2,3,1" > "2,3,0", "2,1,0" > "2,1".
         */
        function compareNodePaths(a, b) {
            const aParts = String(a || '').split(',').map(s => parseInt(s.trim(), 10) || 0);
            const bParts = String(b || '').split(',').map(s => parseInt(s.trim(), 10) || 0);
            const len = Math.max(aParts.length, bParts.length);
            for (let i = 0; i < len; i++) {
                const av = i < aParts.length ? aParts[i] : -1;
                const bv = i < bParts.length ? bParts[i] : -1;
                if (av !== bv) return av - bv;
            }
            return 0;
        }

        /**
         * extractRichTextFromParagraph(pEl)
         * Walk a paragraph element and build a plain-text string, reading
         * math formulae from the data-math attribute on .math-inline elements
         * (and falling back to the full extractLatexFromMathElement machinery
         * for other math containers).  Non-math text nodes are taken as-is.
         * KaTeX internal rendering subtrees (.katex-mathml, .katex-html) are
         * skipped to avoid duplicates.
         */
        function extractRichTextFromParagraph(pEl) {
            if (!pEl) return '';
            const parts = [];
            const seenMath = new WeakSet();

            // Inline math-container detection — mirrors isMathContainer() in
            // runWebpageContext() without crossing the closure boundary.
            function isMathContainerInline(el) {
                if (!el || el.nodeType !== 1) return false;
                const tag = (el.tagName || '').toLowerCase();
                const ns = el.namespaceURI || '';
                const MATHML_TAGS = new Set([
                    'math','mrow','mi','mn','mo','mfrac','msqrt','mroot',
                    'msup','msub','msubsup','mfenced','mover','munder',
                    'munderover','mtable','mtr','mtd','mtext','mspace',
                    'mstyle','merror','mpadded','mphantom','menclose',
                    'semantics','annotation','annotation-xml'
                ]);
                if (MATHML_TAGS.has(tag) || ns === 'http://www.w3.org/1998/Math/MathML') return true;
                const cls = el.classList;
                if (cls?.contains('katex') || cls?.contains('katex-display') ||
                    cls?.contains('editor-equation') || cls?.contains('katex-html')) return true;
                if (tag === 'mjx-container' || tag === 'mjx-math') return true;
                if (el.hasAttribute?.('data-latex') || el.hasAttribute?.('data-tex') ||
                    el.hasAttribute?.('data-mathml')) return true;
                if (tag === 'script' && (el.type || '').startsWith('math/tex')) return true;
                return false;
            }

            function walk(node) {
                if (!node) return;

                // --- text node ---
                if (node.nodeType === 3) {
                    const t = (node.textContent || '');
                    if (t) parts.push(t);
                    return;
                }
                if (node.nodeType !== 1) return;

                const tag = (node.tagName || '').toLowerCase();
                const cls = node.classList;

                // Skip style/script/svg decorations
                if (tag === 'style' || tag === 'script' || tag === 'svg') return;

                // Skip KaTeX internal subtrees; their parent .math-inline
                // (or .katex / .katex-display) handles the output.
                if (cls && (cls.contains('katex-mathml') || cls.contains('katex-html'))) return;

                // .math-inline with data-math — primary Gemini math source
                if (cls && cls.contains('math-inline') && node.hasAttribute('data-math')) {
                    if (!seenMath.has(node)) {
                        seenMath.add(node);
                        const raw = node.getAttribute('data-math') || '';
                        if (raw.trim()) {
                            parts.push(raw.trim());
                            return;
                        }
                    }
                    // data-math empty; fall through to generic math extraction below
                }

                // Generic math container (KaTeX, MathML, MathJax, etc.)
                if (isMathContainerInline(node)) {
                    if (!seenMath.has(node)) {
                        seenMath.add(node);
                        // Prefer data-math on the element itself
                        const dm = (node.getAttribute?.('data-math') || '').trim();
                        if (dm) { parts.push(dm); return; }
                        // Last resort: visible text content
                        const fb = (node.textContent || '').trim();
                        if (fb) parts.push(fb);
                    }
                    return;
                }

                // Regular element — recurse into children
                for (const child of node.childNodes) walk(child);
            }

            walk(pEl);

            return parts.join('')
                .replace(/\u00a0/g, ' ')
                .replace(/\r\n?/g, '\n')
                .replace(/[\u200B-\u200D\uFEFF]/g, '')
                .trim();
        }

        /**
         * extractBoldAnswer(containerEl)
         * Original bold-element extraction logic.
         * Collects ALL b/strong elements from the response in DOM order.
         *
         * Math handling inside bold elements:
         *   • .math-inline[data-math]  → uses data-math attribute (raw LaTeX)
         *   • Generic math containers  → reads data-math attr, then innerText
         *   • KaTeX internals (.katex-mathml, .katex-html) → skipped to avoid dups
         *
         * NOTE: isMathContainer() lives in runWebpageContext() (a different scope).
         * This function runs in runGeminiFrameContext() and therefore uses its own
         * inline math-container detection to avoid the ReferenceError.
         *
         * If bold elements exist → join with " | ".
         * If none exist         → use the full plain-text response as fallback.
         */
        function extractBoldAnswer(containerEl) {
            try {
                if (!containerEl) {
                    nerixLog('warn', 'BOLD_EXTRACTION', 'extractBoldAnswer called with no container element.');
                    return '';
                }

                const currentText = String(containerEl.innerText || containerEl.textContent || '')
                    .replace(/\u00a0/g, ' ')
                    .replace(/\r\n?/g, '\n')
                    .replace(/[\u200B-\u200D\uFEFF]/g, '')
                    .trim();

                // Inline math-container detection for the Gemini frame scope.
                // Mirrors the logic of isMathContainer() in runWebpageContext()
                // without crossing the closure boundary.
                function isMathContainerLocal(el) {
                    if (!el || el.nodeType !== 1) return false;
                    const tag = (el.tagName || '').toLowerCase();
                    const ns = el.namespaceURI || '';
                    const MATHML_TAGS = new Set([
                        'math','mrow','mi','mn','mo','mfrac','msqrt','mroot',
                        'msup','msub','msubsup','mfenced','mover','munder',
                        'munderover','mtable','mtr','mtd','mtext','mspace',
                        'mstyle','merror','mpadded','mphantom','menclose',
                        'semantics','annotation','annotation-xml'
                    ]);
                    if (MATHML_TAGS.has(tag) || ns === 'http://www.w3.org/1998/Math/MathML') return true;
                    const cls = el.classList;
                    if (cls?.contains('katex') || cls?.contains('katex-display') ||
                        cls?.contains('editor-equation') || cls?.contains('katex-html')) return true;
                    if (tag === 'mjx-container' || tag === 'mjx-math') return true;
                    if (el.hasAttribute?.('data-latex') || el.hasAttribute?.('data-tex') ||
                        el.hasAttribute?.('data-mathml')) return true;
                    if (tag === 'script' && (el.type || '').startsWith('math/tex')) return true;
                    return false;
                }

                let boldElements;
                try {
                    boldElements = containerEl.querySelectorAll('b, strong');
                } catch (qErr) {
                    nerixReportError('BOLD_EXTRACTION', qErr, { operation: 'querySelectorAll("b, strong")' });
                    return currentText;
                }

                if (boldElements && boldElements.length > 0) {
                    nerixLog('info', 'BOLD', 'Found ' + boldElements.length + ' bold element(s); extracting.');

                    const parts = Array.from(boldElements).map((el, elIdx) => {
                        const seenMath = new WeakSet();
                        const textParts = [];

                        function walkBold(node) {
                            if (!node) return;

                            // Text node
                            if (node.nodeType === 3) {
                                const t = (node.textContent || '');
                                if (t) textParts.push(t);
                                return;
                            }
                            if (node.nodeType !== 1) return;

                            const cls = node.classList;
                            const tag = (node.tagName || '').toLowerCase();

                            // Skip KaTeX internal subtrees — parent .math-inline handles output.
                            if (cls && (cls.contains('katex-mathml') || cls.contains('katex-html'))) return;
                            if (tag === 'style' || tag === 'script' || tag === 'svg') return;

                            // .math-inline[data-math] — use raw LaTeX from data-math attribute.
                            if (cls && cls.contains('math-inline') && node.hasAttribute('data-math')) {
                                if (!seenMath.has(node)) {
                                    seenMath.add(node);
                                    const raw = (node.getAttribute('data-math') || '').trim();
                                    if (raw) { textParts.push(raw); return; }
                                    // data-math empty — fall through to generic math extraction
                                }
                            }

                            // Generic math container — read data-math or innerText fallback.
                            if (isMathContainerLocal(node)) {
                                if (!seenMath.has(node)) {
                                    seenMath.add(node);
                                    const dm = (node.getAttribute?.('data-math') || '').trim();
                                    if (dm) { textParts.push(dm); return; }
                                    // Last resort: visible text content of the math element
                                    const fb = (node.textContent || '').trim();
                                    if (fb) textParts.push(fb);
                                }
                                return;
                            }

                            for (const child of node.childNodes) {
                                try {
                                    walkBold(child);
                                } catch (wErr) {
                                    nerixReportError('BOLD_WALK', wErr, {
                                        operation: 'walkBold child node',
                                        boldElementIndex: elIdx,
                                        nodeType: child?.nodeType,
                                        nodeName: child?.nodeName
                                    });
                                }
                            }
                        }

                        try {
                            walkBold(el);
                        } catch (walkErr) {
                            nerixReportError('BOLD_WALK', walkErr, {
                                operation: 'walkBold top-level',
                                boldElementIndex: elIdx,
                                tagName: el?.tagName
                            });
                        }

                        return textParts.join('')
                            .replace(/\u00a0/g, ' ')
                            .replace(/[\u200B-\u200D\uFEFF]/g, '')
                            .trim();
                    }).filter(Boolean);

                    if (parts.length > 0) {
                        nerixLog('info', 'BOLD', 'Extraction completed: ' + parts.length + ' non-empty part(s).');
                        return parts.join(' | ');
                    }

                    nerixLog('warn', 'BOLD', 'Bold elements found but all yielded empty text; using full-text fallback.');
                } else {
                    nerixLog('warn', 'RESPONSE', 'No bold elements found; using full-text fallback.');
                }

                // No bold elements, or all were empty — use entire response text as fallback.
                return currentText;

            } catch (outerErr) {
                nerixReportError('BOLD_EXTRACTION', outerErr, { operation: 'extractBoldAnswer outer' });
                // Best-effort fallback: return raw innerText so the pipeline doesn't stall.
                try {
                    return String(containerEl?.innerText || containerEl?.textContent || '').trim();
                } catch (_) { return ''; }
            }
        }

        function isTerminalAnswerParagraph(richText) {
            const text = String(richText || '');
            const lines = text.split('\n');
            let hasJ = false;
            let hasQ = false;
            for (const line of lines) {
                if (!hasJ && matchReportMarker(line, 1, 'J')) hasJ = true;
                if (!hasQ && matchReportMarker(line, 2, 'Q')) hasQ = true;
                if (hasJ && hasQ) return true;
            }
            // Also check inline (no newlines between markers, as Gemini sometimes
            // puts all spans in a single paragraph without line breaks)
            if (!hasJ || !hasQ) {
                const norm = text.replace(/\s+/g, ' ');
                if (/1\s*\.\s*J\s*:/i.test(norm) && /2\s*\.\s*Q\s*:/i.test(norm)) return true;
            }
            return hasJ && hasQ;
        }

        /**
         * extractFromDOMResponseContainer(containerEl)
         * Find p[data-path-to-node] paragraphs in the given container,
         * sort by numeric path descending, find the first one that carries
         * a valid 1.J / 2.Q terminal answer, extract its rich text
         * (with data-math formulas preserved), and return a parseTerminalReport-
         * compatible result object — or null if nothing valid is found.
         */
        function extractFromDOMResponseContainer(containerEl) {
            if (!containerEl) return null;

            // Collect p[data-path-to-node] scoped to this container only
            let candidates = [];
            try {
                candidates = Array.from(
                    containerEl.querySelectorAll('p[data-path-to-node]')
                );
            } catch (_) { return null; }

            if (!candidates.length) return null;

            // Sort by numeric path descending, using DOM order as tiebreaker
            // (candidates are already in DOM order, so we use a stable sort)
            const indexed = candidates.map((el, domIndex) => ({
                el,
                path: el.getAttribute('data-path-to-node') || '',
                domIndex
            }));
            indexed.sort((a, b) => {
                const cmp = compareNodePaths(b.path, a.path);
                if (cmp !== 0) return cmp;
                return b.domIndex - a.domIndex; // later in DOM wins
            });

            // Inspect paragraphs in descending path order
            for (const { el } of indexed) {
                const richText = extractRichTextFromParagraph(el);
                if (!richText) continue;
                if (!isTerminalAnswerParagraph(richText)) continue;

                // Normalize inline format: Gemini may place 1.J: and 2.Q: on a
                // single line without a newline between them when all content is
                // in sibling spans inside one <p>.  parseTerminalReport requires
                // each marker to start at the beginning of a line.
                const normalizedText = richText.replace(
                    /([^\n])(2\s*\.\s*Q\s*:)/gi,
                    '$1\n$2'
                );

                const parsed = parseTerminalReport(normalizedText);
                if (parsed && parsed.answer && parsed.questionRow) return parsed;
            }

            return null;
        }

        function isGenerationStopVisible() {
            const selectors = [
                'button[aria-label]',
                '[role="button"][aria-label]',
                'button[data-test-id*="stop"]',
                '[data-test-id*="stop"] button',
                'mat-icon[fonticon*="stop"]'
            ];
            const elements = new Set();
            for (const selector of selectors) {
                try {
                    document.querySelectorAll(selector).forEach(element => elements.add(element));
                } catch (qErr) {
                    nerixReportError('RESPONSE_DETECTION', qErr, { operation: 'isGenerationStopVisible', selector });
                }
            }
            for (const element of elements) {
                if (!isVisibleElement(element)) continue;
                const label = [
                    element.getAttribute('aria-label'),
                    element.getAttribute('data-test-id'),
                    element.getAttribute('title'),
                    element.getAttribute('fonticon'),
                    element.textContent
                ].filter(Boolean).join(' ').toLowerCase();
                if (/stop(?!\s*(audio|reading|playback|sharing))|stop[-_ ]?(generation|response)|to.?xtat|bekor qilish/.test(label)) {
                    return true;
                }
            }
            return false;
        }

        function isComposerReady() {
            const composer = findComposer();
            if (!composer || !isVisibleElement(composer)) return false;
            if (composer.disabled || composer.getAttribute('aria-disabled') === 'true') return false;
            if (composer.getAttribute('contenteditable') === 'false') return false;
            return true;
        }

        function notifyParentPending() {
            if (window.parent !== window) {
                try {
                    window.parent.postMessage({ type: 'NERIX_RESPONSE_PENDING' }, '*');
                } catch (err) {
                    nerixReportError('MESSAGE_BUS', err, { operation: 'postMessage NERIX_RESPONSE_PENDING' });
                }
            }
        }

        function beginTrackedTurn(source = 'user-send') {
            if (systemInstructionSendPending) source = 'system-instruction';
            const now = Date.now();
            if (trackedTurn && now - trackedTurn.startedAt < 1500 && !trackedTurn.completed) return;

            const latest = getLatestAssistantMessage();
            trackedTurn = {
                id: ++nextTurnId,
                source,
                startedAt: now,
                baselineRoot: latest,
                baselineText: getAssistantMessageText(latest),
                started: false,
                candidateText: '',
                candidateSince: 0,
                completed: false
            };
            notifyParentPending();
        }

        function handleSendIntent(event) {
            const composer = findComposer();
            if (!composer) return;

            if (event.type === 'keydown') {
                if (event.key !== 'Enter' || event.shiftKey || event.isComposing || event.repeat) return;
                const active = document.activeElement;
                if (active === composer || composer.contains(active)) {
                    beginTrackedTurn('composer-enter');
                }
                return;
            }

            if (event.type === 'submit') {
                const form = event.target;
                if (form && (form.contains(composer) || composer.closest('form') === form)) {
                    beginTrackedTurn('composer-submit');
                }
                return;
            }

            if (event.type === 'click') {
                const button = event.target?.closest?.('button,[role="button"]');
                if (!button) return;
                const sendButton = findSendButton(composer);
                const sendLabel = [
                    button.getAttribute('aria-label'),
                    button.getAttribute('data-test-id'),
                    button.getAttribute('data-testid'),
                    button.title,
                    button.textContent
                ].filter(Boolean).join(' ').toLowerCase();
                const iconLabel = Array.from(button.querySelectorAll('mat-icon,[data-mat-icon-name],svg'))
                    .map(icon => [icon.getAttribute('fonticon'), icon.getAttribute('data-mat-icon-name'), icon.getAttribute('aria-label')]
                        .filter(Boolean).join(' ')).join(' ').toLowerCase();
                const composerScope = composer.closest('form') ||
                    composer.parentElement?.parentElement?.parentElement || composer.parentElement;
                const insideComposerControls = !!composerScope?.contains(button);
                const explicitlySend = /send|yubor|jo.nat|submit/.test(sendLabel + ' ' + iconLabel);
                const isMatchedSendButton = sendButton && (
                    button === sendButton || button.contains(sendButton) || sendButton.contains(button)
                );
                if (isMatchedSendButton || (insideComposerControls && explicitlySend &&
                    !/attach|upload|tools|microphone|voice|photo|image/.test(sendLabel + ' ' + iconLabel))) {
                    beginTrackedTurn('send-button');
                }
            }
        }

        function inspectLatestResponse() {
            try {
                if (!trackedTurn && isGenerationStopVisible()) {
                    beginTrackedTurn('generation-detected');
                    if (trackedTurn) trackedTurn.started = true;
                }
                if (!trackedTurn || trackedTurn.completed) return;

                const latest = getLatestAssistantMessage();
                const currentText = getAssistantMessageText(latest);
                const stopVisible = isGenerationStopVisible();
                const rootChanged = !!latest && latest !== trackedTurn.baselineRoot;
                const textChanged = !!currentText && currentText !== trackedTurn.baselineText;

                if (stopVisible || rootChanged || textChanged) trackedTurn.started = true;
                if (!trackedTurn.started || !currentText) {
                    if (trackedTurn.started && !currentText) {
                        nerixLog('warn', 'RESPONSE', 'Response tracking active but no text readable from DOM.',
                            { turnId: trackedTurn.id, hasLatest: !!latest });
                    }
                    return;
                }

                const now = Date.now();
                if (currentText !== trackedTurn.candidateText) {
                    trackedTurn.candidateText = currentText;
                    trackedTurn.candidateSince = now;
                    return;
                }

                // Completion requires the stop control to disappear, the editor to be
                // interactive again, and the last assistant text to remain unchanged.
                if (stopVisible || !isComposerReady()) return;
                if (now - trackedTurn.startedAt < 700) return;
                if (now - trackedTurn.candidateSince < 2400) return;

                nerixLog('info', 'RESPONSE', 'New Gemini response detected (turn ' + trackedTurn.id + ', source: ' + trackedTurn.source + ').');

                const completedId = trackedTurn.id;
                const completedSource = trackedTurn.source;
                trackedTurn.completed = true;
                lastCompletedTurnId = completedId;

                // Priority 1: structured DOM extraction (finds 1.J / 2.Q paragraphs
                // with data-path-to-node and preserves raw LaTeX from data-math).
                // Priority 2: bold-element extraction (b / strong).
                // Priority 3: full plain-text fallback.
                let domParsed = null;
                try {
                    domParsed = extractFromDOMResponseContainer(latest);
                } catch (domErr) {
                    nerixReportError('DOM_EXTRACTION', domErr, {
                        turnId: completedId,
                        source: completedSource
                    });
                }

                let exactAnswer = '';
                let questionRow = '';
                if (domParsed && domParsed.answer) {
                    exactAnswer  = domParsed.answer;
                    questionRow  = domParsed.questionRow || '';
                    nerixLog('info', 'RESPONSE', 'DOM extraction succeeded (turn ' + completedId + ').');
                } else {
                    // Fall back to bold-element extraction.
                    try {
                        exactAnswer = extractBoldAnswer(latest);
                    } catch (extractErr) {
                        nerixReportError('BOLD_EXTRACTION', extractErr, {
                            turnId: completedId,
                            source: completedSource,
                            hasLatest: !!latest
                        });
                        // Last resort: plain text so the pipeline doesn't stall.
                        exactAnswer = currentText;
                    }
                }

                if (exactAnswer && completedSource !== 'system-instruction') {
                    const payload = {
                        type: 'NERIX_SHOW_PARSED_ANSWER',
                        answer: exactAnswer,
                        questionRow: questionRow,
                        mainAnswer: exactAnswer,
                        fullText: currentText
                    };
                    if (window.parent !== window) {
                        try {
                            window.parent.postMessage(payload, '*');
                            nerixLog('info', 'MESSAGE', 'Response sent to parent frame (turn ' + completedId + ').');
                        } catch (postErr) {
                            nerixReportError('MESSAGE_BUS', postErr, {
                                operation: 'postMessage NERIX_SHOW_PARSED_ANSWER',
                                turnId: completedId
                            });
                        }
                    } else {
                        try {
                            renderLocalParsedAnswer(payload);
                            nerixLog('info', 'MESSAGE', 'Response rendered locally (turn ' + completedId + ').');
                        } catch (renderErr) {
                            nerixReportError('RENDER_LOCAL', renderErr, { turnId: completedId });
                        }
                    }
                } else if (!exactAnswer) {
                    nerixLog('warn', 'RESPONSE', 'All extraction paths returned empty for turn ' + completedId + '; nothing to display.');
                }

                trackedTurn = null;

            } catch (outerErr) {
                nerixReportError('INSPECT_RESPONSE', outerErr, { operation: 'inspectLatestResponse outer' });
                // Do NOT null trackedTurn here — let the next poll retry completion detection.
            }
        }

        let localParsedOverlay = null;
        let localParsedOverlayCard = null;
        function renderLocalParsedAnswer(payload) {
            if (!document.body || !payload?.answer) return;
            if (!localParsedOverlay?.isConnected || !localParsedOverlayCard) {
                const overlay = createAnswerOverlayHost('nerix-local-jq-answer', 'top');
                if (!overlay) return;
                localParsedOverlay = overlay.host;
                localParsedOverlayCard = overlay.card;
            }

            const localAnswerText = String(payload.answer).trim();
            const { answerLine: localAnsLine, rowLine: localRowLine } = udaaBuildAnswerCardDOM(
                localAnswerText,
                payload.questionRow || ''
            );
            localParsedOverlayCard.replaceChildren(localAnsLine, localRowLine);
            animateAnswerOverlayIn(localParsedOverlayCard);
        }

        async function waitForTrackedTurnCompletion(turnId, timeoutMs = 120000) {
            const deadline = Date.now() + timeoutMs;
            while (Date.now() < deadline) {
                if (lastCompletedTurnId === turnId) return true;
                await delay(250);
            }
            return false;
        }

        function hasAnyConversationMessages() {
            if (getAssistantMessages().length) return true;
            const userSelectors = [
                'user-query',
                '[data-message-author-role="user"]',
                '[data-test-id*="user-query"]',
                '.user-query'
            ];
            return userSelectors.some(selector => {
                try {
                    return Array.from(document.querySelectorAll(selector)).some(node =>
                        String(node.innerText || node.textContent || '').trim().length > 0
                    );
                } catch (_) { return false; }
            });
        }

        function hasInstructionInExistingConversation() {
            const selectors = [
                'user-query',
                '[data-message-author-role="user"]',
                '[data-test-id*="user-query"]',
                '.user-query'
            ];
            for (const selector of selectors) {
                let nodes = [];
                try { nodes = Array.from(document.querySelectorAll(selector)); } catch (qErr) {
                    nerixReportError('RESPONSE_DETECTION', qErr, { operation: 'hasInstructionInExistingConversation', selector });
                }
                if (nodes.some(node => /GEMINI SYSTEM INSTRUCTION/i.test(
                    String(node.innerText || node.textContent || '')
                ))) return true;
            }
            return false;
        }

        async function ensureGeminiSystemInstruction() {
            if (instructionInitPromise) return instructionInitPromise;
            instructionInitPromise = (async () => {
                const conversationId = getConversationId();
                if (conversationId) {
                    const key = getConversationInstructionKey(conversationId);
                    try {
                        const stored = await chrome.storage.local.get(key);
                        if (stored && stored[key]) return true;
                        if (hasInstructionInExistingConversation()) {
                            await chrome.storage.local.set({ [key]: true });
                            return true;
                        }
                        // An ID-bearing route represents an already-saved chat.
                        // Never inject the instruction into an existing conversation.
                        await chrome.storage.local.set({ [key]: true });
                    } catch (storageErr) {
                        nerixReportError('STORAGE', storageErr, { operation: 'ensureGeminiSystemInstruction conversation key', key });
                    }
                    return true;
                }

                if (safeSessionGet(INSTRUCTION_SESSION_KEY) === 'sent' ||
                    safeSessionGet(INSTRUCTION_SESSION_KEY) === 'pending') return true;

                if (hasInstructionInExistingConversation() || hasAnyConversationMessages()) {
                    // The active route already contains a saved conversation.
                    safeSessionSet(INSTRUCTION_SESSION_KEY, 'sent');
                    return true;
                }

                const composer = await waitForElement(findComposer, 60000, 250);
                if (!composer) return false;
                // Allow saved chat history to hydrate before deciding this is a blank chat.
                await delay(900);
                if (hasInstructionInExistingConversation() || hasAnyConversationMessages()) {
                    safeSessionSet(INSTRUCTION_SESSION_KEY, 'sent');
                    return true;
                }
                const existingText = String(composer.innerText || composer.value || '').trim();
                if (existingText) return false;

                // Set a session guard before sending so iframe reloads cannot duplicate it.
                safeSessionSet(INSTRUCTION_SESSION_KEY, 'pending');
                systemInstructionSendPending = true;
                beginTrackedTurn('system-instruction');
                const sent = await insertAndSend(GEMINI_SYSTEM_INSTRUCTION);
                systemInstructionSendPending = false;
                if (!sent) {
                    safeSessionRemove(INSTRUCTION_SESSION_KEY);
                    trackedTurn = null;
                    return false;
                }

                safeSessionSet(INSTRUCTION_SESSION_KEY, 'sent');
                const turnId = trackedTurn?.id;
                if (turnId) await waitForTrackedTurnCompletion(turnId, 120000);

                // Persist against the generated conversation ID when Gemini assigns one.
                const persistDeadline = Date.now() + 20000;
                let generatedId = getConversationId();
                while (!generatedId && Date.now() < persistDeadline) {
                    await delay(250);
                    generatedId = getConversationId();
                }
                if (generatedId) {
                    try {
                        await chrome.storage.local.set({
                            [getConversationInstructionKey(generatedId)]: true
                        });
                    } catch (storageErr) {
                        nerixReportError('STORAGE', storageErr, { operation: 'ensureGeminiSystemInstruction persist generatedId', generatedId });
                    }
                }
                return true;
            })().finally(() => {
                instructionInitPromise = null;
            });
            return instructionInitPromise;
        }

        function checkConversationRouteChange() {
            const currentId = getConversationId();
            const hasMessages = hasAnyConversationMessages();
            if (currentId === observedConversationId) {
                // Some Gemini builds keep /app as the URL even when starting a new chat.
                if (!currentId && observedConversationHasMessages && !hasMessages) {
                    safeSessionRemove(INSTRUCTION_SESSION_KEY);
                    void ensureGeminiSystemInstruction();
                }
                observedConversationHasMessages = hasMessages;
                return;
            }
            const previousId = observedConversationId;
            observedConversationId = currentId;
            observedConversationHasMessages = hasMessages;

            if (currentId) {
                // Remember that the current ID-bearing chat is already initialized
                // or is an existing saved conversation; do not send into it again.
                return;
            }

            if (previousId) {
                safeSessionRemove(INSTRUCTION_SESSION_KEY);
                void ensureGeminiSystemInstruction();
            }
        }

        function initializeGeminiFrame() {
            if (!document.body) return;
            injectGeminiStyles();
            removeUpsellButtons();
            applyEditorBranding();
            applyTextReplacement();

            // Remove legacy black response UI left by earlier extension versions.
            document.getElementById('nerix-bottom-left-popup')?.remove();
            document.getElementById('nerix-local-jq-answer')?.remove();

            document.addEventListener('click', handleSendIntent, true);
            document.addEventListener('keydown', handleSendIntent, true);
            document.addEventListener('submit', handleSendIntent, true);

            if (responseObserver) responseObserver.disconnect();
            responseObserver = new MutationObserver(() => {
                scheduledCleanup();
                clearTimeout(responseInspectDebounceId);
                responseInspectDebounceId = setTimeout(inspectLatestResponse, 180);
            });
            responseObserver.observe(document.body, {
                childList: true,
                subtree: true,
                characterData: true,
                attributes: true,
                attributeFilter: ['disabled', 'aria-disabled', 'aria-label', 'data-test-id']
            });

            if (responsePollTimer) clearInterval(responsePollTimer);
            responsePollTimer = setInterval(inspectLatestResponse, 500);

            if (routePollTimer) clearInterval(routePollTimer);
            routePollTimer = setInterval(checkConversationRouteChange, 700);

            observedConversationHasMessages = hasAnyConversationMessages();
            // On a blank/new chat, install the conversation instruction once.
            // Existing saved chats are deliberately left untouched.
            void ensureGeminiSystemInstruction();
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initializeGeminiFrame, { once: true });
        } else {
            initializeGeminiFrame();
        }

        window.addEventListener('pagehide', () => {
            if (responseObserver) responseObserver.disconnect();
            if (responsePollTimer) clearInterval(responsePollTimer);
            if (routePollTimer) clearInterval(routePollTimer);
            if (responseInspectDebounceId) clearTimeout(responseInspectDebounceId);
            document.removeEventListener('click', handleSendIntent, true);
            document.removeEventListener('keydown', handleSendIntent, true);
            document.removeEventListener('submit', handleSendIntent, true);
            if (altWActive) {
                altWActive = false;
                try { window.parent.postMessage({ type: 'NERIX_ALT_W_UP' }, '*'); } catch (_) {}
            }
            if (localParsedOverlay?.isConnected) localParsedOverlay.remove();
        });

        window.addEventListener('blur', () => {
            if (altWActive) {
                altWActive = false;
                try { window.parent.postMessage({ type: 'NERIX_ALT_W_UP' }, '*'); } catch (_) {}
            }
        });
    }

    // Run the appropriate context initializer.
    runWebpageContext();
    runGeminiFrameContext();

// ================================================================
// SCREENSHOT SELECTION MODULE (Alt+S region capture)
// ================================================================

(function() {
    'use strict';

    // State
    let screenshotActive = false;
    let screenshotHost = null;
    let shadowRoot = null;
    let overlayEl = null;
    let selectionEl = null;
    let sizeLabel = null;
    let startX = 0, startY = 0;
    let isDragging = false;
    let screenshotDataUrl = null;
    let viewportWidth = 0, viewportHeight = 0;

    // Each crop owns its PNG Blob and request ID from capture through upload.
    // Serial processing prevents fast successive captures from racing the clipboard.
    let screenshotGeneration = 0;
    let activeScreenshotId = 0;
    let screenshotPipeline = Promise.resolve();
    let latestScreenshot = null;

    // ---- CLEANUP ----
    function cleanupScreenshot() {
        screenshotActive = false;
        isDragging = false;
        screenshotDataUrl = null;

        if (overlayEl) {
            overlayEl.removeEventListener('pointerdown', onPointerDown);
            overlayEl.removeEventListener('pointermove', onPointerMove);
            overlayEl.removeEventListener('pointerup', onPointerUp);
            overlayEl.removeEventListener('pointercancel', onPointerCancel);
        }

        document.removeEventListener('keydown', onKeyDown, true);

        if (screenshotHost && screenshotHost.parentNode) {
            screenshotHost.parentNode.removeChild(screenshotHost);
        }
        // WAE resumes only after the screenshot overlay has been fully removed.
        try { window.__nerixWaeResumeAfterShortcut?.('screenshot'); } catch (_) {}
        screenshotHost = null;
        shadowRoot = null;
        overlayEl = null;
        selectionEl = null;
        sizeLabel = null;
    }

    // ---- TOAST NOTIFICATION ----
    function showToast(text, isError) {
        // Show after cleanup so it sits outside the shadow DOM
        const toast = document.createElement('div');
        toast.textContent = text;
        Object.assign(toast.style, {
            position: 'fixed',
            top: '18px',
            right: '18px',
            background: isError ? '#b00020' : '#1a1a1a',
            color: '#fff',
            padding: '10px 18px',
            borderRadius: '8px',
            fontSize: '14px',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            fontWeight: '500',
            zIndex: '2147483647',
            pointerEvents: 'none',
            boxShadow: '0 4px 16px rgba(0,0,0,0.35)',
            opacity: '0',
            transition: 'opacity 0.15s ease-in',
            maxWidth: '320px',
            lineHeight: '1.4'
        });
        document.documentElement.appendChild(toast);
        requestAnimationFrame(() => { toast.style.opacity = '1'; });
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => { if (toast.parentNode) toast.remove(); }, 200);
        }, 1500);
    }

    // ---- BUILD OVERLAY ----
    function buildOverlay() {
        screenshotHost = document.createElement('div');
        screenshotHost.id = 'nerix-screenshot-root';
        document.documentElement.appendChild(screenshotHost);

        shadowRoot = screenshotHost.attachShadow({ mode: 'closed' });

        const style = document.createElement('style');
        style.textContent = `
            :host { all: initial; }
            #overlay {
                position: fixed;
                top: 0; left: 0;
                width: 100vw; height: 100vh;
                z-index: 2147483646;
                cursor: crosshair;
                user-select: none;
                -webkit-user-select: none;
                box-sizing: border-box;
            }
            #dim {
                position: absolute;
                top: 0; left: 0;
                width: 100%; height: 100%;
                background: rgba(0, 0, 0, 0.38);
            }
            #selection {
                position: absolute;
                display: none;
                box-sizing: border-box;
                border: 2px solid #4a9eff;
                box-shadow:
                    0 0 0 1px rgba(0,0,0,0.5),
                    inset 0 0 0 1px rgba(255,255,255,0.15);
            }
            /* The clear "window" inside the selection */
            #selection-inner {
                position: absolute;
                top: 0; left: 0;
                width: 100%; height: 100%;
                background: transparent;
                overflow: hidden;
            }
            #size-label {
                position: absolute;
                bottom: -24px;
                right: 0;
                font: 11px/16px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                color: #fff;
                background: rgba(0,0,0,0.65);
                padding: 1px 5px;
                border-radius: 3px;
                white-space: nowrap;
                pointer-events: none;
            }
        `;
        shadowRoot.appendChild(style);

        overlayEl = document.createElement('div');
        overlayEl.id = 'overlay';

        const dim = document.createElement('div');
        dim.id = 'dim';
        overlayEl.appendChild(dim);

        selectionEl = document.createElement('div');
        selectionEl.id = 'selection';

        const selInner = document.createElement('div');
        selInner.id = 'selection-inner';
        selectionEl.appendChild(selInner);

        sizeLabel = document.createElement('div');
        sizeLabel.id = 'size-label';
        selectionEl.appendChild(sizeLabel);

        overlayEl.appendChild(selectionEl);
        shadowRoot.appendChild(overlayEl);
    }

    // ---- UPDATE SELECTION RECT ----
    function updateSelectionRect(x1, y1, x2, y2) {
        const left   = Math.min(x1, x2);
        const top    = Math.min(y1, y2);
        const width  = Math.abs(x2 - x1);
        const height = Math.abs(y2 - y1);

        selectionEl.style.left   = left + 'px';
        selectionEl.style.top    = top  + 'px';
        selectionEl.style.width  = width + 'px';
        selectionEl.style.height = height + 'px';
        selectionEl.style.display = 'block';

        sizeLabel.textContent = width + ' × ' + height;
    }

    // ---- POINTER EVENTS ----
    function onPointerDown(e) {
        if (e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();

        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;

        overlayEl.setPointerCapture(e.pointerId);
    }

    function onPointerMove(e) {
        if (!isDragging) return;
        e.preventDefault();
        e.stopPropagation();

        const curX = Math.max(0, Math.min(e.clientX, viewportWidth));
        const curY = Math.max(0, Math.min(e.clientY, viewportHeight));

        updateSelectionRect(startX, startY, curX, curY);
    }

    function onPointerUp(e) {
        if (!isDragging) return;
        e.preventDefault();
        e.stopPropagation();

        isDragging = false;

        const curX = Math.max(0, Math.min(e.clientX, viewportWidth));
        const curY = Math.max(0, Math.min(e.clientY, viewportHeight));

        const left   = Math.min(startX, curX);
        const top    = Math.min(startY, curY);
        const width  = Math.abs(curX - startX);
        const height = Math.abs(curY - startY);

        if (width < 3 || height < 3) {
            cleanupScreenshot();
            return;
        }

        const selection = { left, top, width, height };

        // Capture the screenshot FIRST (already taken before overlay appeared)
        // Now crop it
        if (!screenshotDataUrl) {
            cleanupScreenshot();
            showToast('Screenshot data missing', true);
            return;
        }

        const capturedDataUrl = screenshotDataUrl;
        const capturedViewportW = viewportWidth;
        const capturedViewportH = viewportHeight;
        const capturedScreenshotId = activeScreenshotId;

        // Remove overlay before cropping
        cleanupScreenshot();

        cropAndCopy(
            capturedDataUrl,
            selection,
            capturedViewportW,
            capturedViewportH,
            capturedScreenshotId
        );
    }

    function onPointerCancel(e) {
        if (!isDragging) return;
        isDragging = false;
        cleanupScreenshot();
    }

    function onKeyDown(e) {
        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            cleanupScreenshot();
        }
    }

    // ---- CROP + COPY + AUTOMATIC GEMINI ATTACHMENT ----
    function blobToDataUrl(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(
                reader.error || new Error("Screenshot ma'lumotini o'qib bo'lmadi.")
            );
            reader.readAsDataURL(blob);
        });
    }

    async function writeScreenshotToClipboard(blob, dataUrl) {
        // Keep the existing direct clipboard path as the first choice.
        try {
            if (
                navigator.clipboard &&
                typeof navigator.clipboard.write === 'function' &&
                typeof ClipboardItem !== 'undefined'
            ) {
                await navigator.clipboard.write([
                    new ClipboardItem({ 'image/png': blob })
                ]);
                return { ok: true, method: 'page-clipboard' };
            }
        } catch (error) {
            console.warn('UD/AA: Direct screenshot clipboard write failed:', error);
        }

        // Preserve the existing background-injection fallback.
        try {
            const result = await sendBg({
                type: 'NERIX_CLIPBOARD_WRITE_PNG',
                dataUrl: dataUrl
            });
            if (result && result.ok) {
                return { ok: true, method: 'background-clipboard' };
            }
            return result || {
                ok: false,
                error: "Clipboard service javob bermadi."
            };
        } catch (error) {
            return {
                ok: false,
                error: error?.message || String(error)
            };
        }
    }

    async function processScreenshot(blob, screenshotId, requestId) {
        try {
            // If a newer selection began before this crop completed, discard
            // the stale crop before it can overwrite the clipboard or Gemini.
            if (screenshotId !== screenshotGeneration) return;

            if (!blob || blob.size === 0 || blob.type !== 'image/png') {
                showToast("Couldn't copy screenshot", true);
                return;
            }

            // Keep this exact crop Blob; all subsequent stages use this payload.
            const dataUrl = await blobToDataUrl(blob);

            if (
                typeof dataUrl !== 'string' ||
                !dataUrl.startsWith('data:image/png;base64,')
            ) {
                showToast("Couldn't read screenshot", true);
                return;
            }

            if (latestScreenshot?.requestId === requestId) {
                latestScreenshot.dataUrl = dataUrl;
            }

            const clipboardResult = await writeScreenshotToClipboard(blob, dataUrl);
            if (!clipboardResult || !clipboardResult.ok) {
                showToast("Couldn't copy screenshot", true);
                return;
            }

            // This notification is only shown after image/png reached clipboard.
            showToast('✓ Screenshot copied');

            // Let the existing toast finish its 150 ms fade-in before opening Gemini.
            await delay(180);

            const openResult = typeof window.__nerixEnsureGeminiPopupOpen === 'function'
                ? await window.__nerixEnsureGeminiPopupOpen()
                : {
                    ok: false,
                    error: "Gemini popup boshqaruv funksiyasi topilmadi."
                };

            if (!openResult || !openResult.ok) {
                showToast(
                    "Gemini iframe ochilmadi: " +
                    (openResult?.error || "noma'lum xato"),
                    true
                );
                return;
            }

            // The background waits for the registered Gemini frame, then the
            // frame waits for the actual editor before attaching this exact PNG.
            const uploadResult = await sendBg({
                type: 'NERIX_UPLOAD_TO_IFRAME',
                dataUrl: dataUrl,
                requestId: requestId,
                prompt: SCREENSHOT_GEMINI_PROMPT
            });

            if (
                uploadResult &&
                uploadResult.ok === true &&
                uploadResult.attached === true &&
                uploadResult.promptAdded === true
            ) {
                showToast("✓ Screenshot + savol prompti Gemini inputiga qo\'shildi");
            } else if (uploadResult?.attached === true) {
                showToast(uploadResult.promptError || "Screenshot biriktirildi, ammo prompt matni qo\'shilmadi.", true);
            } else {
                showToast(
                    "Gemini'ga rasm biriktirilmadi: " +
                    (uploadResult?.error || "preview tasdiqlanmadi"),
                    true
                );
            }
        } catch (error) {
            console.error('UD/AA: Screenshot → Gemini pipeline failed:', error);
            showToast(
                "Screenshot/Gemini xatosi: " +
                (error?.message || String(error)),
                true
            );
        }
    }

    function queueScreenshotProcessing(blob, screenshotId, requestId) {
        const task = screenshotPipeline.then(
            () => processScreenshot(blob, screenshotId, requestId)
        );

        // Keep the queue alive even if a capture fails.
        screenshotPipeline = task.catch(error => {
            console.error('UD/AA: Screenshot queue error:', error);
        });

        return task;
    }

    function cropAndCopy(dataUrl, selection, vpW, vpH, screenshotId) {
        const img = new Image();

        img.onload = function() {
            const screenshotW = img.naturalWidth;
            const screenshotH = img.naturalHeight;

            // Scale factors: screenshot pixels per CSS pixel.
            const scaleX = screenshotW / vpW;
            const scaleY = screenshotH / vpH;

            const srcX = Math.round(selection.left * scaleX);
            const srcY = Math.round(selection.top * scaleY);
            const srcW = Math.round(selection.width * scaleX);
            const srcH = Math.round(selection.height * scaleY);

            // Clamp to screenshot bounds.
            const clampedX = Math.max(0, Math.min(srcX, screenshotW - 1));
            const clampedY = Math.max(0, Math.min(srcY, screenshotH - 1));
            const clampedW = Math.max(1, Math.min(srcW, screenshotW - clampedX));
            const clampedH = Math.max(1, Math.min(srcH, screenshotH - clampedY));

            const canvas = document.createElement('canvas');
            canvas.width = clampedW;
            canvas.height = clampedH;

            const ctx = canvas.getContext('2d');
            if (!ctx) {
                showToast('Crop failed', true);
                return;
            }

            ctx.drawImage(
                img,
                clampedX, clampedY, clampedW, clampedH,
                0, 0, clampedW, clampedH
            );

            canvas.toBlob(function(blob) {
                if (!blob) {
                    showToast('Crop failed', true);
                    return;
                }

                // Store this exact Blob immediately; later jobs never read an older clipboard image.
                const requestId = 'screenshot-' + screenshotId + '-' + Date.now();
                latestScreenshot = {
                    requestId: requestId,
                    blob: blob,
                    dataUrl: null
                };
                void queueScreenshotProcessing(blob, screenshotId, requestId);
            }, 'image/png');
        };

        img.onerror = function() {
            showToast("Couldn't copy screenshot", true);
        };

        img.src = dataUrl;
    }

    // ---- MAIN ENTRY: start screenshot selection ----
    window.__nerixStartScreenshot = function(dataUrl, vpW, vpH) {
        if (screenshotActive) return;
        if (!dataUrl || !dataUrl.startsWith('data:image/png;base64,')) return;

        screenshotActive = true;
        activeScreenshotId = ++screenshotGeneration;
        // Also suspend when screenshot is launched by a background command/message.
        try { window.__nerixWaeSuspendForShortcut?.('screenshot'); } catch (_) {}
        screenshotDataUrl = dataUrl;
        viewportWidth  = vpW  || window.innerWidth;
        viewportHeight = vpH  || window.innerHeight;

        buildOverlay();

        overlayEl.addEventListener('pointerdown',  onPointerDown,  { passive: false });
        overlayEl.addEventListener('pointermove',  onPointerMove,  { passive: false });
        overlayEl.addEventListener('pointerup',    onPointerUp,    { passive: false });
        overlayEl.addEventListener('pointercancel', onPointerCancel, { passive: false });
        document.addEventListener('keydown', onKeyDown, true);
    };

})(); 

})();