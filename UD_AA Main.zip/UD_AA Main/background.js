﻿// ========== UD/AA && tools — background.js v2.3 ==========
// Manifest V3 Service Worker
//
// Functions:
// 1. Supabase REST API
// 2. Screenshot capture coordination
// 3. PNG clipboard write through chrome.scripting.executeScript()
// 4. Gemini iframe registration and message routing
// 5. Chrome Commands
//
// Clipboard method:
// captureVisibleTab -> crop in content.js ->
// executeScript -> navigator.clipboard.write()
//
// No Offscreen API is used for clipboard writing.

'use strict';

// ================================================================
// 1. SUPABASE CONFIGURATION
// ================================================================

const SUPABASE_URL = "https://pvygfyuajshkxlijiisa.supabase.co";
const SUPABASE_REST_URL = SUPABASE_URL + "/rest/v1/chat_messages";
const SUPABASE_BROADCAST_URL = SUPABASE_URL + "/rest/v1/broadcast_messages";

// Faqat publishable key kiriting.
// sb_secret_ yoki service_role key ishlatmang.
const SUPABASE_PUBLISHABLE_KEY =
    "sb_publishable_8wn0xKfABQZ-Pa_UTIk_5A_1q_bUADk";

const SUPABASE_FETCH_TIMEOUT_MS = 8000;

function supabaseConfigured() {
    return (
        typeof SUPABASE_PUBLISHABLE_KEY === "string" &&
        SUPABASE_PUBLISHABLE_KEY.trim().length > 0 &&
        SUPABASE_PUBLISHABLE_KEY.startsWith("sb_publishable_") &&
        !SUPABASE_PUBLISHABLE_KEY.includes("BU_YERGA")
    );
}

// ================================================================
// 2. GENERAL HELPERS
// ================================================================

function isValidTabId(tabId) {
    return Number.isInteger(tabId) && tabId >= 0;
}

function isPngDataUrl(dataUrl) {
    return (
        typeof dataUrl === "string" &&
        dataUrl.startsWith("data:image/png;base64,")
    );
}

function safeSendResponse(sendResponse, response) {
    try {
        sendResponse(response);
    } catch (error) {
        console.warn(
            "UD/AA: Javob yuborilmadi:",
            error
        );
    }
}

function fetchWithTimeout(url, init = {}, timeoutMs = 8000) {
    const controller = new AbortController();

    const timeoutId = setTimeout(() => {
        controller.abort();
    }, timeoutMs);

    return fetch(url, {
        ...init,
        signal: controller.signal
    }).finally(() => {
        clearTimeout(timeoutId);
    });
}

// ================================================================
// 3. SUPABASE REST REQUEST
// ================================================================

async function supabaseRequest(path = "", init = {}) {
    if (!supabaseConfigured()) {
        return {
            ok: false,
            error:
                "Supabase publishable key sozlanmagan. " +
                "background.js ichidagi SUPABASE_PUBLISHABLE_KEY ni to'ldiring."
        };
    }

    const safePath =
        typeof path === "string" ? path : "";

    const url = safePath.startsWith("http")
        ? safePath
        : SUPABASE_REST_URL + safePath;

    const headers = {
        "apikey": SUPABASE_PUBLISHABLE_KEY,
        "Content-Type": "application/json",
        ...(init.headers || {})
    };

    try {
        const response = await fetchWithTimeout(
            url,
            {
                ...init,
                headers
            },
            SUPABASE_FETCH_TIMEOUT_MS
        );

        if (!response.ok) {
            let bodyText = "";

            try {
                bodyText = await response.text();
            } catch (_) {
                // Ignore response-body parsing errors.
            }

            return {
                ok: false,
                error:
                    `Supabase xatosi (${response.status}): ` +
                    (bodyText || response.statusText)
            };
        }

        if (response.status === 204) {
            return {
                ok: true,
                data: null
            };
        }

        const responseText = await response.text();

        let data = null;

        if (responseText) {
            try {
                data = JSON.parse(responseText);
            } catch (_) {
                return {
                    ok: false,
                    error: "Supabase noto'g'ri JSON javob qaytardi."
                };
            }
        }

        return {
            ok: true,
            data
        };

    } catch (error) {
        const isTimeout =
            error && error.name === "AbortError";

        return {
            ok: false,
            error: isTimeout
                ? "Supabase so'rovi vaqti tugadi."
                : (error.message || String(error))
        };
    }
}

// ================================================================
// 4. SUPABASE — GET MESSAGES
// ================================================================

async function supabaseGetMessages(limit) {
    const requestedLimit = Number(limit);

    const safeLimit = Number.isFinite(requestedLimit)
        ? Math.min(100, Math.max(1, Math.floor(requestedLimit)))
        : 20;

    const path =
        `?select=id,user,text,created_at` +
        `&order=created_at.desc` +
        `&limit=${safeLimit}`;

    const result = await supabaseRequest(path, {
        method: "GET"
    });

    if (!result.ok) {
        return result;
    }

    const rows = Array.isArray(result.data)
        ? result.data
        : [];

    const messages = rows.map(row => ({
        id: row.id,
        user: row.user,
        text: row.text,
        createdAt: row.created_at
    })).reverse();

    return {
        ok: true,
        messages
    };
}

// ================================================================
// 5. SUPABASE — INSERT MESSAGE
// ================================================================

async function supabaseInsertMessage(sender, text) {
    if (sender !== "UMAROV" && sender !== "DILSHOD") {
        return {
            ok: false,
            error: "Noto'g'ri foydalanuvchi."
        };
    }

    if (typeof text !== "string" || !text.trim()) {
        return {
            ok: false,
            error: "Bo'sh xabar yuborib bo'lmaydi."
        };
    }

    const result = await supabaseRequest("", {
        method: "POST",

        headers: {
            "Prefer": "return=representation"
        },

        body: JSON.stringify({
            user: sender,
            text: text.trim()
        })
    });

    if (!result.ok) {
        return result;
    }

    const row = Array.isArray(result.data)
        ? result.data[0]
        : result.data;

    if (!row) {
        return {
            ok: false,
            error: "Supabase bo'sh javob qaytardi."
        };
    }

    return {
        ok: true,

        message: {
            id: row.id,
            user: row.user,
            text: row.text,
            createdAt: row.created_at
        }
    };
}

// ================================================================
// 5a. SUPABASE — DELETE ALL MESSAGES (via secure RPC function)
// ================================================================

async function supabaseDeleteAllMessages() {
    // Calls a PostgreSQL RPC function (delete_chat_messages) via PostgREST.
    // The RPC function is defined as SECURITY DEFINER and performs its own
    // authorization checks (only UMAROV and DILSHOD users' rows are deleted).
    // This avoids the need for the anon role to have direct DELETE privilege
    // on the chat_messages table.
    const rpcUrl = SUPABASE_URL + "/rest/v1/rpc/delete_chat_messages";

    try {
        const response = await fetchWithTimeout(
            rpcUrl,
            {
                method: "POST",
                headers: {
                    "apikey": SUPABASE_PUBLISHABLE_KEY,
                    "Authorization": "Bearer " + SUPABASE_PUBLISHABLE_KEY,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({})
            },
            SUPABASE_FETCH_TIMEOUT_MS
        );

        if (!response.ok) {
            let bodyText = "";
            try { bodyText = await response.text(); } catch (_) {}
            return {
                ok: false,
                error: "Xabarlarni o'chirish xatosi (" + response.status + "): " +
                    (bodyText || response.statusText)
            };
        }

        return { ok: true };

    } catch (error) {
        const isTimeout = error && error.name === "AbortError";
        return {
            ok: false,
            error: isTimeout
                ? "So'rov vaqti tugadi."
                : (error.message || String(error))
        };
    }
}

// ================================================================
// 5b. SUPABASE BROADCAST
// ================================================================

// Only UMAROV is allowed to send broadcasts. Enforced client-side
// here and by RLS in Supabase (see SQL editor setup below).
async function supabaseSendBroadcast(text) {
    if (typeof text !== "string" || !text.trim()) {
        return { ok: false, error: "Bo'sh xabar yuborib bo'lmaydi." };
    }
    const trimmed = text.trim().slice(0, 500);
    const result = await fetchWithTimeout(
        SUPABASE_BROADCAST_URL,
        {
            method: "POST",
            headers: {
                "apikey": SUPABASE_PUBLISHABLE_KEY,
                "Authorization": "Bearer " + SUPABASE_PUBLISHABLE_KEY,
                "Content-Type": "application/json",
                "Prefer": "return=representation"
            },
            body: JSON.stringify({ sender: "UMAROV", message: trimmed })
        },
        SUPABASE_FETCH_TIMEOUT_MS
    );
    if (!result.ok) {
        let bodyText = "";
        try { bodyText = await result.text(); } catch (_) {}
        return { ok: false, error: `Broadcast xatosi (${result.status}): ` + (bodyText || result.statusText) };
    }
    const row = await result.json().catch(() => null);
    const entry = Array.isArray(row) ? row[0] : row;
    return { ok: true, broadcast: entry || null };
}

async function supabaseGetNewBroadcasts(afterId) {
    // Returns broadcasts newer than afterId (or last 1 if afterId is null)
    const filter = afterId
        ? `?select=id,sender,message,created_at&id=gt.${afterId}&order=created_at.asc&limit=10`
        : `?select=id,sender,message,created_at&order=created_at.desc&limit=1`;
    try {
        const resp = await fetchWithTimeout(
            SUPABASE_BROADCAST_URL + filter,
            {
                method: "GET",
                headers: {
                    "apikey": SUPABASE_PUBLISHABLE_KEY,
                    "Authorization": "Bearer " + SUPABASE_PUBLISHABLE_KEY
                }
            },
            SUPABASE_FETCH_TIMEOUT_MS
        );
        if (!resp.ok) return { ok: false, error: "Broadcast fetch failed" };
        const rows = await resp.json().catch(() => []);
        return { ok: true, rows: Array.isArray(rows) ? rows : [] };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ================================================================
// 5c. SUPABASE — LOGIN VERIFY via Edge Function
// ================================================================

// Edge Function endpoint'i (loyiha ref ni almashtiring agar boshqa bo'lsa)
const SUPABASE_LOGIN_FUNCTION_URL = SUPABASE_URL + "/functions/v1/account-login";

async function supabaseLoginVerify(password) {
    try {
        const response = await fetchWithTimeout(
            SUPABASE_LOGIN_FUNCTION_URL,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + SUPABASE_PUBLISHABLE_KEY
                },
                body: JSON.stringify({ password })
            },
            SUPABASE_FETCH_TIMEOUT_MS
        );

        if (!response.ok) {
            return { ok: false, success: false, error: "NETWORK_ERROR" };
        }

        let data;
        try {
            data = await response.json();
        } catch (_) {
            return { ok: false, success: false, error: "NETWORK_ERROR" };
        }

        if (data && data.success === true && data.account) {
            return { ok: true, success: true, account: data.account };
        }

        return {
            ok: true,
            success: false,
            error: data?.error || "INVALID_PASSWORD"
        };

    } catch (error) {
        const isTimeout = error && error.name === "AbortError";
        return {
            ok: false,
            success: false,
            error: isTimeout ? "NETWORK_ERROR" : "NETWORK_ERROR"
        };
    }
}

// ================================================================
// 6. GEMINI IFRAME REGISTRY
// ================================================================

const REGISTRY_KEY = "nerixGeminiFrameRegistry";

// Registry format:
// {
//     "tabId": {
//         frameId: 123,
//         url: "...",
//         ts: 123456789
//     }
// }

async function getRegistry() {
    try {
        const result = await chrome.storage.session.get(
            REGISTRY_KEY
        );

        return (
            result &&
            result[REGISTRY_KEY] &&
            typeof result[REGISTRY_KEY] === "object"
        )
            ? result[REGISTRY_KEY]
            : {};

    } catch (error) {
        console.warn(
            "UD/AA: Registry o'qilmadi:",
            error
        );

        return {};
    }
}

async function setRegistryEntry(tabId, entry) {
    if (!isValidTabId(tabId)) {
        return false;
    }

    try {
        const registry = await getRegistry();

        registry[String(tabId)] = entry;

        await chrome.storage.session.set({
            [REGISTRY_KEY]: registry
        });

        return true;

    } catch (error) {
        console.error(
            "UD/AA: Registry saqlanmadi:",
            error
        );

        return false;
    }
}

async function removeRegistryEntry(tabId) {
    if (!isValidTabId(tabId)) {
        return;
    }

    try {
        const registry = await getRegistry();
        const key = String(tabId);

        if (registry[key]) {
            delete registry[key];

            await chrome.storage.session.set({
                [REGISTRY_KEY]: registry
            });
        }

    } catch (error) {
        console.warn(
            "UD/AA: Registry tozalanmadi:",
            error
        );
    }
}

function isGeminiUrl(url) {
    try {
        return new URL(url).origin ===
            "https://gemini.google.com";
    } catch (_) {
        return false;
    }
}

// Tab yopilganda Gemini frame ma'lumotini tozalash.
chrome.tabs.onRemoved.addListener((tabId) => {
    removeRegistryEntry(tabId);
});

// ================================================================
// 6b. BROADCAST POLLING - delivers new broadcasts to all tabs
// ================================================================

// ================================================================
// 6c. ACCOUNT AUTHENTICATION STORAGE
// ================================================================

// SESSION-BASED LOGIN (Chrome to'liq yopilganda avtomatik tozalanadi).
//
// chrome.storage.session ishlatiladi:
//   - Chrome to'liq yopilganda (X) → sessiya tugaydi → avtomatik logout ✅
//   - F5 / Ctrl+R refresh → sessiya saqlanadi → login yo'qolmaydi ✅
//   - Tab yopib yangisini ochish → sessiya saqlanadi → login saqlanadi ✅
//   - Service worker qayta ishga tushsa → sessiya saqlanadi ✅
//   - chrome.storage.local ishlatilmaydi → doimiy xotirada saqlanmaydi ✅
//
// Stores: { authenticated: true, activeAccount: "Dilshod" | "Umarov" }
// or: {} / null when no account is saved.

const AUTH_STORAGE_KEY = "udaa_auth_account";

async function getAuthAccount() {
    try {
        const result = await chrome.storage.session.get(AUTH_STORAGE_KEY);
        const data = result && result[AUTH_STORAGE_KEY];
        if (
            data &&
            typeof data === "object" &&
            data.authenticated === true &&
            (data.activeAccount === "Dilshod" || data.activeAccount === "Umarov")
        ) {
            return { ok: true, authenticated: true, activeAccount: data.activeAccount };
        }
        return { ok: true, authenticated: false, activeAccount: null };
    } catch (error) {
        return { ok: false, error: error.message || String(error), authenticated: false, activeAccount: null };
    }
}

async function setAuthAccount(activeAccount) {
    if (activeAccount !== "Dilshod" && activeAccount !== "Umarov") {
        return { ok: false, error: "Noto'g'ri account nomi." };
    }
    try {
        await chrome.storage.session.set({
            [AUTH_STORAGE_KEY]: { authenticated: true, activeAccount }
        });
        return { ok: true };
    } catch (error) {
        return { ok: false, error: error.message || String(error) };
    }
}

// ================================================================
// 6d. MIGRATION: eski chrome.storage.local login ma'lumotlarini tozalash
// ================================================================
// Oldingi versiyada login holati chrome.storage.local ga saqlanardi.
// Endi chrome.storage.session ishlatiladi. Birinchi ishga tushganda
// eski local storage dan login ma'lumotini tozalab qo'yamiz —
// shunday qilib eski login avtomatik qayta kirish bo'lib qolmaydi.
(async () => {
    try {
        await chrome.storage.local.remove(AUTH_STORAGE_KEY);
    } catch (_) {
        // Migration xatosi — keyingi sessiyada qayta uriniladi.
    }
})();

let lastSeenBroadcastId = null;
let broadcastPollTimer = null;
const BROADCAST_POLL_MS = 4000;
const BROADCAST_LAST_ID_KEY = "udaa_broadcast_last_id";

// Persist lastSeenBroadcastId to session storage so that a Service Worker
// restart (which zeroes all in-memory state) does not cause old broadcasts
// to be re-shown or new ones to be missed.
async function saveBroadcastLastId(id) {
    try {
        await chrome.storage.session.set({ [BROADCAST_LAST_ID_KEY]: String(id) });
    } catch (_) { /* non-critical — in-memory value remains correct */ }
}

async function loadBroadcastLastId() {
    try {
        const result = await chrome.storage.session.get(BROADCAST_LAST_ID_KEY);
        const stored = result && result[BROADCAST_LAST_ID_KEY];
        if (typeof stored === "string" && stored.length > 0) {
            lastSeenBroadcastId = stored;
        }
    } catch (_) { /* fall through — will seed from network on first poll */ }
}

async function broadcastToAllTabs(broadcast, durationMs) {
    if (!broadcast || !broadcast.id) return;
    const msg = {
        type: "NERIX_BROADCAST_SHOW",
        id: String(broadcast.id),
        sender: String(broadcast.sender || "UMAROV"),
        message: String(broadcast.message || "").slice(0, 500),
        durationMs: (typeof durationMs === "number" && durationMs > 0) ? durationMs : undefined
    };
    try {
        const tabs = await new Promise((resolve) =>
            chrome.tabs.query({}, resolve)
        );
        for (const tab of (tabs || [])) {
            if (!isValidTabId(tab.id)) continue;
            chrome.tabs.sendMessage(tab.id, msg, { frameId: 0 }, () => {
                void chrome.runtime.lastError;
            });
        }
    } catch (_) {}
}

// Compare two broadcast IDs: a > b?
// Uses BigInt for pure-integer strings (handles PostgreSQL BIGINT safely,
// which can exceed Number.MAX_SAFE_INTEGER = 9007199254740991).
// Falls back to lexicographic comparison for UUID / non-numeric formats.
// Returns false for any null / undefined / empty input.
function broadcastIdGt(a, b) {
    if (a == null || b == null || a === "" || b === "") return false;
    const sa = String(a);
    const sb = String(b);
    // Only use BigInt when both values are pure decimal integer strings
    // (no decimal point, no sign, no whitespace).
    if (/^\d+$/.test(sa) && /^\d+$/.test(sb)) {
        try { return BigInt(sa) > BigInt(sb); } catch (_) { /* fall through */ }
    }
    return sa > sb;
}

async function pollBroadcasts() {
    const result = await supabaseGetNewBroadcasts(lastSeenBroadcastId);
    if (!result.ok || !result.rows.length) return;
    for (const row of result.rows) {
        if (!row || !row.id) continue;
        const idStr = String(row.id);
        // First poll after startup (or after SW restart): seed the cursor
        // so we know where "now" is without showing historical messages.
        if (lastSeenBroadcastId === null) {
            lastSeenBroadcastId = idStr;
            void saveBroadcastLastId(idStr);
            continue;
        }
        // Skip rows that are not strictly newer (numeric-safe BigInt comparison).
        if (!broadcastIdGt(idStr, lastSeenBroadcastId)) continue;
        lastSeenBroadcastId = idStr;
        void saveBroadcastLastId(idStr);
        await broadcastToAllTabs(row);
    }
}

// Start broadcast polling. Load the persisted cursor first so that a
// Service Worker restart does not re-show already-seen broadcasts.
if (broadcastPollTimer) clearInterval(broadcastPollTimer);
loadBroadcastLastId().then(() => {
    broadcastPollTimer = setInterval(pollBroadcasts, BROADCAST_POLL_MS);
    void pollBroadcasts();
});

// ================================================================
// 7. SCREENSHOT PNG → REAL WINDOWS CLIPBOARD
// ================================================================

// MUHIM:
// Chrome service worker ichida DOM yo'q.
// Shuning uchun screenshot PNG faol tabning asosiy frame'iga
// chrome.scripting.executeScript() orqali yuboriladi.
//
// Bu funksiya mustaqil bo'lishi kerak.
// Tashqi background.js o'zgaruvchilariga murojaat qilmaydi.

async function copyImageToClipboard(dataUrl) {
    try {
        // 1. PNG ma'lumotini tekshirish.
        if (
            typeof dataUrl !== "string" ||
            !dataUrl.startsWith("data:image/png;base64,")
        ) {
            throw new Error(
                "Screenshot PNG ma'lumoti noto'g'ri."
            );
        }

        // 2. Clipboard API mavjudligini tekshirish.
        if (
            !navigator.clipboard ||
            typeof navigator.clipboard.write !== "function"
        ) {
            throw new Error(
                "Clipboard API mavjud emas."
            );
        }

        if (typeof ClipboardItem === "undefined") {
            throw new Error(
                "ClipboardItem brauzer tomonidan qo'llab-quvvatlanmaydi."
            );
        }

        // 3. DataURL -> Blob.
        const response = await fetch(dataUrl);

        if (!response.ok) {
            throw new Error(
                "Screenshot ma'lumotini o'qib bo'lmadi."
            );
        }

        const blob = await response.blob();

        if (!blob || blob.size === 0) {
            throw new Error(
                "Screenshot rasmi bo'sh."
            );
        }

        if (blob.type !== "image/png") {
            throw new Error(
                "Rasm image/png formatida emas."
            );
        }

        // 4. Haqiqiy PNG'ni Windows clipboard'ga yozish.
        const clipboardItem = new ClipboardItem({
            "image/png": blob
        });

        await navigator.clipboard.write([
            clipboardItem
        ]);

        // 5. Screenshot flash effekti.
        // Bu effekt rasm clipboard'ga yozilgandan keyin ko'rsatiladi.
        try {
            const flash = document.createElement("div");

            flash.id = "nerix-screenshot-flash";

            Object.assign(flash.style, {
                position: "fixed",
                top: "0",
                left: "0",
                width: "100vw",
                height: "100vh",
                backgroundColor: "#ffffff",
                opacity: "0.55",
                zIndex: "2147483647",
                pointerEvents: "none",
                transition: "opacity 0.25s ease-out"
            });

            const root =
                document.body || document.documentElement;

            root.appendChild(flash);

            setTimeout(() => {
                flash.style.opacity = "0";

                setTimeout(() => {
                    if (flash.parentNode) {
                        flash.remove();
                    }
                }, 260);

            }, 50);

        } catch (flashError) {
            // Flash effekti ishlamasa ham clipboard yozuvi saqlanadi.
        }

        return {
            ok: true,
            sizeBytes: blob.size,
            mimeType: blob.type,
            message: "Screenshot clipboard'ga nusxalandi."
        };

    } catch (error) {
        return {
            ok: false,
            error: error && error.message
                ? error.message
                : String(error)
        };
    }
}

// ================================================================
// 8. EXECUTE SCRIPT — COPY PNG
// ================================================================

async function writePngToClipboard(tabId, dataUrl) {
    if (!isValidTabId(tabId)) {
        return {
            ok: false,
            error: "Faol tab aniqlanmadi."
        };
    }

    if (!isPngDataUrl(dataUrl)) {
        return {
            ok: false,
            error: "Noto'g'ri PNG rasm ma'lumoti."
        };
    }

    try {
        if (
            !chrome.scripting ||
            typeof chrome.scripting.executeScript !== "function"
        ) {
            throw new Error(
                "Chrome Scripting API mavjud emas. Manifestni tekshiring."
            );
        }

        // Screenshot clipboard funksiyasini faol sahifaga yuborish.
        const results = await chrome.scripting.executeScript({
            target: {
                tabId: tabId,
                frameIds: [0]
            },

            world: "ISOLATED",

            func: copyImageToClipboard,

            args: [dataUrl]
        });

        const result =
            results &&
                results.length > 0 &&
                results[0]
                ? results[0].result
                : null;

        if (!result) {
            return {
                ok: false,
                error:
                    "Sahifaga clipboard funksiyasi yuborildi, " +
                    "ammo javob olinmadi."
            };
        }

        if (!result.ok) {
            return result;
        }

        return result;

    } catch (error) {
        console.error(
            "UD/AA: Clipboard injection xatosi:",
            error
        );

        return {
            ok: false,
            error:
                "Clipboard injection xatosi: " +
                (error.message || String(error))
        };
    }
}

// ================================================================
// 9. SHORTCUT RELAY DEDUPLICATION
// ================================================================

const lastRelayByTab = Object.create(null);

const RELAY_DEDUPE_MS = 350;

function shouldRelay(tabId) {
    const now = Date.now();

    const last = lastRelayByTab[tabId] || 0;

    if (now - last < RELAY_DEDUPE_MS) {
        return false;
    }

    lastRelayByTab[tabId] = now;

    return true;
}

// ================================================================
// 10. SCREENSHOT CAPTURE
// ================================================================

function captureActiveTab(tabId, windowId, sendResponse) {
    if (!isValidTabId(tabId)) {
        safeSendResponse(sendResponse, {
            dataUrl: null,
            error: "Tab ID aniqlanmadi."
        });

        return;
    }

    if (!Number.isInteger(windowId) || windowId < 0) {
        safeSendResponse(sendResponse, {
            dataUrl: null,
            error: "Window ID aniqlanmadi."
        });

        return;
    }

    chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
            safeSendResponse(sendResponse, {
                dataUrl: null,
                error:
                    "Faol tabni aniqlab bo'lmadi: " +
                    (
                        chrome.runtime.lastError
                            ? chrome.runtime.lastError.message
                            : "Tab mavjud emas."
                    )
            });

            return;
        }

        if (!tab.active || tab.windowId !== windowId) {
            safeSendResponse(sendResponse, {
                dataUrl: null,
                error:
                    "Screenshot olinmadi: kerakli sahifa " +
                    "faol tab emas."
            });

            return;
        }

        chrome.tabs.captureVisibleTab(
            windowId,

            {
                format: "png"
            },

            (dataUrl) => {
                if (chrome.runtime.lastError) {
                    safeSendResponse(sendResponse, {
                        dataUrl: null,
                        error:
                            "Screenshot olish xatosi: " +
                            chrome.runtime.lastError.message
                    });

                    return;
                }

                if (!isPngDataUrl(dataUrl)) {
                    safeSendResponse(sendResponse, {
                        dataUrl: null,
                        error:
                            "Screenshot PNG ma'lumoti olinmadi."
                    });

                    return;
                }

                safeSendResponse(sendResponse, {
                    dataUrl: dataUrl,
                    error: null
                });
            }
        );
    });
}

// ================================================================
// 11. SEND SCREENSHOT TO GEMINI IFRAME
// ================================================================

async function waitForGeminiFrameRegistration(tabId, timeoutMs = 25000) {
    const deadline = Date.now() + timeoutMs;

    while (Date.now() < deadline) {
        const registry = await getRegistry();
        const entry = registry[String(tabId)];

        if (
            entry &&
            Number.isInteger(entry.frameId) &&
            entry.frameId > 0 &&
            isGeminiUrl(entry.url)
        ) {
            return entry;
        }

        // Gemini content script registers the frame after the iframe document loads.
        await new Promise(resolve => setTimeout(resolve, 200));
    }

    return null;
}

async function uploadScreenshotToGemini(tabId, dataUrl, requestId, prompt) {
    if (!isValidTabId(tabId)) {
        return {
            ok: false,
            error: "Tab ID aniqlanmadi."
        };
    }

    if (!isPngDataUrl(dataUrl)) {
        return {
            ok: false,
            error: "Gemini'ga yuboriladigan PNG noto'g'ri."
        };
    }

    // The iframe can still be loading when Alt+S is used.
    const entry = await waitForGeminiFrameRegistration(tabId);

    if (!entry) {
        return {
            ok: false,
            error:
                "Gemini iframe 25 soniya ichida tayyor bo'lmadi. " +
                "Iframe ochiqligini va Gemini yuklanganini tekshiring."
        };
    }

    return new Promise((resolve) => {
        chrome.tabs.sendMessage(
            tabId,
            {
                type: "NERIX_UPLOAD_SCREENSHOT_IFRAME",
                dataUrl: dataUrl,
                requestId: String(requestId || ("screenshot-" + Date.now())),
                prompt: typeof prompt === "string" ? prompt : ""
            },
            {
                frameId: entry.frameId
            },
            (response) => {
                if (chrome.runtime.lastError) {
                    removeRegistryEntry(tabId);
                    resolve({
                        ok: false,
                        error:
                            "Gemini iframe bilan aloqa uzildi: " +
                            chrome.runtime.lastError.message
                    });
                    return;
                }

                if (!response || response.ok !== true || response.attached !== true) {
                    resolve(response || {
                        ok: false,
                        error: "Gemini iframe javob bermadi."
                    });
                    return;
                }

                resolve(response);
            }
        );
    });
}

// ================================================================
// 12. CENTRAL MESSAGE ROUTER
// ================================================================

chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {

        if (
            !message ||
            typeof message.type !== "string"
        ) {
            return false;
        }

        // ================================================================
        // GLOBAL LOGIN GUARD — background message router
        //
        // Auth-infrastructure messages are ALWAYS allowed (no guard):
        //   NERIX_LOGIN_VERIFY, NERIX_GET_AUTH_ACCOUNT, NERIX_SET_AUTH_ACCOUNT,
        //   NERIX_GEMINI_FRAME_REGISTER, NERIX_CHECK_IFRAME_READY,
        //   NERIX_LOGIN_REQUIRED_NOTIFY (passthrough only)
        //
        // All other feature messages require a valid authenticated account.
        // ================================================================
        const AUTH_EXEMPT_MESSAGES = new Set([
            "NERIX_LOGIN_VERIFY",
            "NERIX_GET_AUTH_ACCOUNT",
            "NERIX_SET_AUTH_ACCOUNT",
            "NERIX_GEMINI_FRAME_REGISTER",
            "NERIX_CHECK_IFRAME_READY",
            "NERIX_LOGIN_REQUIRED_NOTIFY",
            "NERIX_SELF_UNINSTALL",
        ]);

        if (!AUTH_EXEMPT_MESSAGES.has(message.type)) {
            // Check authentication before dispatching.
            getAuthAccount().then((auth) => {
                if (!auth || !auth.authenticated || !auth.activeAccount) {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: "NOT_AUTHENTICATED"
                    });
                } else {
                    // Authenticated: re-dispatch to the actual handler.
                    _dispatchAuthenticatedMessage(message, sender, sendResponse);
                }
            }).catch(() => {
                safeSendResponse(sendResponse, { ok: false, error: "AUTH_CHECK_FAILED" });
            });
            return true; // async
        }

        // Auth-exempt messages handled below.
        switch (message.type) {

            // ----------------------------------------------------
            // GEMINI FRAME REGISTRATION
            // ----------------------------------------------------

            case "NERIX_GEMINI_FRAME_REGISTER": {
                const tabId =
                    sender.tab && sender.tab.id;

                const frameId = sender.frameId;

                const frameUrl = sender.url || "";

                if (
                    !isValidTabId(tabId) ||
                    !Number.isInteger(frameId) ||
                    frameId === 0 ||
                    !isGeminiUrl(frameUrl)
                ) {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error:
                            "Gemini iframe ma'lumoti noto'g'ri."
                    });

                    return false;
                }

                setRegistryEntry(tabId, {
                    frameId: frameId,
                    url: frameUrl,
                    ts: Date.now()
                }).then((saved) => {
                    safeSendResponse(sendResponse, {
                        ok: saved
                    });
                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message
                    });
                });

                return true;
            }

            // ----------------------------------------------------
            // CHECK GEMINI FRAME READINESS
            // ----------------------------------------------------

            case "NERIX_CHECK_IFRAME_READY": {
                const tabId =
                    sender.tab && sender.tab.id;

                if (!isValidTabId(tabId)) {
                    safeSendResponse(sendResponse, {
                        ready: false
                    });

                    return false;
                }

                getRegistry().then((registry) => {
                    const entry = registry[String(tabId)];

                    safeSendResponse(sendResponse, {
                        ready: !!(
                            entry &&
                            Number.isInteger(entry.frameId)
                        ),

                        frameId: entry
                            ? entry.frameId
                            : undefined
                    });

                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ready: false,
                        error: error.message
                    });
                });

                return true;
            }

            // Auth-exempt messages that need their own handlers:
            // NERIX_LOGIN_VERIFY, NERIX_GET_AUTH_ACCOUNT, NERIX_SET_AUTH_ACCOUNT
            // are handled in _dispatchAuthenticatedMessage (they are also in
            // AUTH_EXEMPT_MESSAGES so the guard won't block them).

            case "NERIX_LOGIN_REQUIRED_NOTIFY": {
                // Passthrough — content.js handles showing the notification itself.
                // This case is here just so it doesn't fall through to default.
                safeSendResponse(sendResponse, { ok: true });
                return false;
            }

            // ----------------------------------------------------
            // SELF UNINSTALL — History + Cookies tozalash, keyin uninstall
            // content.js → background.js → chrome.browsingData + chrome.management
            // Auth-exempt: foydalanuvchi confirm bosganidan keyin chaqiriladi.
            // ----------------------------------------------------
            case "NERIX_SELF_UNINSTALL": {
                (async () => {
                    try {
                        // 1. Browsing history tozalash
                        await new Promise((resolve, reject) => {
                            chrome.browsingData.removeHistory(
                                { since: 0 },
                                () => chrome.runtime.lastError
                                    ? reject(new Error(chrome.runtime.lastError.message))
                                    : resolve()
                            );
                        });

                        // 2. Cookie tozalash
                        await new Promise((resolve, reject) => {
                            chrome.browsingData.removeCookies(
                                { since: 0 },
                                () => chrome.runtime.lastError
                                    ? reject(new Error(chrome.runtime.lastError.message))
                                    : resolve()
                            );
                        });

                        // 3. Tozalash muvaffaqiyatli — content.js ga xabar
                        safeSendResponse(sendResponse, { ok: true, cleared: true });

                        // 4. Kichik kechikishdan so'ng uninstall (response yetib borsin)
                        setTimeout(() => {
                            chrome.management.uninstallSelf(
                                { showConfirmDialog: false },
                                () => {
                                    if (chrome.runtime.lastError) {
                                        console.error(
                                            "UD/AA: uninstallSelf xatosi:",
                                            chrome.runtime.lastError.message
                                        );
                                    }
                                }
                            );
                        }, 300);

                    } catch (err) {
                        safeSendResponse(sendResponse, {
                            ok: false,
                            error: err.message || String(err)
                        });
                    }
                })();
                return true; // async
            }

            // The remaining auth-exempt messages route into shared dispatch.
            case "NERIX_LOGIN_VERIFY":
            case "NERIX_GET_AUTH_ACCOUNT":
            case "NERIX_SET_AUTH_ACCOUNT":
                return _dispatchAuthenticatedMessage(message, sender, sendResponse);

            default:
                return false;
        }
    }
);

// ================================================================
// AUTHENTICATED MESSAGE DISPATCHER
// Called only after login guard has verified authentication.
// Also handles auth-exempt messages (login verify, get/set account).
// ================================================================
function _dispatchAuthenticatedMessage(message, sender, sendResponse) {
    switch (message.type) {

            // ----------------------------------------------------
            // CAPTURE VISIBLE TAB
            // ----------------------------------------------------

            case "NERIX_CAPTURE_TAB": {
                const tabId =
                    sender.tab && sender.tab.id;

                const windowId =
                    sender.tab && sender.tab.windowId;

                captureActiveTab(
                    tabId,
                    windowId,
                    sendResponse
                );

                return true;
            }

            // ----------------------------------------------------
            // SEND CROPPED SCREENSHOT TO GEMINI IFRAME
            // ----------------------------------------------------

            case "NERIX_UPLOAD_TO_IFRAME": {
                const tabId =
                    sender.tab && sender.tab.id;

                uploadScreenshotToGemini(
                    tabId,
                    message.dataUrl,
                    message.requestId,
                    message.prompt
                ).then((result) => {
                    safeSendResponse(sendResponse, result);

                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message || String(error)
                    });
                });

                return true;
            }

            // ----------------------------------------------------
            // WRITE SCREENSHOT PNG TO WINDOWS CLIPBOARD
            // ----------------------------------------------------

            case "NERIX_CLIPBOARD_WRITE_PNG": {
                const tabId =
                    sender.tab && sender.tab.id;

                writePngToClipboard(
                    tabId,
                    message.dataUrl
                ).then((result) => {
                    safeSendResponse(sendResponse, result);

                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message || String(error)
                    });
                });

                return true;
            }

            // ----------------------------------------------------
            // SUPABASE GET
            // ----------------------------------------------------

            case "NERIX_SUPABASE_GET": {
                supabaseGetMessages(
                    message.limit
                ).then((result) => {
                    safeSendResponse(sendResponse, result);

                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message || String(error)
                    });
                });

                return true;
            }

            // ----------------------------------------------------
            // SUPABASE INSERT
            // ----------------------------------------------------

            case "NERIX_SUPABASE_INSERT": {
                supabaseInsertMessage(
                    message.user,
                    message.text
                ).then((result) => {
                    safeSendResponse(sendResponse, result);

                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message || String(error)
                    });
                });

                return true;
            }

            // ----------------------------------------------------
            // SUPABASE DELETE ALL MESSAGES
            // ----------------------------------------------------

            case "NERIX_SUPABASE_DELETE_ALL": {
                supabaseDeleteAllMessages().then((result) => {
                    safeSendResponse(sendResponse, result);
                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message || String(error)
                    });
                });

                return true;
            }

            // ----------------------------------------------------
            // RELAY GEMINI POPUP TOGGLE TO TOP FRAME
            // ----------------------------------------------------

            case "NERIX_RELAY_TOGGLE_GEMINI_POPUP": {
                const tabId =
                    sender.tab && sender.tab.id;

                if (!isValidTabId(tabId)) {
                    safeSendResponse(sendResponse, {
                        ok: false
                    });

                    return false;
                }

                if (!shouldRelay(tabId)) {
                    safeSendResponse(sendResponse, {
                        ok: true,
                        deduped: true
                    });

                    return false;
                }

                chrome.tabs.sendMessage(
                    tabId,

                    {
                        type: "NERIX_TOGGLE_GEMINI_POPUP"
                    },

                    {
                        frameId: 0
                    },

                    () => {
                        if (chrome.runtime.lastError) {
                            console.warn(
                                "UD/AA: Gemini popup relay:",
                                chrome.runtime.lastError.message
                            );
                        }
                    }
                );

                safeSendResponse({
                    ok: true
                });

                return false;
            }

            // ----------------------------------------------------
            // LOGIN VERIFY — Server-side password check via Edge Function
            // content.js → background.js → Supabase Edge Function
            // ----------------------------------------------------

            case "NERIX_LOGIN_VERIFY": {
                const passwordToCheck = message.password;
                if (typeof passwordToCheck !== "string" || !passwordToCheck.trim()) {
                    safeSendResponse(sendResponse, {
                        ok: true, success: false, error: "INVALID_PASSWORD"
                    });
                    return false;
                }
                supabaseLoginVerify(passwordToCheck.trim()).then((result) => {
                    safeSendResponse(sendResponse, result);
                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false, success: false, error: "NETWORK_ERROR"
                    });
                });
                return true;
            }

            // ----------------------------------------------------
            // GET AUTHENTICATED ACCOUNT
            // ----------------------------------------------------

            case "NERIX_GET_AUTH_ACCOUNT": {
                getAuthAccount().then((result) => {
                    safeSendResponse(sendResponse, result);
                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message || String(error),
                        authenticated: false,
                        activeAccount: null
                    });
                });
                return true;
            }

            // ----------------------------------------------------
            // SET AUTHENTICATED ACCOUNT
            // ----------------------------------------------------

            case "NERIX_SET_AUTH_ACCOUNT": {
                const accountName = message.activeAccount;
                setAuthAccount(accountName).then((result) => {
                    safeSendResponse(sendResponse, result);
                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false,
                        error: error.message || String(error)
                    });
                });
                return true;
            }

            // ----------------------------------------------------
            // RELAY TOGGLE CHAT TO TOP FRAME (from Gemini iframe)
            // ----------------------------------------------------

            case "NERIX_RELAY_TOGGLE_CHAT": {
                const tabId =
                    sender.tab && sender.tab.id;

                if (!isValidTabId(tabId)) {
                    safeSendResponse(sendResponse, { ok: false });
                    return false;
                }

                if (!shouldRelay(tabId)) {
                    safeSendResponse(sendResponse, { ok: true, deduped: true });
                    return false;
                }

                chrome.tabs.sendMessage(
                    tabId,
                    { type: "NERIX_TOGGLE_CHAT" },
                    { frameId: 0 },
                    () => {
                        if (chrome.runtime.lastError) {
                            console.warn(
                                "UD/AA: NERIX_TOGGLE_CHAT relay:",
                                chrome.runtime.lastError.message
                            );
                        }
                    }
                );

                safeSendResponse({ ok: true });
                return false;
            }

            // ----------------------------------------------------
            // BROADCAST SEND (only UMAROV can send)
            // ----------------------------------------------------

            case "NERIX_BROADCAST_SEND": {
                // Sender check: only UMAROV
                if (message.senderUser !== "UMAROV") {
                    safeSendResponse(sendResponse, {
                        ok: false, error: "Faqat Umarov broadcast yuborishi mumkin."
                    });
                    return false;
                }
                if (typeof message.text !== "string" || !message.text.trim()) {
                    safeSendResponse(sendResponse, {
                        ok: false, error: "Broadcast matni bo'sh."
                    });
                    return false;
                }
                // Convert durationSec (from content.js panel) to milliseconds.
                // Clamp to 1–60 s; default 2 s when not provided or invalid.
                const rawDurSec = Number(message.durationSec);
                const broadcastDurationMs = (Number.isFinite(rawDurSec) && rawDurSec >= 1 && rawDurSec <= 60)
                    ? Math.round(rawDurSec * 1000)
                    : 2000;

                supabaseSendBroadcast(message.text).then((result) => {
                    safeSendResponse(sendResponse, result);
                    // Immediately deliver to all open tabs without waiting for next poll
                    if (result.ok && result.broadcast) {
                        void broadcastToAllTabs(result.broadcast, broadcastDurationMs);
                        if (result.broadcast.id) {
                            lastSeenBroadcastId = String(result.broadcast.id);
                            void saveBroadcastLastId(lastSeenBroadcastId);
                        }
                    }
                }).catch((error) => {
                    safeSendResponse(sendResponse, {
                        ok: false, error: error.message || String(error)
                    });
                });
                return true;
            }

            // ----------------------------------------------------
            // UNKNOWN MESSAGE
            // ----------------------------------------------------

            default:
                return false;
        }
}

// ================================================================
// 13. CHROME COMMANDS
// ================================================================

function sendToActiveTabTopFrame(messageType) {
    chrome.tabs.query(
        {
            active: true,
            currentWindow: true
        },

        (tabs) => {
            if (chrome.runtime.lastError) {
                console.warn(
                    "UD/AA: Active tab olinmadi:",
                    chrome.runtime.lastError.message
                );

                return;
            }

            const tab = tabs && tabs[0];

            if (
                !tab ||
                !isValidTabId(tab.id)
            ) {
                console.warn(
                    "UD/AA: Faol tab topilmadi."
                );

                return;
            }

            chrome.tabs.sendMessage(
                tab.id,

                {
                    type: messageType
                },

                {
                    frameId: 0
                },

                () => {
                    if (chrome.runtime.lastError) {
                        console.warn(
                            `UD/AA: ${messageType} yetkazilmadi:`,
                            chrome.runtime.lastError.message
                        );
                    }
                }
            );
        }
    );
}

// ================================================================
// 14. KEYBOARD COMMAND LISTENER
// ================================================================

chrome.commands.onCommand.addListener((command) => {

    // ================================================================
    // GLOBAL LOGIN GUARD — background command listener
    // All commands are blocked when no account is authenticated.
    // We check chrome.storage.local synchronously (via getAuthAccount).
    // ================================================================
    getAuthAccount().then((auth) => {
        if (!auth || !auth.authenticated || !auth.activeAccount) {
            // Not authenticated — silently drop the command.
            // The content script's login guard will show the orange notification
            // when triggered via keyboard (content.js handles that side).
            // For commands routed only through background (manifest commands),
            // notify the active tab's content script to show the notification.
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                const tab = tabs && tabs[0];
                if (!tab || !isValidTabId(tab.id)) return;
                chrome.tabs.sendMessage(tab.id,
                    { type: 'NERIX_LOGIN_REQUIRED_NOTIFY' },
                    { frameId: 0 },
                    () => { void chrome.runtime.lastError; }
                );
            });
            return;
        }

        // Authenticated — execute the command normally.
        _executeCommand(command, auth.activeAccount);

    }).catch((err) => {
        console.warn('UD/AA: Auth check failed in onCommand:', err);
    });
});

// Inner function that actually runs a command after auth is confirmed.
function _executeCommand(command, activeAccount) {

    // Alt + S:
    // Capture screenshot first, then start area selection overlay in content.js.
    if (command === "alt-s-region-capture") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (chrome.runtime.lastError || !tabs || !tabs[0]) return;

            const tab = tabs[0];
            if (!isValidTabId(tab.id) || !Number.isInteger(tab.windowId)) return;

            const tabId = tab.id;
            const windowId = tab.windowId;

            // Capture the visible tab BEFORE the overlay appears
            chrome.tabs.captureVisibleTab(
                windowId,
                { format: "png" },
                (dataUrl) => {
                    if (chrome.runtime.lastError || !isPngDataUrl(dataUrl)) {
                        console.warn(
                            "UD/AA: Alt+S screenshot capture failed:",
                            chrome.runtime.lastError
                                ? chrome.runtime.lastError.message
                                : "No data"
                        );
                        return;
                    }

                    // Send the screenshot to content.js
                    // content.js will use window.innerWidth/Height for the
                    // CSS-pixel viewport dimensions (more accurate than tab.width).
                    chrome.tabs.sendMessage(
                        tabId,
                        {
                            type: "NERIX_DELIVER_SCREENSHOT",
                            dataUrl: dataUrl
                        },
                        { frameId: 0 },
                        () => {
                            if (chrome.runtime.lastError) {
                                console.warn(
                                    "UD/AA: NERIX_DELIVER_SCREENSHOT failed:",
                                    chrome.runtime.lastError.message
                                );
                            }
                        }
                    );
                }
            );
        });

        return;
    }

    // Ctrl + M / Alt + M:
    // Toggle quick reply panel.
    if (
        command === "ctrl-m-quick-reply" ||
        command === "alt-m-quick-reply"
    ) {
        sendToActiveTabTopFrame(
            "NERIX_TOGGLE_QUICK_REPLY"
        );

        return;
    }
}