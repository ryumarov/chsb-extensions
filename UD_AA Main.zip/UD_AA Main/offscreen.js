
/* ================================================================
   UD/AA && tools — offscreen.js v2.2

   Vazifalar:
   1. Background.js dan PNG screenshot ma'lumotini qabul qilish.
   2. PNG ma'lumotini haqiqiy Blob obyektiga aylantirish.
   3. Rasmni Windows system clipboard'ga yozish.
   4. Natijani background.js ga qaytarish.

   Kerakli manifest permissions:
   - offscreen
   - clipboardWrite
   ================================================================ */

'use strict';

const MESSAGE_TYPE = 'NERIX_OFFSCREEN_WRITE_CLIPBOARD';

// Bitta so'rovga ikki marta javob yuborilishining oldini oladi.
function createResponder(sendResponse) {
    let completed = false;

    return function respond(data) {
        if (completed) return;

        completed = true;

        try {
            sendResponse(data);
        } catch (error) {
            console.warn('UD/AA: Javob yuborilmadi:', error);
        }
    };
}

// ================================================================
// 1. PNG DATA URL VALIDATION
// ================================================================

function validatePngDataUrl(dataUrl) {
    if (typeof dataUrl !== 'string' || !dataUrl) {
        throw new Error("Rasm ma'lumoti topilmadi.");
    }

    if (!dataUrl.startsWith('data:image/png;base64,')) {
        throw new Error("Noto'g'ri rasm formati. PNG talab qilinadi.");
    }

    const base64 = dataUrl.substring(
        'data:image/png;base64,'.length
    );

    if (!base64 || !/^[A-Za-z0-9+/]*={0,2}$/.test(base64)) {
        throw new Error("PNG Base64 ma'lumoti noto'g'ri.");
    }

    return base64;
}

// ================================================================
// 2. BASE64 -> REAL PNG BLOB
// ================================================================

function base64ToPngBlob(base64) {
    let binary;

    try {
        binary = atob(base64);
    } catch (error) {
        throw new Error("Rasm Base64 formatidan ochilmadi.");
    }

    if (!binary || binary.length === 0) {
        throw new Error("Rasm bo'sh.");
    }

    const bytes = new Uint8Array(binary.length);

    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }

    // PNG faylining haqiqiy signature qiymatini tekshirish.
    const pngSignature = [
        0x89, 0x50, 0x4E, 0x47,
        0x0D, 0x0A, 0x1A, 0x0A
    ];

    if (
        bytes.length < 8 ||
        !pngSignature.every((value, index) => bytes[index] === value)
    ) {
        throw new Error("Rasm haqiqiy PNG fayli emas.");
    }

    return new Blob(
        [bytes],
        { type: 'image/png' }
    );
}

// ================================================================
// 3. WRITE PNG TO SYSTEM CLIPBOARD
// ================================================================

async function writePngToSystemClipboard(pngBlob) {
    if (!pngBlob || pngBlob.size === 0) {
        throw new Error("Clipboard'ga yoziladigan rasm bo'sh.");
    }

    if (typeof ClipboardItem === 'undefined') {
        throw new Error(
            "ClipboardItem qo'llab-quvvatlanmaydi. " +
            "Chrome brauzerini yangilang."
        );
    }

    if (
        !navigator.clipboard ||
        typeof navigator.clipboard.write !== 'function'
    ) {
        throw new Error(
            "Clipboard API mavjud emas. " +
            "Manifest ichidagi clipboardWrite ruxsatini tekshiring."
        );
    }

    if (
        typeof ClipboardItem.supports === 'function' &&
        !ClipboardItem.supports('image/png')
    ) {
        throw new Error(
            "Brauzer image/png clipboard formatini qo'llab-quvvatlamaydi."
        );
    }

    const clipboardItem = new ClipboardItem({
        'image/png': pngBlob
    });

    // Windows system clipboard'ga haqiqiy PNG yozish.
    await navigator.clipboard.write([
        clipboardItem
    ]);

    return {
        sizeBytes: pngBlob.size,
        mimeType: pngBlob.type
    };
}

// ================================================================
// 4. MAIN CLIPBOARD HANDLER
// ================================================================

async function handleClipboardWrite(dataUrl) {
    try {
        // 1. Ma'lumotni tekshirish.
        const base64 = validatePngDataUrl(dataUrl);

        // 2. Base64 -> PNG Blob.
        const pngBlob = base64ToPngBlob(base64);

        // 3. PNG -> Windows system clipboard.
        const result = await writePngToSystemClipboard(pngBlob);

        return {
            ok: true,
            verified: true,
            mimeType: result.mimeType,
            sizeBytes: result.sizeBytes,
            message: "Rasm clipboard'ga muvaffaqiyatli nusxalandi."
        };

    } catch (error) {
        console.error(
            'UD/AA: Clipboard yozish xatosi:',
            error
        );

        return {
            ok: false,
            error: error && error.message
                ? error.message
                : String(error)
        };
    }
}

// ================================================================
// 5. MESSAGE LISTENER
// ================================================================

chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {

        if (
            !message ||
            message.type !== MESSAGE_TYPE
        ) {
            return false;
        }

        const respond = createResponder(sendResponse);

        // Asinxron clipboard amali.
        handleClipboardWrite(message.dataUrl)
            .then(result => {
                respond(result);
            })
            .catch(error => {
                respond({
                    ok: false,
                    error: error.message || String(error)
                });
            });

        // Chrome message channel ochiq qolishi kerak.
        return true;
    }
);

console.log('UD/AA: Offscreen clipboard service ishga tushdi.');
