// Test if the querySelector selector is valid on a DocumentFragment
const { JSDOM } = require('jsdom');
const dom = new JSDOM('<!DOCTYPE html><html><body><p>Hello world</p></body></html>');
const doc = dom.window.document;
const range = doc.createRange();
range.selectNodeContents(doc.querySelector('p'));
const frag = range.cloneContents();

const selector = 'math, .katex, .katex-display, .katex-html, mjx-container, ' +
    '[data-latex], [data-tex], [data-mathml], .editor-equation, ' +
    'script[type^="math/tex"], annotation[encoding="application/x-tex"], ' +
    '.msupsub, .mfrac, .mord > .msupsub';

try {
    const result = frag.querySelector(selector);
    console.log('✅ querySelector on fragment: OK, result:', result);
} catch(e) {
    console.log('❌ querySelector on fragment ERROR:', e.message);
}

// Test 2: What happens with getRangeAt on empty selection?
try {
    const sel = dom.window.getSelection();
    console.log('Selection rangeCount:', sel.rangeCount);
    if (sel.rangeCount > 0) {
        const r = sel.getRangeAt(0);
        console.log('✅ getRangeAt(0): OK');
    } else {
        console.log('⚠ rangeCount is 0');
    }
} catch(e) {
    console.log('❌ getRangeAt ERROR:', e.message);
}

// Test 3: Check the hasMath regex
const regex = /\\[(\\[]|\\\\frac|\\\\sqrt|\\\\sum|\\\\int|\\\\prod/;
console.log('\nRegex test on plain text:', regex.test('Hello world'));
console.log('Regex test on \\(y=2x^{2}\\):', regex.test('\\(y=2x^{2}\\)'));
console.log('Regex test on \\\\frac:', regex.test('\\\\frac{a}{b}'));
console.log('Regex test on \\frac:', regex.test('\\frac{a}{b}'));

// This is key — in the source code, the regex is /\\\\[(\\[]|\\\\frac/
// In JS source: \\\\[ means literal \\[ but in string context it's different
// Let me test what the actual regex does
const r2 = /\\[(\\[]|\\frac|\\sqrt|\\sum|\\int|\\prod/;
console.log('\nCorrected regex on \\(y\\):', r2.test('\\(y=2x^{2}\\)'));
console.log('Corrected regex on \\[:', r2.test('\\[x\\]'));
console.log('Corrected regex on \\frac:', r2.test('\\frac{a}{b}'));
